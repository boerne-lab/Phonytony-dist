"""Audio-Feedback: kurze WAV-Töne via pw-play (Fallback aplay), nicht-blockierend."""

from __future__ import annotations

import asyncio
import logging
import shutil
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger(__name__)

SOUNDS = {
    "startup":      "startup.wav",
    "tag_ok":       "tag_ok.wav",
    "tag_unknown":  "tag_unknown.wav",
    "tag_removed":  "tag_removed.wav",
    "offline":      "offline.wav",
    "error":        "error.wav",
    "volume_max":   "volume_max.wav",
    "volume_min":   "volume_min.wav",
}


class FeedbackPlayer:
    # So lange wartet der erste Ton auf einen benutzbaren Ausgang. Gemessen
    # waren es auf der Box neun Sekunden von musicbox-core bis PipeWire.
    _WARTE_MAX_S = 15.0
    _WARTE_SCHRITT_S = 0.5

    def __init__(self, sounds_dir: Path, alsa_card: str,
                 volume: Optional[Callable[[], int]] = None) -> None:
        self._dir = sounds_dir
        self._card = alsa_card
        self._playing = False
        # Nur der erste Ton wartet auf einen Ausgang (siehe _mit_ausgang).
        self._ausgang_geprueft = False
        # Wird bei jedem Ton aufgerufen, damit ein Schieben des Reglers sofort
        # hörbar ist. Ohne Angabe bleibt es beim vollen Pegel wie bisher.
        self._volume = volume

    def _lautstaerke(self) -> Optional[int]:
        """0–100, oder None wenn keine Einstellung vorliegt.

        Ein Fehler beim Lesen darf den Ton nicht verschlucken: Eine ausbleibende
        Rückmeldung ist schlimmer als eine zu laute — sie sieht aus wie ein
        Gerät, das nicht reagiert hat.
        """
        if self._volume is None:
            return None
        try:
            return max(0, min(100, int(self._volume())))
        except Exception:
            log.debug("Lautstärke der Warntöne nicht lesbar — voller Pegel")
            return None

    async def play(self, name: str) -> None:
        """Spielt einen Ton, ohne auf das Ende der Wiedergabe zu warten.

        Läuft bereits ein Ton, wird der Aufruf übersprungen (kein Aufstauen) —
        so bleiben z.B. Anschlag-Töne synchron zum schnellen Drehen des Encoders,
        statt die Event-Schleife zu blockieren.
        """
        filename = SOUNDS.get(name)
        if not filename:
            log.warning("Unbekannter Sound: %r", name)
            return
        path = self._dir / filename
        if not path.exists():
            log.debug("Sound-Datei nicht vorhanden: %s", path)
            return
        if self._lautstaerke() == 0:
            # Stumm gestellt: Auch ein lautloser pw-play-Aufruf ist auf einem
            # Pi Zero Arbeit, die niemand hört.
            return
        if self._playing:
            return
        self._playing = True
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            # Kein laufender Loop (z.B. synchroner Kontext) → direkt abspielen
            await self._mit_ausgang(path)
        else:
            asyncio.create_task(self._mit_ausgang(path))

    async def _mit_ausgang(self, path: Path) -> None:
        """Spielt den Ton, sobald ein Ausgang bereitsteht.

        Nur der erste Ton wartet. Auf der Box ist ``musicbox-core`` neun
        Sekunden vor PipeWire da — der Startton lief in dieser Lücke ins Leere,
        mal hörbar, mal nicht. Spätere Töne warten nie: Dann läuft PipeWire
        längst, und ein Wartelauf bei jedem Tastendruck würde genau die
        Rückmeldung verzögern, für die die Töne da sind.
        """
        if not self._ausgang_geprueft:
            self._ausgang_geprueft = True
            gewartet = 0.0
            while gewartet < self._WARTE_MAX_S:
                if await self._ausgang_da():
                    break
                await asyncio.sleep(self._WARTE_SCHRITT_S)
                gewartet += self._WARTE_SCHRITT_S
            else:
                # Kein Ausgang in Sicht — Ton verwerfen. Die Box muss bedienbar
                # bleiben, auch wenn sie stumm ist.
                log.info("Kein Audio-Ausgang nach %.0f s — Ton verworfen",
                         self._WARTE_MAX_S)
                self._playing = False
                return

        await self._play_file(path)

    async def _ausgang_da(self) -> bool:
        """Ob PipeWire ansprechbar ist. Fehlt pw-play, gilt der Weg über aplay
        als vorhanden — der braucht PipeWire nicht."""
        if not shutil.which("pw-play"):
            return True
        try:
            proc = await asyncio.create_subprocess_exec(
                "pw-cli", "info", "0",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            return await proc.wait() == 0
        except Exception:
            return False

    async def _play_file(self, path: Path) -> None:
        # pw-play spielt über PipeWire und erreicht damit auch Bluetooth-Sinks.
        # aplay bleibt als Fallback, falls PipeWire (noch) nicht installiert ist.
        if shutil.which("pw-play"):
            cmd = ["pw-play"]
            pegel = self._lautstaerke()
            if pegel is not None:
                cmd += ["--volume", f"{pegel / 100:.2f}"]
            cmd.append(str(path))
        else:
            # aplay kennt --volume nicht; die Option mitzugeben ließe den Ton
            # ganz ausfallen statt ihn nur lauter zu spielen.
            cmd = ["aplay", "-D", "default", str(path)]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
        except Exception:
            log.debug("%s fehlgeschlagen für %s", cmd[0], path)
        finally:
            self._playing = False
