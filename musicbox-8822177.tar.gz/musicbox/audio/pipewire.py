"""PipeWire-Sinks über pactl steuern (pipewire-pulse spricht das Pulse-Protokoll).

pactl statt wpctl, weil die PipeWire-Node-Namen die MAC des Kopfhörers enthalten
(bluez_output.AA_BB_CC_DD_EE_FF.1) — der Bluetooth-Sink ist damit eindeutig
erkennbar, statt über den Anzeigenamen geraten werden zu müssen.
"""

from __future__ import annotations

import logging
import subprocess
from typing import Callable, Optional

log = logging.getLogger(__name__)

_BT_PREFIX = "bluez_output."
_ALSA_PREFIX = "alsa_output."
# Die Box hat zwei ALSA-Karten (HDMI und die WM8960-Soundkarte). pactl gibt nach
# Index sortiert aus — ohne gezielte Suche landete der Ton beim Zurückschalten von
# Bluetooth auf HDMI, sobald dort je ein Sink auftaucht.
_WM8960_HINTS = ("soc_sound", "wm8960")
_TIMEOUT = 5


def _run(args: list, runner: Callable) -> Optional[str]:
    try:
        r = runner(["pactl", *args], capture_output=True, text=True, timeout=_TIMEOUT)
    except Exception as e:
        log.debug("pactl %s fehlgeschlagen: %s", args, e)
        return None
    if getattr(r, "returncode", 1) != 0:
        log.debug("pactl %s: rc=%s", args, getattr(r, "returncode", None))
        return None
    return getattr(r, "stdout", "") or ""


def sinks(*, runner: Callable = subprocess.run) -> list[dict]:
    """Alle Sinks als [{"id", "name"}] — aus `pactl list sinks short`."""
    out = _run(["list", "sinks", "short"], runner)
    result = []
    for line in (out or "").splitlines():
        parts = line.split("\t") if "\t" in line else line.split()
        if len(parts) < 2 or not parts[0].strip().isdigit():
            continue
        result.append({"id": int(parts[0].strip()), "name": parts[1].strip()})
    return result


def bluetooth_sink(sink_list: list) -> Optional[dict]:
    return next((s for s in sink_list if s["name"].startswith(_BT_PREFIX)), None)


def alsa_sink(sink_list: list) -> Optional[dict]:
    """Der ALSA-Sink der WM8960-Karte; das Präfix allein nur als Rückfall."""
    wm8960 = next((s for s in sink_list
                   if s["name"].startswith(_ALSA_PREFIX)
                   and any(h in s["name"].lower() for h in _WM8960_HINTS)), None)
    if wm8960:
        return wm8960
    return next((s for s in sink_list if s["name"].startswith(_ALSA_PREFIX)), None)


def set_default(name: str, *, runner: Callable = subprocess.run) -> bool:
    return _run(["set-default-sink", name], runner) is not None


def set_volume(name: str, pct: int, *, runner: Callable = subprocess.run) -> bool:
    pct = max(0, min(100, int(pct)))
    return _run(["set-sink-volume", name, f"{pct}%"], runner) is not None


def apply_bluetooth_volume(pct: int, *, runner: Callable = subprocess.run) -> bool:
    """Setzt die Lautstärke auf dem Bluetooth-Sink. False, wenn keiner da ist."""
    sink = bluetooth_sink(sinks(runner=runner))
    if not sink:
        return False
    return set_volume(sink["name"], pct, runner=runner)


def switch_default_to(kind: str, *, runner: Callable = subprocess.run) -> bool:
    """Default-Sink auf "bluetooth" oder "alsa" umstellen, damit auch neu
    gestartete Quellen auf dem richtigen Ausgang landen."""
    found = sinks(runner=runner)
    sink = bluetooth_sink(found) if kind == "bluetooth" else alsa_sink(found)
    if not sink:
        return False
    return set_default(sink["name"], runner=runner)
