"""Web-Routen des Offline-Abgleichs.

Der Abgleich selbst liegt in ``musicbox.offline``; hier steht nur, wie er von
der Weboberfläche aus angestoßen und ausgewertet wird.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from musicbox.offline import fetch as fetch_mod
from musicbox.offline import index as ix
from musicbox.offline import reconcile, runner
from musicbox.offline.matcher import match

router = APIRouter()
log = logging.getLogger(__name__)


def _index_pfad(request: Request) -> Path:
    return Path(request.app.state.settings.data_dir) / "offline_index.json"


def _stores(request: Request) -> reconcile.Stores:
    state = request.app.state
    state.playlist_store.load()
    return reconcile.Stores(mapping=state.mapping_store, playlists=state.playlist_store,
                            music_dir=Path(state.settings.music_dir))


def _eintraege(request: Request):
    """Alle Karten und Bibliothekseinträge als (key, entry, is_library)."""
    mapping = request.app.state.mapping_store
    mapping.reload_if_changed()
    return ([(k, e, False) for k, e in mapping.all_cards().items()]
            + [(k, e, True) for k, e in mapping.library_all().items()])


def _finde(request: Request, key: str):
    for eintrag in _eintraege(request):
        if eintrag[0] == key:
            return eintrag
    return None


def _pfad_pruefen(request: Request, rel: str) -> Path:
    """Nur Dateien innerhalb der Musikordner sind zulässig — der Pfad kommt
    aus dem Netz, ein Ausbruch daraus wäre ein Einfallstor."""
    music_dir = Path(request.app.state.settings.music_dir).resolve()
    ziel = (music_dir / rel).resolve()
    if not ziel.is_relative_to(music_dir) or not ziel.is_file():
        raise HTTPException(400, f"Unbekannte Datei: {rel}")
    return ziel


@router.post("/offline/scan")
async def offline_scan(request: Request) -> Any:
    """Abgleich von Hand anstoßen — gilt auch bei abgeschalteter Automatik."""
    körper = await _json(request)
    bericht = await runner.run(request.app.state, trigger="manuell",
                               recheck_offline=bool(körper.get("recheck_offline")))
    if bericht.get("busy"):
        return {"ok": False, "busy": True, "report": bericht}
    return {"ok": True, "busy": False, "report": bericht}


@router.get("/offline/suggestions")
async def offline_suggestions(request: Request) -> Any:
    """Offene unsichere Treffer aus dem letzten Lauf, dazu dessen Eckdaten.

    Gelesen, nicht gerechnet: ein Abgleich über alle Karten kostet den Pi Zero
    mehrere Sekunden, und diese Liste wird bei jedem Aufruf der Geräteseite
    geholt. Neu berechnet wird sie beim Lauf und nach jeder Bestätigung."""
    index = ix.load(_index_pfad(request))
    return {"items": list(index.suggestions.values()), "last_run": index.last_run or {}}


@router.post("/offline/confirm")
async def offline_confirm(request: Request) -> Any:
    """Eine vorgeschlagene Zuordnung bestätigen; danach den Eintrag neu prüfen."""
    körper = await _json(request)
    uri = (körper.get("uri") or "").strip()
    rel = (körper.get("path") or "").strip()
    if not uri or not rel:
        raise HTTPException(400, "uri und path sind erforderlich")
    _pfad_pruefen(request, rel)

    pfad = _index_pfad(request)
    index = ix.load(pfad)
    ix.confirm(index, uri, rel)
    ix.drop_suggestion(index, uri)

    umgestellt = await _neu_pruefen(request, körper.get("key"), index)
    ix.save(pfad, index)
    return {"ok": True, "converted": umgestellt}


@router.post("/offline/reject")
async def offline_reject(request: Request) -> Any:
    """Eine vorgeschlagene Zuordnung ablehnen — sie wird nicht wieder angeboten."""
    körper = await _json(request)
    uri = (körper.get("uri") or "").strip()
    rel = (körper.get("path") or "").strip()
    if not uri or not rel:
        raise HTTPException(400, "uri und path sind erforderlich")

    pfad = _index_pfad(request)
    index = ix.load(pfad)
    ix.reject(index, uri, rel)
    ix.save(pfad, index)
    return {"ok": True}


@router.get("/offline/status")
async def offline_status(request: Request, uri: str, key: str = "") -> Any:
    """Trackweise Offline-Verfügbarkeit für die Bearbeiten-Ansicht."""
    index = ix.load(_index_pfad(request))

    entry = None
    if key:
        gefunden = _finde(request, key)
        entry = gefunden[1] if gefunden else None
    if entry is None:
        entry = {"type": "spotify", "ref": uri}

    # Vor dem ersten Lauf ist der Index leer: dann wäre "0 von 18 offline" eine
    # falsche Auskunft — die Dateien können längst da sein, nur ungeprüft.
    schon_gelaufen = bool(index.last_run)

    tracks = await runner.tracklist(request.app.state, entry)
    if tracks is None:
        return {"available": False, "scanned": schon_gelaufen, "tracks": [],
                "total": 0, "offline": 0, "complete": False}

    ergebnis = match(tracks, index, excluded_uris=set(entry.get("excluded_tracks") or []))
    spielbar = [t for t in ergebnis.tracks if t.status != "excluded"]
    return {
        "available": True,
        "scanned": schon_gelaufen,
        "complete": ergebnis.complete,
        "total": len(spielbar),
        "offline": sum(1 for t in spielbar if t.status == "sure"),
        "tracks": [{"uri": t.uri, "name": t.name, "by": t.by, "status": t.status,
                    "path": t.path, "candidates": t.candidates}
                   for t in ergebnis.tracks],
    }


@router.post("/offline/revert")
async def offline_revert(request: Request) -> Any:
    """Eine offline gestellte Karte wieder auf Spotify umstellen."""
    körper = await _json(request)
    key = (körper.get("key") or "").strip()
    gefunden = _finde(request, key)
    if gefunden is None:
        raise HTTPException(404, f"Eintrag nicht gefunden: {key}")

    _, entry, is_library = gefunden
    if entry.get("type") != "local" or not entry.get("offline_of"):
        raise HTTPException(400, "Dieser Eintrag spielt nicht aus einer Spotify-Herkunft")

    ergebnis = reconcile.revert(key, entry, stores=_stores(request), is_library=is_library)
    return {"ok": ergebnis == "reverted"}


async def _neu_pruefen(request: Request, key, index) -> bool:
    """Prüft einen einzelnen Eintrag nach einer Bestätigung — wird er dadurch
    vollständig, stellt er sofort um."""
    if not key:
        return False
    gefunden = _finde(request, str(key))
    if gefunden is None:
        return False

    _, entry, is_library = gefunden
    tracks = await runner.tracklist(request.app.state, entry)
    if not tracks:
        return False

    ergebnis = match(tracks, index, excluded_uris=set(entry.get("excluded_tracks") or []))
    offen = [{"uri": t.uri, "name": t.name, "by": t.by,
              "candidates": list(t.candidates), "score": round(t.score, 2)}
             for t in ergebnis.tracks if t.status == "unsure"]
    if offen:
        index.suggestions[str(key)] = {
            "key": str(key), "label": entry.get("label") or str(key),
            "is_library": is_library, "tracks": offen}
    else:
        index.suggestions.pop(str(key), None)

    if not ergebnis.complete:
        return False

    umgestellt = reconcile.apply(str(key), entry, ergebnis, stores=_stores(request),
                                 is_library=is_library,
                                 spotify_name=entry.get("label") or "")
    return umgestellt == "converted"


async def _json(request: Request) -> dict:
    """Körper als dict; ein leerer Körper ist zulässig."""
    try:
        daten = await request.json()
    except Exception:
        return {}
    return daten if isinstance(daten, dict) else {}


# ── Hol-Vorgang ────────────────────────────────────────────────────────────
#
# own-librespot holt die fehlenden Titel einer Karte, ohne sie abzuspielen.
# Die Umstellung der Karte macht danach der reguläre Abgleich — hier wird nur
# beauftragt und beobachtet.

@router.post("/offline/fetch")
async def offline_fetch(request: Request) -> Any:
    """Fehlende Titel einer Karte holen lassen."""
    körper = await _json(request)
    key = (körper.get("key") or "").strip()
    if not key:
        raise HTTPException(400, "key ist erforderlich")

    kategorie = (körper.get("category") or "musik").strip()
    if kategorie not in ("musik", "hoerbuch"):
        kategorie = "musik"

    ergebnis = await fetch_mod.start(request.app.state, key, category=kategorie)
    if ergebnis["reason"] == "not_found":
        raise HTTPException(404, f"Eintrag nicht gefunden: {key}")
    return {**ergebnis, "message": _erklaere(ergebnis)}


@router.get("/offline/fetch")
async def offline_fetch_status(request: Request) -> Any:
    """Stand des laufenden Hol-Vorgangs."""
    return await fetch_mod.status(request.app.state)


@router.post("/offline/fetch/cancel")
async def offline_fetch_cancel(request: Request) -> Any:
    """Den Hol-Vorgang abbrechen. Was schon geholt wurde, bleibt erhalten."""
    return await fetch_mod.cancel(request.app.state)


def _erklaere(ergebnis: dict) -> str:
    """Ein Satz für die Weboberfläche — die Gründe kommen teils vom Fork."""
    if ergebnis["ok"] and ergebnis["reason"] == "complete":
        return "Alle Titel dieser Karte liegen bereits vor."
    if ergebnis["ok"] and ergebnis["reason"] == "einraeumen_laeuft":
        return (f"{ergebnis.get('wartend', 0)} geholte Titel warten noch darauf, "
                "eingeräumt zu werden. Der Import ist vorgemerkt und startet, "
                "sobald ein laufender Abgleich fertig ist.")
    if ergebnis["ok"]:
        return f"{ergebnis['missing']} Titel werden geholt."
    return {
        "busy": "Es läuft bereits ein Hol-Vorgang.",
        "no_session": "Die Box ist gerade nicht bei Spotify angemeldet.",
        "rejected": "own-librespot hat den Auftrag abgelehnt — ist der Export eingeschaltet?",
        "unreachable": "own-librespot ist nicht erreichbar.",
        "unsupported": "Die laufende Fassung von own-librespot kennt das Herunterladen nicht.",
        "no_tracklist": "Die Titelliste ist gerade nicht abrufbar (kein Netz und nichts im Zwischenspeicher).",
    }.get(ergebnis["reason"], "Der Hol-Vorgang ist fehlgeschlagen.")
