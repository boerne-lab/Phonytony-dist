"""REST API: /api/*"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import socket
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, Response

from musicbox.web import cover as cover_mod
from musicbox.web import spotify_cache
from musicbox.web import spotify_images
from musicbox.web.spotify_items import track_of, tracks_by_ids
from musicbox.web import sticker

log = logging.getLogger(__name__)

router = APIRouter()

# Spotify-Metadaten altern langsam (Playlist-Namen, Tracklisten) — ein Tag frisch
# genug, damit die Weboberfläche nicht bei jedem Aufruf ans Netz muss.
_SPOTIFY_CACHE_TTL_S = 24 * 3600


def _spotify_cache_dir(request: Request):
    return request.app.state.settings.data_dir / "spotify_cache"


def _spotify_image_dir(request: Request):
    return request.app.state.settings.data_dir / "spotify_images"


async def _cached_spotify(request: Request, *, kind: str, params: dict, fetch,
                          nocache: bool, error_label: str) -> Any:
    """Antwort aus dem Cache, sonst frisch von Spotify.

    Ist Spotify nicht erreichbar, wird notfalls der veraltete Cache-Eintrag
    ausgeliefert (mit ``stale: true``) — die Kartenverwaltung bleibt so auch
    ohne WLAN bedienbar. Ein abgelaufener Token hat Vorrang vor dem Fallback,
    weil er eine Handlungsaufforderung ist.
    """
    import spotipy

    cache_dir = _spotify_cache_dir(request)
    key = spotify_cache.key_for(kind, params)

    if not nocache:
        hit = spotify_cache.read(cache_dir, key, max_age_s=_SPOTIFY_CACHE_TTL_S)
        if hit is not None:
            return hit

    try:
        data = await asyncio.to_thread(fetch)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except spotipy.SpotifyException as e:
        if e.http_status in (401, 403):
            # 401 (Token abgelaufen) und 403 (z.B. keine Berechtigung für eine
            # bestimmte Playlist) sehen im UI identisch aus ("reauth_required"),
            # haben aber unterschiedliche Ursachen — `detail` liefert die rohe
            # Spotify-Meldung fürs Debugging mit, rein additiv fürs Frontend.
            return JSONResponse({"items": [], "error": "reauth_required", "detail": str(e)})
        return _stale_or_error(cache_dir, key, error_label, e)
    except Exception as e:
        return _stale_or_error(cache_dir, key, error_label, e)

    if _hat_inhalt(data):
        spotify_cache.write(cache_dir, key, data)
    return data


def _hat_inhalt(data) -> bool:
    """Ob sich das Zwischenspeichern lohnt.

    Eine leere Antwort ist entweder billig neu zu holen (Seite hinter dem Ende
    einer Liste) oder das Symptom einer Störung. Mit 24 Stunden Lebensdauer
    würde sie einen behobenen Fehler einen ganzen Tag lang überleben.
    """
    if isinstance(data, dict) and "items" in data:
        return bool(data["items"])
    return data is not None


def _stale_or_error(cache_dir, key: str, error_label: str, exc: Exception) -> Any:
    stale = spotify_cache.read_stale(cache_dir, key)
    if isinstance(stale, dict):
        log.info("%s (%s) — liefere veralteten Cache-Stand", error_label, exc)
        return {**stale, "stale": True}
    raise HTTPException(503, f"{error_label}: {exc}")


def _cover_cache_dir(request: Request):
    from pathlib import Path  # noqa: F401  (Pfad-Objekt kommt aus settings)
    s = request.app.state.settings
    return s.music_dir.parent / "cover_cache"


def _ipc(settings, cmd: dict) -> bool:
    """Sendet JSON-Kommando an control.sock; gibt True bei Erfolg zurück."""
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(2.0)
        sock.connect(settings.control_socket)
        sock.sendall((json.dumps(cmd) + "\n").encode())
        resp = json.loads(sock.recv(256))
        sock.close()
        return resp.get("ok", False)
    except Exception:
        return False


@router.get("/status")
def get_status(request: Request) -> dict:
    state_store = request.app.state.state_store
    state_store.load()
    s = state_store.state
    return {
        "volume": s.volume,
        "active_uid": s.active_uid,
        "active_backend": s.active_backend,
        "last_scanned_uid": s.last_scanned_uid,
        "last_scanned_at": s.last_scanned_at,
        "present_uid": s.present_uid,
        "spotify_authorized": _spotify_authorized(request),
    }


def _spotify_authorized(request: Request) -> bool:
    try:
        sp_oauth = request.app.state.sp_oauth
        token = sp_oauth.get_cached_token()
        return token is not None
    except Exception:
        return False


@router.get("/sticker/{uid}.{ext}")
def card_sticker(uid: str, ext: str, request: Request):
    """Kreditkartengroßer Aufkleber (Cover + Titel) als PNG oder PDF."""
    ext = ext.lower()
    if ext not in ("png", "pdf"):
        raise HTTPException(404, "Format")
    uid = uid.upper()
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    card = ms.get(uid)
    if not card:
        raise HTTPException(404, "Karte nicht gefunden")
    s = request.app.state.settings
    covers_dir = s.music_dir.parent / "covers"
    title, cover = sticker.cover_title_for_card(
        card, uid,
        sp_oauth=request.app.state.sp_oauth,
        music_dir=s.music_dir,
        covers_dir=covers_dir,
    )
    data = sticker.render(title, cover, ext, online=(card.get("type") == "spotify"))
    media = "application/pdf" if ext == "pdf" else "image/png"
    safe = "".join(ch for ch in (title or uid) if ch.isalnum() or ch in " -_")[:40].strip() or uid
    return Response(
        content=data,
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="sticker_{safe}.{ext}"'},
    )


@router.get("/cover/{uid}.jpg")
def card_cover(uid: str, request: Request):
    """Quadratisches Cover-Thumbnail (JPEG) fürs Karten-Grid, gecacht."""
    uid = uid.upper()
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    card = ms.get(uid)
    if not card:
        raise HTTPException(404, "Karte nicht gefunden")
    s = request.app.state.settings
    data = cover_mod.thumbnail_jpeg(
        card, uid,
        sp_oauth=request.app.state.sp_oauth,
        music_dir=s.music_dir,
        covers_dir=s.music_dir.parent / "covers",
        cache_dir=_cover_cache_dir(request),
    )
    return Response(content=data, media_type="image/jpeg",
                    headers={"Cache-Control": "no-cache"})


@router.get("/cover/lib/{lib_id}.jpg")
def library_cover(lib_id: str, request: Request):
    """Cover-Thumbnail für einen Bibliothekseintrag (noch keiner Karte zugewiesen)."""
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    entry = ms.library_get(lib_id)
    if not entry:
        raise HTTPException(404, "Bibliothekseintrag nicht gefunden")
    s = request.app.state.settings
    data = cover_mod.thumbnail_jpeg(
        entry, f"lib-{lib_id}",
        sp_oauth=request.app.state.sp_oauth,
        music_dir=s.music_dir,
        covers_dir=s.music_dir.parent / "covers",
        cache_dir=_cover_cache_dir(request),
    )
    return Response(content=data, media_type="image/jpeg",
                    headers={"Cache-Control": "no-cache"})


@router.get("/settings")
def get_settings(request: Request) -> dict:
    st = request.app.state.settings_store
    st.reload_if_changed()
    return st.data


@router.post("/settings")
async def save_settings(request: Request) -> dict:
    body = await request.json()
    st = request.app.state.settings_store
    data = st.update(body)
    # Core sofort neu laden lassen (sonst greift es erst beim periodischen Reload)
    await asyncio.to_thread(_ipc, request.app.state.settings, {"action": "reload_settings"})
    return {"ok": True, "settings": data}


@router.get("/mappings")
def list_mappings(request: Request) -> dict:
    mapping_store = request.app.state.mapping_store
    mapping_store.reload_if_changed()
    return {
        "defaults": mapping_store.defaults(),
        "cards": mapping_store.all_cards(),
    }


@router.post("/mappings")
async def create_mapping(request: Request) -> dict:
    body = await request.json()
    uid = body.get("uid", "").upper().replace(":", "").replace(" ", "")
    entry = body.get("entry", {})
    if not uid:
        raise HTTPException(400, "uid fehlt")
    try:
        request.app.state.mapping_store.set(uid, entry)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # Cover-Cache für diese UID verwerfen (Ref könnte sich geändert haben)
    cover_mod.invalidate(_cover_cache_dir(request), uid)
    # _ipc ist blockierendes Socket-I/O → nicht im Event-Loop ausführen
    await asyncio.to_thread(_ipc, request.app.state.settings, {"action": "reload_mapping"})
    return {"ok": True, "uid": uid}


@router.delete("/mappings/{uid}")
def delete_mapping(uid: str, request: Request) -> dict:
    uid = uid.upper()
    deleted = request.app.state.mapping_store.delete(uid)
    if not deleted:
        raise HTTPException(404, "UID nicht gefunden")
    cover_mod.invalidate(_cover_cache_dir(request), uid)
    _ipc(request.app.state.settings, {"action": "reload_mapping"})
    return {"ok": True}


@router.get("/library")
def list_library(request: Request) -> dict:
    mapping_store = request.app.state.mapping_store
    mapping_store.reload_if_changed()
    return {"entries": mapping_store.library_all()}


@router.post("/library")
async def create_library_entry(request: Request) -> dict:
    body = await request.json()
    entry = body.get("entry", {})
    ms = request.app.state.mapping_store
    ref = entry.get("ref")
    existing_id = ms.library_find_by_ref(entry.get("type"), ref) if ref else None
    if existing_id is not None:
        return {"ok": True, "id": existing_id, "existed": True}
    try:
        lib_id = ms.library_create(entry)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "id": lib_id, "existed": False}


@router.put("/library/{lib_id}")
async def update_library_entry(lib_id: str, request: Request) -> dict:
    body = await request.json()
    entry = body.get("entry", {})
    try:
        request.app.state.mapping_store.library_set(lib_id, entry)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # library_set aktualisiert auch bereits zugewiesene Karten. Der Core muss
    # seine im Speicher gehaltene Mapping-Kopie anschließend neu laden.
    await asyncio.to_thread(_ipc, request.app.state.settings, {"action": "reload_mapping"})
    return {"ok": True}


@router.delete("/library/{lib_id}")
def delete_library_entry(lib_id: str, request: Request) -> dict:
    deleted = request.app.state.mapping_store.library_delete(lib_id)
    if not deleted:
        raise HTTPException(404, "Bibliothekseintrag nicht gefunden")
    return {"ok": True}


@router.post("/library/{lib_id}/assign")
async def assign_library_entry(lib_id: str, request: Request) -> dict:
    body = await request.json()
    uid = body.get("uid", "").upper().replace(":", "").replace(" ", "")
    if not uid:
        raise HTTPException(400, "uid fehlt")
    try:
        request.app.state.mapping_store.assign_to_card(uid, lib_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    cover_mod.invalidate(_cover_cache_dir(request), uid)
    await asyncio.to_thread(_ipc, request.app.state.settings, {"action": "reload_mapping"})
    return {"ok": True, "uid": uid}


@router.post("/control/{action}")
async def control_action(action: str, request: Request) -> dict:
    settings = request.app.state.settings
    body: dict = {}
    try:
        body = await request.json()
    except Exception:
        pass
    cmd = {"action": action, **body}
    ok = await asyncio.to_thread(_ipc, settings, cmd)
    return {"ok": ok}


# Playlists (und Artists) sind aus der freien Suche bewusst ausgeschlossen:
# Spotify verweigert seit November 2024 API-Zugriff auf Tracks fremder (nicht
# selbst erstellter/gefolgter) Playlists mit einem nichtssagenden 403
# Forbidden — die Suche würde sonst Ergebnisse anzeigen, die beim Antippen
# einfach nicht funktionieren. Playlists bleiben ausschließlich über "Meine
# Spotify-Bibliothek" erreichbar (current_user_playlists() liefert
# garantiert nur eigene/gefolgte, also funktionierende, Playlists).
_SEARCH_ALLOWED_TYPES = {"album", "track"}
_SEARCH_DEFAULT_TYPE = "album,track"


@router.get("/search")
async def spotify_search(q: str, request: Request, type: str = _SEARCH_DEFAULT_TYPE) -> Any:
    """Spotify-Suche via spotipy (synchron in Thread-Pool). Nur Song/Album —
    siehe _SEARCH_ALLOWED_TYPES. Serverseitig erzwungen, unabhängig davon,
    was der `type`-Parameter anfragt."""
    import spotipy

    requested = {t.strip() for t in type.split(",") if t.strip()}
    allowed = requested & _SEARCH_ALLOWED_TYPES
    search_type = ",".join(sorted(allowed)) if allowed else _SEARCH_DEFAULT_TYPE

    sp_oauth = request.app.state.sp_oauth
    try:
        sp = spotipy.Spotify(auth_manager=sp_oauth)
        results = await asyncio.to_thread(sp.search, q=q, type=search_type, limit=10)
        return results
    except Exception as e:
        raise HTTPException(503, f"Spotify-Suche fehlgeschlagen: {e}")


@router.get("/spotify/tracks")
async def spotify_tracks_batch(uris: str, request: Request) -> Any:
    """Track-Metadaten für eine Liste von Track-URIs (kommagetrennt) — für
    die Editor-Anzeige von spotify_queue-Karten, die selbst nur URIs
    speichern (siehe MappingStore)."""
    import spotipy

    ids = [u.strip() for u in uris.split(",") if u.strip()]
    if not ids:
        return {"items": []}
    # Spotify erlaubt maximal 50 IDs pro tracks()-Aufruf; kein Chunking nötig — die
    # Playlist-Bau-UI kennt keine Obergrenze, aber 50 Tracks sind für eine
    # Kinder-Hörspiel-Playlist bereits sehr großzügig.
    ids = ids[:50]

    sp_oauth = request.app.state.sp_oauth
    try:
        sp = spotipy.Spotify(auth_manager=sp_oauth)
        # Nicht sp.tracks(): Spotify sperrt den Sammel-Endpunkt mit 403, obwohl
        # das Token gilt — tracks_by_ids() weicht dann auf Einzelabrufe aus.
        res = await asyncio.to_thread(tracks_by_ids, sp, ids)
        items = []
        for t in res:
            if not t:
                continue
            items.append({
                "uri": t.get("uri", ""), "name": t.get("name", ""),
                "by": ", ".join(a["name"] for a in t.get("artists", [])),
                "image": _img(t.get("album", {}).get("images", [])),
            })
        return {"items": items}
    except spotipy.SpotifyException as e:
        if e.http_status in (401, 403):
            return JSONResponse({"items": [], "error": "reauth_required", "detail": str(e)})
        raise HTTPException(503, f"Spotify-Track-Abfrage fehlgeschlagen: {e}")
    except Exception as e:
        raise HTTPException(503, f"Spotify-Track-Abfrage fehlgeschlagen: {e}")


def _img(images: list) -> str:
    """Cover-URL, umgebogen auf den lokalen Spiegel (siehe spotify_images)."""
    return spotify_images.proxy_url(images[0]["url"]) if images else ""


@router.get("/spotify/library")
async def spotify_library(request: Request, type: str = "playlists",
                          limit: int = 20, offset: int = 0, nocache: int = 0) -> Any:
    """Eigene Spotify-Bibliothek, normalisiert: {items:[{uri,name,by,image}], next}."""
    import spotipy

    sp_oauth = request.app.state.sp_oauth
    sp = spotipy.Spotify(auth_manager=sp_oauth)

    def _fetch():
        items, nxt = [], None
        if type == "playlists":
            res = sp.current_user_playlists(limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            for p in res.get("items", []):
                if p:
                    items.append({"uri": p.get("uri", ""), "name": p.get("name", ""),
                                  "by": (p.get("owner") or {}).get("display_name", ""),
                                  "image": _img(p.get("images", []))})
        elif type == "tracks":
            res = sp.current_user_saved_tracks(limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            for it in res.get("items", []):
                t = (it or {}).get("track") or {}
                items.append({"uri": t.get("uri", ""), "name": t.get("name", ""),
                              "by": ", ".join(a["name"] for a in t.get("artists", [])),
                              "image": _img((t.get("album") or {}).get("images", []))})
        elif type == "albums":
            res = sp.current_user_saved_albums(limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            for it in res.get("items", []):
                a = (it or {}).get("album") or {}
                items.append({"uri": a.get("uri", ""), "name": a.get("name", ""),
                              "by": ", ".join(ar["name"] for ar in a.get("artists", [])),
                              "image": _img(a.get("images", []))})
        elif type == "artists":
            res = sp.current_user_followed_artists(limit=limit)
            block = res.get("artists", {}) if isinstance(res, dict) else {}
            nxt = bool(block.get("next"))
            for ar in block.get("items", []):
                if ar:
                    items.append({"uri": ar.get("uri", ""), "name": ar.get("name", ""),
                                  "by": "", "image": _img(ar.get("images", []))})
        else:
            raise ValueError(f"Unbekannter type: {type}")
        return {"items": items, "next": nxt}

    return await _cached_spotify(
        request,
        kind="library",
        params={"type": type, "limit": limit, "offset": offset},
        fetch=_fetch,
        nocache=bool(nocache),
        error_label="Spotify-Bibliothek nicht verfügbar",
    )


@router.get("/spotify/playlist_tracks")
async def spotify_playlist_tracks(request: Request, uri: str,
                                   limit: int = 50, offset: int = 0,
                                   nocache: int = 0) -> Any:
    """Tracks einer Spotify-Playlist/eines Albums, normalisiert wie /spotify/library:
    {items:[{uri,name,by,image}], next}. Für die Track-Ausschluss-UI im Zuweisen-Sheet."""
    import spotipy

    sp_oauth = request.app.state.sp_oauth
    sp = spotipy.Spotify(auth_manager=sp_oauth)

    def _fetch():
        items, nxt = [], None
        if uri.startswith("spotify:playlist:"):
            playlist_id = uri.split(":")[-1]
            if not re.fullmatch(r"[A-Za-z0-9]{22}", playlist_id):
                raise ValueError("Ungültige Spotify-ID")
            res = sp.playlist_items(playlist_id, limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            for it in res.get("items", []):
                t = track_of(it)
                if not t:
                    continue
                items.append({"uri": t.get("uri", ""), "name": t.get("name", ""),
                              "by": ", ".join(a["name"] for a in t.get("artists", [])),
                              "image": _img((t.get("album") or {}).get("images", []))})
        elif uri.startswith("spotify:album:"):
            album_id = uri.split(":")[-1]
            if not re.fullmatch(r"[A-Za-z0-9]{22}", album_id):
                raise ValueError("Ungültige Spotify-ID")
            res = sp.album_tracks(album_id, limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            cover = _img(sp.album(album_id).get("images", []))
            for t in res.get("items", []):
                if not t:
                    continue
                items.append({"uri": t.get("uri", ""), "name": t.get("name", ""),
                              "by": ", ".join(a["name"] for a in t.get("artists", [])),
                              "image": cover})
        else:
            raise ValueError(f"Kein Playlist-/Album-URI: {uri}")
        return {"items": items, "next": nxt}

    return await _cached_spotify(
        request,
        kind="playlist_tracks",
        params={"uri": uri, "limit": limit, "offset": offset},
        fetch=_fetch,
        nocache=bool(nocache),
        error_label="Spotify-Tracks nicht verfügbar",
    )


@router.get("/spotify/image")
async def spotify_image(request: Request, url: str) -> Response:
    """Spotify-Cover über den lokalen Spiegel ausliefern.

    Nur Spotifys eigene Bild-CDNs sind zugelassen — die URL kommt aus dem
    Query-Parameter, ein offener Proxy wäre sonst ein Einfallstor ins Heimnetz.
    """
    if not spotify_images.is_allowed(url):
        raise HTTPException(400, "Nur Spotify-Cover-URLs sind zugelassen")

    data = await asyncio.to_thread(spotify_images.get, _spotify_image_dir(request), url)
    if data is None:
        # Weder Spiegel noch Netz — neutraler Platzhalter, damit das Grid nicht
        # mit kaputten Bildern übersät ist. Bewusst ungecacht: sobald das Netz
        # wieder da ist, soll das echte Cover nachgeladen werden.
        return Response(cover_mod.placeholder_jpeg(), media_type="image/jpeg",
                        headers={"Cache-Control": "no-store"})

    media_type = "image/png" if data[:8] == b"\x89PNG\r\n\x1a\n" else "image/jpeg"
    # Cover-Bilder unter einer URL ändern sich nicht mehr → lange cachen.
    return Response(data, media_type=media_type,
                    headers={"Cache-Control": "public, max-age=2592000, immutable"})


@router.post("/spotify/cache/clear")
def spotify_cache_clear(request: Request) -> dict:
    """Metadaten- und Cover-Cache leeren — erzwingt frische Daten von Spotify."""
    return {
        "ok": True,
        "cleared": spotify_cache.clear(_spotify_cache_dir(request)),
        "cleared_images": spotify_images.clear(_spotify_image_dir(request)),
    }


@router.get("/spotify/me")
async def spotify_me(request: Request) -> Any:
    import spotipy

    sp_oauth = request.app.state.sp_oauth
    try:
        sp = spotipy.Spotify(auth_manager=sp_oauth)
        return await asyncio.to_thread(sp.me)
    except Exception as e:
        raise HTTPException(503, str(e))
