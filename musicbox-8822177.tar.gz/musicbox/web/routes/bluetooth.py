"""Bluetooth-API. Schreibende und lesende Aktionen laufen über den root-Helfer (sudo)."""

from __future__ import annotations

import asyncio
import json
import subprocess

from fastapi import APIRouter, HTTPException, Request

from musicbox.connectivity.bluetooth import validate_mac
from musicbox.web.routes.api import _ipc

router = APIRouter()
HELPER = "/opt/musicbox/scripts/bt_helper.sh"
_SCAN_SECONDS = 10


def _helper(cmd: str, *args: str) -> dict:
    try:
        r = subprocess.run(["sudo", "-n", HELPER, cmd, *args],
                           capture_output=True, text=True, timeout=60)
        out = (r.stdout or "").strip()
        return json.loads(out) if out else {"ok": r.returncode == 0}
    except Exception as e:
        return {"ok": False, "error": str(e)}


async def _mac_from(request: Request) -> str:
    body = await request.json()
    try:
        return validate_mac(body.get("mac", ""))
    except ValueError:
        raise HTTPException(400, "Ungültige Bluetooth-Adresse")


def _caps(request: Request) -> dict:
    st = request.app.state.settings_store
    st.reload_if_changed()
    return st.data.get("bt_devices", {})


@router.get("/api/bluetooth")
async def bt_status(request: Request) -> dict:
    res = await asyncio.to_thread(_helper, "list")
    caps = _caps(request)
    devices = [
        {**d, "max_volume": caps.get(d["mac"], {}).get("max_volume", 100)}
        for d in res.get("devices", [])
    ]
    connected = next((d for d in devices if d.get("connected")), None)
    return {"ok": res.get("ok", False), "devices": devices, "connected": connected}


@router.post("/api/bluetooth/scan")
async def bt_scan(request: Request) -> dict:
    return await asyncio.to_thread(_helper, "scan", "--seconds", str(_SCAN_SECONDS))


@router.post("/api/bluetooth/pair")
async def bt_pair(request: Request) -> dict:
    mac = await _mac_from(request)
    return await asyncio.to_thread(_helper, "pair", "--mac", mac)


@router.post("/api/bluetooth/connect")
async def bt_connect(request: Request) -> dict:
    mac = await _mac_from(request)
    return await asyncio.to_thread(_helper, "connect", "--mac", mac)


@router.post("/api/bluetooth/disconnect")
async def bt_disconnect(request: Request) -> dict:
    mac = await _mac_from(request)
    return await asyncio.to_thread(_helper, "disconnect", "--mac", mac)


@router.post("/api/bluetooth/forget")
async def bt_forget(request: Request) -> dict:
    mac = await _mac_from(request)
    res = await asyncio.to_thread(_helper, "forget", "--mac", mac)
    # Den gespeicherten Deckel nur entfernen, wenn das Gerät wirklich weg ist —
    # sonst verliert ein weiterhin gekoppelter Kopfhörer still seine Begrenzung.
    if res.get("ok"):
        st = request.app.state.settings_store
        st.reload_if_changed()
        devices = dict(st.data.get("bt_devices", {}))
        if devices.pop(mac, None) is not None:
            st.update({"bt_devices": devices})
    return res


@router.post("/api/bluetooth/max-volume")
async def bt_max_volume(request: Request) -> dict:
    mac = await _mac_from(request)
    body = await request.json()
    st = request.app.state.settings_store
    st.reload_if_changed()
    devices = dict(st.data.get("bt_devices", {}))
    devices[mac] = {"name": body.get("name", ""), "max_volume": body.get("max_volume", 100)}
    st.update({"bt_devices": devices})
    # Core sofort neu laden lassen — sonst greift der neue Deckel erst beim
    # periodischen Reload und wird auch dann nicht auf den Sink angewendet.
    await asyncio.to_thread(_ipc, request.app.state.settings, {"action": "reload_settings"})
    return {"ok": True}
