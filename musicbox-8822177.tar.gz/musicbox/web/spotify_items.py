"""Formwechsel und Sperren der Spotify-Web-API, an einer Stelle gebündelt.

Am 05.09.2026 gegen die echte API gemessen (Konto „Thomas"):

| Endpunkt                        | Ergebnis                                  |
|---------------------------------|-------------------------------------------|
| `/v1/playlists/{id}/items`      | 200, Titel unter `item` — kein `track`    |
| `/v1/playlists/{id}/tracks`     | **403**, auch bei eigenen Playlists       |
| `/v1/tracks?ids=…` (Batch)      | **403**                                   |
| `/v1/tracks/{id}` (einzeln)     | 200                                       |

Beides sieht von außen wie „Spotify ist kaputt" aus, ist es aber nicht: die
Daten kommen an, nur unter anderem Namen bzw. über einen anderen Endpunkt.
"""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)

# Prozessweit gemerkt: Spotify verweigert den Batch-Abruf. Nach dem ersten 403
# sparen wir uns den Fehlversuch bei jedem weiteren Aufruf.
_batch_gesperrt = False


def track_of(eintrag: dict | None) -> dict:
    """Titel eines Playlist-Eintrags, oder {} wenn keiner drinsteht.

    `GET /v1/playlists/{id}/items` liefert ihn unter `item`; der ältere
    Endpunkt `/tracks` nutzte `track` und antwortet inzwischen mit 403. Wer nur
    `track` liest, bekommt für jeden Eintrag `None` und zeigt eine leere
    Playlist an, obwohl `total` die richtige Anzahl nennt.

    Beide Schlüssel werden gelesen: Spotify hat die Form schon einmal
    geändert, und ältere Cache-Stände enthalten noch die alte.

    Achtung: Das Titel-Objekt selbst hat ebenfalls ein Feld `track` (ein
    Bool). Hier wird ausschließlich der *Eintrag* gelesen, nie der Titel.
    """
    eintrag = eintrag or {}
    return eintrag.get("item") or eintrag.get("track") or {}


def batch_zuruecksetzen() -> None:
    """Die gemerkte Batch-Sperre vergessen — für Tests."""
    global _batch_gesperrt
    _batch_gesperrt = False


def tracks_by_ids(sp, ids: list[str]) -> list[dict]:
    """Track-Objekte zu Spotify-IDs, in der Reihenfolge der Anfrage.

    Versucht weiter den Batch-Endpunkt — er ist bis zu 50-mal sparsamer, und
    Spotify kann die Sperre zurücknehmen — und schaltet nach einem 403 für die
    Laufzeit des Prozesses auf Einzelabrufe um.

    Ein 401 wird durchgereicht: ein abgelaufenes Token ist ein Anmeldefehler
    und darf nicht als Sperre missdeutet werden, sonst verschluckt der
    Einzelabruf-Pfad den Hinweis auf die nötige Neuanmeldung.

    Der Aufrufer teilt selbst in Blöcke zu höchstens 50 IDs — mehr nimmt
    Spotify pro Batch nicht an.
    """
    global _batch_gesperrt

    ids = list(ids)
    if not ids:
        return []

    batch_fehler = None
    if not _batch_gesperrt:
        try:
            antwort = sp.tracks(ids) or {}
            return [t for t in antwort.get("tracks", []) if t]
        except Exception as e:
            if getattr(e, "http_status", None) != 403:
                raise
            batch_fehler = e
            _batch_gesperrt = True
            log.info("Spotify verweigert den Batch-Abruf (403) — ab jetzt einzeln")

    ergebnis = []
    for kennung in ids:
        try:
            titel = sp.track(kennung)
        except Exception as e:
            if getattr(e, "http_status", None) == 401:
                raise
            # Einzelner Ausfall (gelöschter Titel, regional weg): überspringen
            # statt die ganze Trackliste zu verlieren.
            log.info("Titel %s nicht abrufbar: %s", kennung, e)
            continue
        if titel:
            ergebnis.append(titel)

    if batch_fehler is not None and not ergebnis:
        # Nicht jeder 403 ist die Sammel-Sperre: „Insufficient client scope"
        # trifft auch den Einzelabruf. Kam über beide Wege nichts an, war der
        # Batch nicht das Problem — dann muss der ursprüngliche Fehler sichtbar
        # bleiben, damit der Aufrufer zur Neuanmeldung führen kann.
        _batch_gesperrt = False
        raise batch_fehler

    return ergebnis
