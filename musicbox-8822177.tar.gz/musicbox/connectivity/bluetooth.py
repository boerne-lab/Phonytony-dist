"""Bluetooth-Verwaltung über bluetoothctl (testbar) + CLI für den root-Helfer.

Sicherheit: MAC-Adressen werden validiert und nie in eine Shell interpoliert,
sondern als eigene bluetoothctl-Argumente übergeben — analog zu maintenance/wifi.py.
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import shutil
import subprocess
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger(__name__)

_MAC_RE = re.compile(r"^([0-9A-F]{2}:){5}[0-9A-F]{2}$")
_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]")
_DEVICE_RE = re.compile(r"^Device\s+((?:[0-9A-F]{2}:){5}[0-9A-F]{2})\s*(.*)$")
_CMD_TIMEOUT = 30
_BT_STATE_DIR = "/var/lib/bluetooth"


def validate_mac(mac: str) -> str:
    """Normalisiert auf Großbuchstaben und prüft das Format. Wirft bei allem anderen."""
    norm = (mac or "").strip().upper()
    if not _MAC_RE.match(norm):
        raise ValueError("Ungültige Bluetooth-Adresse")
    return norm


def _clean(text: str) -> str:
    """Entfernt ANSI-Sequenzen und Steuerzeichen, die bluetoothctl beimischt."""
    return _ANSI_RE.sub("", text or "").replace("\r", "")


def parse_devices(out: str) -> list[dict]:
    """Parst Zeilen der Form 'Device AA:BB:CC:DD:EE:FF Name'."""
    devices = []
    for line in _clean(out).splitlines():
        m = _DEVICE_RE.match(line.strip())
        if m:
            devices.append({"mac": m.group(1), "name": m.group(2).strip()})
    return devices


def parse_info(out: str) -> dict:
    """Parst 'bluetoothctl info <MAC>' zu Name und Zustandsflags."""
    info = {"name": "", "paired": False, "trusted": False, "connected": False}
    for line in _clean(out).splitlines():
        key, _, value = line.strip().partition(":")
        value = value.strip()
        if key == "Name":
            info["name"] = value
        elif key in ("Paired", "Trusted", "Connected"):
            info[key.lower()] = value == "yes"
    return info


def _bt(*args: str, runner: Callable) -> tuple[bool, str]:
    """Führt bluetoothctl aus; gibt (Erfolg, Ausgabe) zurück."""
    try:
        r = runner(["bluetoothctl", *args], capture_output=True, text=True,
                   timeout=_CMD_TIMEOUT)
    except Exception as e:  # subprocess.TimeoutExpired o. ä.
        return False, str(e)
    out = ((getattr(r, "stdout", "") or "") + (getattr(r, "stderr", "") or "")).strip()
    ok = getattr(r, "returncode", 0) == 0 and "Failed" not in out
    return ok, out


def _macs(out: str) -> set:
    return {d["mac"] for d in parse_devices(out)}


def scan(seconds: int = 10, *, runner: Callable = subprocess.run) -> dict:
    """Sucht `seconds` Sekunden nach Geräten und liefert alle bekannten Geräte.

    Scheitert eine der Abfragen, wird `ok: False` gemeldet — eine leere Liste
    wäre von "keine Geräte gefunden" nicht zu unterscheiden.
    """
    _bt("--timeout", str(int(seconds)), "scan", "on", runner=runner)
    ok_all, all_out = _bt("devices", runner=runner)
    ok_paired, paired_out = _bt("devices", "Paired", runner=runner)
    ok_conn, conn_out = _bt("devices", "Connected", runner=runner)
    if not (ok_all and ok_paired and ok_conn):
        return {"ok": False, "devices": []}
    paired, conn = _macs(paired_out), _macs(conn_out)
    devices = [
        {**d, "paired": d["mac"] in paired, "connected": d["mac"] in conn}
        for d in parse_devices(all_out)
    ]
    return {"ok": True, "devices": devices}


def list_devices(*, runner: Callable = subprocess.run) -> dict:
    """Nur die gekoppelten Geräte samt Vertrauens- und Verbindungszustand.

    `trusted` sagt, ob die Box das Gerät von sich aus wieder verbinden darf.
    Scheitert eine der Abfragen, wird `ok: False` gemeldet (siehe `scan`).
    """
    ok_paired, paired_out = _bt("devices", "Paired", runner=runner)
    ok_trusted, trusted_out = _bt("devices", "Trusted", runner=runner)
    ok_conn, conn_out = _bt("devices", "Connected", runner=runner)
    if not (ok_paired and ok_trusted and ok_conn):
        return {"ok": False, "devices": []}
    trusted, conn = _macs(trusted_out), _macs(conn_out)
    devices = [
        {**d, "paired": True, "trusted": d["mac"] in trusted,
         "connected": d["mac"] in conn}
        for d in parse_devices(paired_out)
    ]
    return {"ok": True, "devices": devices}


def connected(*, runner: Callable = subprocess.run) -> dict:
    """Das aktuell verbundene Gerät (erstes) oder None.

    Wichtig: Bei einem fehlgeschlagenen Aufruf (Rückgabecode ≠ 0, "Failed" in der
    Ausgabe, Timeout oder D-Bus-Fehler während eines bluetoothd-Neustarts) wird
    `ok: False` gemeldet. Sonst sähe der Fehler wie "kein Kopfhörer verbunden"
    aus und der Ton spränge zurück auf den Lautsprecher.
    """
    ok, out = _bt("devices", "Connected", runner=runner)
    if not ok:
        return {"ok": False, "device": None}
    found = parse_devices(out)
    return {"ok": True, "device": found[0] if found else None}


def pair(mac: str, *, runner: Callable = subprocess.run) -> dict:
    """Koppeln, dauerhaft vertrauen und verbinden — eine Aktion für die Oberfläche.

    `trust` sorgt dafür, dass sich der Kopfhörer nach dem Einschalten selbst
    wieder verbindet, ohne dass jemand die Weboberfläche öffnen muss.
    """
    mac = validate_mac(mac)
    for args in (("pair", mac), ("trust", mac), ("connect", mac)):
        ok, out = _bt(*args, runner=runner)
        if not ok:
            return {"ok": False, "error": out}
    return {"ok": True, "error": None}


def _simple(action: str, mac: str, runner: Callable) -> dict:
    mac = validate_mac(mac)
    ok, out = _bt(action, mac, runner=runner)
    return {"ok": ok, "error": None if ok else out}


def connect(mac: str, *, runner: Callable = subprocess.run) -> dict:
    return _simple("connect", mac, runner)


def disconnect(mac: str, *, runner: Callable = subprocess.run) -> dict:
    return _simple("disconnect", mac, runner)


def _forget_link_key(mac: str, *, bt_dir: str = _BT_STATE_DIR) -> None:
    """Räumt den Link-Key-Ordner unter /var/lib/bluetooth auf, den `bluetoothctl
    remove` auf mancher Hardware stehen lässt.

    Bleibt der Ordner übrig, scheitert jede neue Kopplung dauerhaft mit
    org.bluez.Error.AuthenticationFailed (Box und Kopfhörer haben dann
    unterschiedliche Schlüssel). Die Adapter-MAC steht nicht fest, sondern
    ergibt sich aus den vorhandenen Adapter-Verzeichnissen unter `bt_dir`.
    Rein bestmöglich: fehlt der Ordner oder scheitert das Löschen (Rechte,
    Pfad fehlt), wird das nur geloggt — `forget` bleibt beim Ergebnis von
    `bluetoothctl remove`.
    """
    base = Path(bt_dir)
    try:
        adapter_dirs = [p for p in base.iterdir() if p.is_dir()]
    except OSError as e:
        log.debug("Bluetooth-Zustandsverzeichnis %s nicht lesbar: %s", base, e)
        return
    for adapter_dir in adapter_dirs:
        device_dir = adapter_dir / mac
        if not device_dir.is_dir():
            continue
        try:
            shutil.rmtree(device_dir)
            log.info("Link-Key-Rest für %s unter %s entfernt", mac, device_dir)
        except OSError as e:
            log.warning("Link-Key-Rest für %s unter %s konnte nicht entfernt "
                        "werden: %s", mac, device_dir, e)


def forget(mac: str, *, runner: Callable = subprocess.run,
           bt_dir: str = _BT_STATE_DIR) -> dict:
    mac = validate_mac(mac)
    res = _simple("remove", mac, runner)
    _forget_link_key(mac, bt_dir=bt_dir)
    return res


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sc = sub.add_parser("scan"); sc.add_argument("--seconds", type=int, default=10)
    sub.add_parser("list")
    sub.add_parser("status")
    for name in ("pair", "connect", "disconnect", "forget"):
        p = sub.add_parser(name); p.add_argument("--mac", required=True)
    args = ap.parse_args(argv)
    try:
        if args.cmd == "scan":
            res = scan(args.seconds)
        elif args.cmd == "list":
            res = list_devices()
        elif args.cmd == "status":
            res = connected()
        else:
            res = {"pair": pair, "connect": connect,
                   "disconnect": disconnect, "forget": forget}[args.cmd](args.mac)
    except ValueError as e:
        res = {"ok": False, "error": str(e)}
    print(json.dumps(res))
    return 0 if res.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
