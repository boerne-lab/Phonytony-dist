"""Lokale M3U8-Titel lesen, ohne die vollständige Playlist zu verändern."""

from pathlib import Path


def playlist_tracks(ref: str, music_dir: Path) -> list[str]:
    """Dateipfade relativ zu music_dir; fremde absolute Pfade bleiben absolut.

    Relative M3U-Einträge beziehen sich auf den Ordner der Playlist.
    Kommentare und Leerzeilen gehören nicht zur Titelliste.
    """
    music_dir = Path(music_dir).resolve()
    playlist = Path(ref)
    if not playlist.is_absolute():
        playlist = music_dir / playlist
    tracks = []
    for line in playlist.read_text().splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        path = Path(line)
        if not path.is_absolute():
            path = playlist.parent / path
        path = path.resolve()
        tracks.append(str(path.relative_to(music_dir))
                      if path.is_relative_to(music_dir) else str(path))
    return tracks
