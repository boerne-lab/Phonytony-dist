"""StateStore: Laufzeit-Zustand (Volume, Resume-Positionen). Atomisches Schreiben."""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class State:
    volume: int = 75
    active_uid: Optional[str] = None
    active_backend: Optional[str] = None
    last_scanned_uid: Optional[str] = None  # zuletzt gescannte UID (auch unbekannte) für Web-Zuordnung
    last_scanned_at: float = 0.0            # Zeitstempel des letzten Scans (zählt bei jedem Auflegen hoch)
    present_uid: Optional[str] = None       # Karte, die GERADE aufliegt (None wenn keine) — fürs Web-Onboarding
    output_mode: str = "both"               # aktiver Audio-Ausgang: both | speaker | headphone | bluetooth
    wired_output_mode: str = "both"         # letzter kabelgebundener Ausgang (Rückfall beim Trennen)
    bt_device_mac: Optional[str] = None     # verbundener Bluetooth-Kopfhörer
    bt_device_name: Optional[str] = None
    resume_positions: dict = field(default_factory=dict)
    queue_resume: dict = field(default_factory=dict)  # uid -> {"index": int, "position_ms": int}
    last_updated: float = field(default_factory=time.time)


class StateStore:
    def __init__(self, path: Path) -> None:
        self._path = path
        self._state = State()

    def load(self) -> State:
        if self._path.exists():
            try:
                raw = json.loads(self._path.read_text())
                self._state = State(
                    volume=raw.get("volume", 75),
                    active_uid=raw.get("active_uid"),
                    active_backend=raw.get("active_backend"),
                    last_scanned_uid=raw.get("last_scanned_uid"),
                    last_scanned_at=raw.get("last_scanned_at", 0.0),
                    present_uid=raw.get("present_uid"),
                    output_mode=raw.get("output_mode", "both"),
                    wired_output_mode=raw.get("wired_output_mode", "both"),
                    bt_device_mac=raw.get("bt_device_mac"),
                    bt_device_name=raw.get("bt_device_name"),
                    resume_positions=raw.get("resume_positions", {}),
                    queue_resume=raw.get("queue_resume", {}),
                    last_updated=raw.get("last_updated", 0.0),
                )
            except (json.JSONDecodeError, KeyError):
                self._state = State()
        return self._state

    def save(self, state: Optional[State] = None) -> None:
        if state is not None:
            self._state = state
        self._state.last_updated = time.time()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(self._state), indent=2))
        os.replace(tmp, self._path)

    @property
    def state(self) -> State:
        return self._state

    def update_resume(self, uid: str, position_ms: int) -> None:
        self._state.resume_positions[uid] = position_ms
        self.save()

    def get_resume(self, uid: str) -> int:
        return self._state.resume_positions.get(uid, 0)

    def update_queue_resume(self, uid: str, index: int, position_ms: int) -> None:
        self._state.queue_resume[uid] = {"index": index, "position_ms": position_ms}
        self.save()

    def get_queue_resume(self, uid: str) -> tuple[int, int]:
        entry = self._state.queue_resume.get(uid, {})
        return entry.get("index", 0), entry.get("position_ms", 0)

    def set_volume(self, volume: int) -> None:
        self._state.volume = max(0, min(100, volume))
        self.save()
