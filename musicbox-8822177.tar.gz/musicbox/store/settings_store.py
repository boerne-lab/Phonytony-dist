"""SettingsStore: benutzer-editierbare Einstellungen (settings.json), live nachladbar.

Wird vom Core gelesen (Reload-Schleife) und vom Web geschrieben — analog zu
MappingStore. Defaults sind so gewählt, dass sich ohne Konfiguration nur das
gewünschte neue Verhalten ergibt (Karte entfernen = weiterspielen).
"""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path

# Aktionen, die einer Knopf-Geste zugeordnet werden können
VALID_ACTIONS = {
    "play_pause", "next", "prev", "vol_up", "vol_down", "toggle_output",
    "bluetooth_toggle", "none",
}
_VALID_CARD_REMOVED = {"continue", "pause"}
VALID_EQ = {"off", "bass", "speech", "treble", "loudness"}
_VALID_SLEEP_TIMER_MIN = {15, 30, 45, 60}
_VALID_IDLE_SHUTDOWN_MIN = {30, 60, 120, 240}

DEFAULTS: dict = {
    "card_removed": "continue",                      # was tun, wenn Karte abgenommen wird
    "max_volume": {"Headphone": 100, "Speaker": 100},  # Deckel pro Ausgang
    "bt_devices": {},                                # MAC -> {"name", "max_volume"}: Deckel je Kopfhörer
    "eq_preset": "off",                              # Equalizer (lokale Wiedergabe), Standard aus
    "min_volume": 0,                                 # globale Mindestlautstärke (0 = aus)
    # Lautstärke der Warntöne, unabhängig von der Musik. Sie kamen bisher immer
    # mit vollem Pegel — im Kinderzimmer der unangenehmste Ton im Gerät.
    # 0 = stumm.
    "feedback_volume": 50,
    "auto_update": True,                             # wöchentliches Auto-Update (pro Box abschaltbar)
    "trim_silence": True,                            # Anfangsstille beim Upload entfernen
    "sleep_timer_enabled": False,   # Einschlaf-Timer: global aus/an
    "sleep_timer_min": 30,          # Minuten bis Fade+Pause, wenn aktiv
    "idle_shutdown_enabled": True,  # Auto-Shutdown nach Inaktivität
    "idle_shutdown_min": 60,        # Minuten ohne Wiedergabe/Bedienung bis Shutdown
    "offline_scan_enabled": True,   # Offline-Abgleich nach Upload und im Leerlauf
    "buttons": {                                      # GPIO 17 / 27 / 22
        "btn1": {"short": "play_pause", "long": "none"},
        "btn2": {"short": "next",       "long": "none"},
        "btn3": {"short": "prev",       "long": "none"},
        "btn4": {"short": "play_pause", "long": "toggle_output"},  # Drehregler-Knopf (GPIO 25)
    },
}


class SettingsStore:
    def __init__(self, path: Path) -> None:
        self._path = path
        self._data = copy.deepcopy(DEFAULTS)
        self._mtime = 0.0

    def load(self) -> None:
        if not self._path.exists():
            self._save()
            return
        try:
            raw = json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError):
            raw = {}
        self._data = self._merge(raw)
        try:
            self._mtime = self._path.stat().st_mtime
        except OSError:
            pass

    def reload_if_changed(self) -> bool:
        try:
            mtime = self._path.stat().st_mtime
        except FileNotFoundError:
            return False
        if mtime > self._mtime:
            self.load()
            return True
        return False

    def _merge(self, raw: dict) -> dict:
        """Validiert raw gegen die Defaults; unbekannte/ungültige Werte werden ersetzt."""
        d = copy.deepcopy(DEFAULTS)
        if raw.get("card_removed") in _VALID_CARD_REMOVED:
            d["card_removed"] = raw["card_removed"]
        if raw.get("eq_preset") in VALID_EQ:
            d["eq_preset"] = raw["eq_preset"]
        mvol = raw.get("min_volume")
        if isinstance(mvol, (int, float)) and not isinstance(mvol, bool):
            d["min_volume"] = max(0, min(100, int(mvol)))
        fvol = raw.get("feedback_volume")
        if isinstance(fvol, (int, float)) and not isinstance(fvol, bool):
            d["feedback_volume"] = max(0, min(100, int(fvol)))
        au = raw.get("auto_update")
        if isinstance(au, bool):
            d["auto_update"] = au
        ts = raw.get("trim_silence")
        if isinstance(ts, bool):
            d["trim_silence"] = ts
        ste = raw.get("sleep_timer_enabled")
        if isinstance(ste, bool):
            d["sleep_timer_enabled"] = ste
        stm = raw.get("sleep_timer_min")
        if stm in _VALID_SLEEP_TIMER_MIN:
            d["sleep_timer_min"] = stm
        ise = raw.get("idle_shutdown_enabled")
        if isinstance(ise, bool):
            d["idle_shutdown_enabled"] = ise
        ism = raw.get("idle_shutdown_min")
        if ism in _VALID_IDLE_SHUTDOWN_MIN:
            d["idle_shutdown_min"] = ism
        ose = raw.get("offline_scan_enabled")
        if isinstance(ose, bool):
            d["offline_scan_enabled"] = ose
        mv = raw.get("max_volume") or {}
        for ctrl in d["max_volume"]:
            v = mv.get(ctrl)
            if isinstance(v, (int, float)):
                d["max_volume"][ctrl] = max(0, min(100, int(v)))
        btns = raw.get("buttons") or {}
        for b in d["buttons"]:
            cfg = btns.get(b) or {}
            for press in ("short", "long"):
                if cfg.get(press) in VALID_ACTIONS:
                    d["buttons"][b][press] = cfg[press]
        # bt_devices ist — anders als die übrigen Defaults — ein OFFENES Dictionary:
        # die Schlüssel kommen aus raw (gekoppelte Geräte), nicht aus DEFAULTS.
        from musicbox.connectivity.bluetooth import validate_mac
        for mac, cfg in (raw.get("bt_devices") or {}).items():
            try:
                key = validate_mac(mac)
            except ValueError:
                continue
            if not isinstance(cfg, dict):
                continue
            vol = cfg.get("max_volume", 100)
            if not isinstance(vol, (int, float)) or isinstance(vol, bool):
                vol = 100
            d["bt_devices"][key] = {
                "name": str(cfg.get("name", ""))[:64],
                "max_volume": max(0, min(100, int(vol))),
            }
        return d

    @property
    def data(self) -> dict:
        return copy.deepcopy(self._data)

    def update(self, new: dict) -> dict:
        """Übernimmt (validiert) Felder aus new und speichert."""
        merged = {**self._data, **(new or {})}
        self._data = self._merge(merged)
        self._save()
        return self.data

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._data, indent=2, ensure_ascii=False))
        os.replace(tmp, self._path)
        try:
            self._mtime = self._path.stat().st_mtime
        except OSError:
            pass
