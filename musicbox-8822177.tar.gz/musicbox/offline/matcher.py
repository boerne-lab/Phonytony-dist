"""Matcher: welche Spotify-Tracks liegen als Datei auf der Box?

Reine Funktion — keine Dateizugriffe, kein Netz, keine Uhrzeit. Das macht die
Regeln einzeln prüfbar, und genau darauf kommt es an: eine falsche Zuordnung
fällt erst auf, wenn das Kind ein anderes Lied hört.

Drei Bewertungen je Track:
  sure     — eindeutig diese Datei
  unsure   — wahrscheinlich, aber nicht sicher: wird der Nutzerin vorgelegt
  missing  — nicht vorhanden
Dazu excluded für Tracks, die lokal von der Wiedergabe ausgeschlossen sind.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Optional

from .fingerprint import normalize
from .index import OfflineIndex

# Ab hier gilt ein Titel überhaupt als Kandidat …
_CANDIDATE_TITLE = 0.80
# … ab hier wird er der Nutzerin als Vorschlag vorgelegt …
_SUGGEST_TITLE = 0.85
# … und so ähnlich muss der Künstler für einen sicheren Treffer sein.
_SURE_ARTIST = 0.90
# Zulässige Abweichung der Spieldauer in Sekunden.
_DURATION_TOLERANCE = 3.0

_ZAHLEN = re.compile(r"\d+")


@dataclass(frozen=True)
class TrackMatch:
    uri: str
    name: str
    by: str
    status: str                       # sure | unsure | missing | excluded
    path: Optional[str] = None
    candidates: list = field(default_factory=list)
    score: float = 0.0


@dataclass(frozen=True)
class MatchResult:
    tracks: list
    complete: bool


def match(spotify_tracks: list, idx: OfflineIndex, *, excluded_uris: set) -> MatchResult:
    """Bewertet jeden Spotify-Track gegen den Index; Reihenfolge bleibt erhalten."""
    roh: list[dict] = []
    for track in spotify_tracks:
        uri = track.get("uri", "")
        eintrag = {
            "uri": uri,
            "name": track.get("name", ""),
            "by": track.get("by", ""),
        }
        if uri in excluded_uris:
            eintrag["status"] = "excluded"
        else:
            eintrag.update(_bewerte(track, idx))
        roh.append(eintrag)

    _entwirre_doppelte_dateien(roh)

    tracks = [TrackMatch(uri=e["uri"], name=e["name"], by=e["by"], status=e["status"],
                         path=e.get("path"), candidates=e.get("candidates", []),
                         score=e.get("score", 0.0))
              for e in roh]

    spielbar = [t for t in tracks if t.status != "excluded"]
    complete = bool(spielbar) and all(t.status == "sure" for t in spielbar)
    return MatchResult(tracks=tracks, complete=complete)


def _bewerte(track: dict, idx: OfflineIndex) -> dict:
    uri = track.get("uri", "")

    # Eine bestätigte Zuordnung überstimmt jede Heuristik — solange die Datei da ist.
    bestätigt = idx.confirmed.get(uri)
    if bestätigt and bestätigt in idx.files:
        return {"status": "sure", "path": bestätigt, "score": 1.0, "candidates": []}

    titel = normalize(track.get("name", ""))
    künstler = normalize(track.get("by", ""))
    dauer = _sekunden(track.get("duration_ms"))
    abgelehnt = set(idx.rejected.get(uri, []))

    kandidaten: list[dict] = []
    for pfad, eintrag in idx.files.items():
        if pfad in abgelehnt:
            continue
        datei_titel = eintrag.get("title", "")
        if not _zahlen_passen(titel, datei_titel):
            continue
        t_score = _aehnlich(titel, datei_titel, _CANDIDATE_TITLE)
        if t_score < _CANDIDATE_TITLE:
            continue
        a_score = _aehnlich(künstler, eintrag.get("artist", ""))
        kandidaten.append({
            "pfad": pfad,
            "titel": t_score,
            "gesamt": _gesamtscore(t_score, a_score, dauer, eintrag.get("duration_s")),
            "sicher": (t_score >= 1.0 and a_score >= _SURE_ARTIST
                       and _dauer_passt(dauer, eintrag.get("duration_s"))),
        })

    sichere = [(k["gesamt"], k["pfad"]) for k in kandidaten if k["sicher"]]

    if len(sichere) == 1:
        gesamt, pfad = sichere[0]
        return {"status": "sure", "path": pfad, "score": gesamt, "candidates": []}
    if len(sichere) > 1:
        # Mehrere gleich gute Treffer: nicht raten, sondern fragen.
        return {"status": "unsure", "path": None, "candidates": sorted(p for _, p in sichere),
                "score": max(g for g, _ in sichere)}

    vorschläge = [(k["gesamt"], k["pfad"]) for k in kandidaten if k["titel"] >= _SUGGEST_TITLE]
    if vorschläge:
        vorschläge.sort(reverse=True)
        return {"status": "unsure", "path": None,
                "candidates": [p for _, p in vorschläge], "score": vorschläge[0][0]}

    return {"status": "missing", "path": None, "candidates": [], "score": 0.0}


def _entwirre_doppelte_dateien(roh: list) -> None:
    """Eine Datei kann nur einem Track als sicherer Treffer dienen.

    Ohne diese Regel würde eine einzige Datei, die zufällig auf zwei Titel passt,
    eine ganze Playlist als vollständig erscheinen lassen."""
    belegung: dict[str, int] = {}   # pfad -> Index des bisher besten Tracks
    for i, eintrag in enumerate(roh):
        if eintrag.get("status") != "sure":
            continue
        pfad = eintrag["path"]
        bisher = belegung.get(pfad)
        if bisher is None:
            belegung[pfad] = i
            continue
        verlierer = i if roh[bisher]["score"] >= eintrag["score"] else bisher
        gewinner = bisher if verlierer == i else i
        belegung[pfad] = gewinner
        roh[verlierer].update(status="unsure", path=None, candidates=[pfad])


def _aehnlich(a: str, b: str, schwelle: float = 0.0) -> float:
    """Ähnlichkeit zweier normalisierter Texte (0..1).

    Mit ``schwelle`` werden aussichtslose Paare früh verworfen: Der volle
    Vergleich ist teuer und läuft für jede Datei gegen jeden Track. Die Box
    hat einige hundert Dateien und der Pi Zero wenig Rechenkraft — ohne diese
    Abkürzung dauert ein Abgleich Minuten statt Sekunden."""
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    vergleich = SequenceMatcher(None, a, b)
    if schwelle:
        # real_quick_ratio und quick_ratio sind obere Schranken von ratio und
        # kosten fast nichts (Längen- bzw. Zeichenvergleich).
        if vergleich.real_quick_ratio() < schwelle or vergleich.quick_ratio() < schwelle:
            return 0.0
    return vergleich.ratio()


def _zahlen_passen(a: str, b: str) -> bool:
    """Zahlen in Titeln sind bedeutungstragend: "Kapitel 1" und "Kapitel 2"
    unterscheiden sich für ein Ähnlichkeitsmaß kaum, für ein Hörbuch aber
    vollständig. Enthalten beide Titel Zahlen, müssen sie übereinstimmen;
    fehlt die Zahl auf einer Seite, bleibt es beim reinen Textvergleich."""
    zahlen_a = [int(z) for z in _ZAHLEN.findall(a)]
    zahlen_b = [int(z) for z in _ZAHLEN.findall(b)]
    if not zahlen_a or not zahlen_b:
        return True
    return zahlen_a == zahlen_b


def _sekunden(duration_ms) -> Optional[float]:
    if isinstance(duration_ms, (int, float)) and duration_ms > 0:
        return float(duration_ms) / 1000.0
    return None


def _dauer_passt(spotify_s: Optional[float], datei_s) -> bool:
    """Unbekannte Dauer auf einer der beiden Seiten hebt die Bedingung auf —
    nicht jede Datei liefert eine verlässliche Länge."""
    if spotify_s is None or not isinstance(datei_s, (int, float)):
        return True
    return abs(spotify_s - float(datei_s)) <= _DURATION_TOLERANCE


def _gesamtscore(t_score: float, a_score: float, spotify_s, datei_s) -> float:
    """Titel zählt am schwersten, dann der Künstler, dann die Dauergenauigkeit."""
    score = t_score * 0.6 + a_score * 0.3
    if spotify_s is None or not isinstance(datei_s, (int, float)):
        return score + 0.05
    abweichung = abs(spotify_s - float(datei_s))
    return score + 0.1 * max(0.0, 1.0 - abweichung / _DURATION_TOLERANCE)
