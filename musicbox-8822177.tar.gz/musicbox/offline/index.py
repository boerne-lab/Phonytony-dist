"""Fingerabdruck-Index über die lokalen Musikordner — persistent und inkrementell.

Der Abgleich vergleicht Spotify-Tracklisten gegen die Dateien auf der Box. Die
Tags jedes Mal neu zu lesen wäre auf dem Pi Zero spürbar, deshalb liegen die
Fingerabdrücke in ``offline_index.json`` und werden nur für Dateien erneuert,
deren mtime oder Größe sich geändert hat.

Neben den Fingerabdrücken hält der Index die Entscheidungen der Nutzerin:
``confirmed`` (dieser Track IST diese Datei) und ``rejected`` (diese Datei
gehört nicht zu diesem Track) — beides überstimmt die Heuristik.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

from . import fingerprint as _fp

log = logging.getLogger(__name__)

CATEGORIES = ("musik", "hoerbuch")
_AUDIO_SUFFIXES = {".mp3", ".flac", ".ogg", ".m4a"}


@dataclass
class OfflineIndex:
    files: dict = field(default_factory=dict)
    confirmed: dict = field(default_factory=dict)   # track-uri -> relativer Pfad
    rejected: dict = field(default_factory=dict)    # track-uri -> [relative Pfade]
    suggestions: dict = field(default_factory=dict)  # key -> offene unsichere Treffer
    last_run: dict = field(default_factory=dict)


def load(path: Path) -> OfflineIndex:
    """Index aus der Datei. Fehlt sie oder ist sie kaputt, beginnt er leer —
    ein verlorener Index kostet nur einen Neuaufbau, kein Datenverlust."""
    try:
        raw = json.loads(Path(path).read_text())
    except (OSError, json.JSONDecodeError):
        return OfflineIndex()
    if not isinstance(raw, dict):
        return OfflineIndex()
    return OfflineIndex(
        files=raw.get("files") or {},
        confirmed=raw.get("confirmed") or {},
        rejected=raw.get("rejected") or {},
        suggestions=raw.get("suggestions") or {},
        last_run=raw.get("last_run") or {},
    )


def save(path: Path, index: OfflineIndex) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": 1,
        "files": index.files,
        "confirmed": index.confirmed,
        "rejected": index.rejected,
        "suggestions": index.suggestions,
        "last_run": index.last_run,
    }
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False))
    os.replace(tmp, path)


def rebuild(music_dir: Path, index: OfflineIndex) -> int:
    """Index gegen den Ordnerinhalt fortschreiben; liefert die Anzahl neu
    gelesener Dateien. Unveränderte Dateien werden nicht angefasst."""
    music_dir = Path(music_dir)
    gesehen: set[str] = set()
    neu = 0

    for kategorie in CATEGORIES:
        ordner = music_dir / kategorie
        if not ordner.is_dir():
            continue
        for datei in sorted(ordner.iterdir()):
            if not datei.is_file() or datei.suffix.lower() not in _AUDIO_SUFFIXES:
                continue
            rel = f"{kategorie}/{datei.name}"
            gesehen.add(rel)
            try:
                stat = datei.stat()
            except OSError:
                continue
            alt = index.files.get(rel)
            if alt and alt.get("mtime") == stat.st_mtime and alt.get("size") == stat.st_size:
                continue
            fp = _read_fingerprint(datei, rel)
            index.files[rel] = {
                "mtime": stat.st_mtime,
                "size": stat.st_size,
                "title": fp.title,
                "artist": fp.artist,
                "album": fp.album,
                "duration_s": fp.duration_s,
                "source": fp.source,
            }
            neu += 1

    for rel in [p for p in index.files if p not in gesehen]:
        del index.files[rel]
    # Bestätigungen auf verschwundene Dateien sind wertlos; Ablehnungen bleiben,
    # denn kommt die Datei zurück, war sie immer noch die falsche.
    for uri in [u for u, p in index.confirmed.items() if p not in index.files]:
        del index.confirmed[uri]

    return neu


def confirm(index: OfflineIndex, uri: str, path: str) -> None:
    index.confirmed[uri] = path
    übrig = [p for p in index.rejected.get(uri, []) if p != path]
    if übrig:
        index.rejected[uri] = übrig
    else:
        index.rejected.pop(uri, None)


def reject(index: OfflineIndex, uri: str, path: str) -> None:
    pfade = index.rejected.setdefault(uri, [])
    if path not in pfade:
        pfade.append(path)
    if index.confirmed.get(uri) == path:
        del index.confirmed[uri]
    drop_suggestion(index, uri, path)


def drop_suggestion(index: OfflineIndex, uri: str, path: str = "") -> None:
    """Einen erledigten Vorschlag aus der offenen Liste nehmen.

    Ohne Pfad verschwindet der ganze Track, sonst nur dieser eine Kandidat."""
    for key in list(index.suggestions):
        eintrag = index.suggestions[key]
        tracks = []
        for track in eintrag.get("tracks", []):
            if track.get("uri") != uri:
                tracks.append(track)
                continue
            if not path:
                continue
            übrig = [p for p in track.get("candidates", []) if p != path]
            if übrig:
                tracks.append({**track, "candidates": übrig})
        if tracks:
            index.suggestions[key] = {**eintrag, "tracks": tracks}
        else:
            del index.suggestions[key]


def _read_fingerprint(abs_path: Path, rel_path: str):
    """Eigene Funktion, damit Tests das Tag-Lesen ersetzen können."""
    return _fp.read(abs_path, rel_path)
