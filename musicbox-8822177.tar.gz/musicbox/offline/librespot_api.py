"""Download-Auskunft von own-librespot abholen.

Der Fork führt einen Index darüber, welche Datei er für welche Track-URI
geschrieben hat. Diese Auskunft ist verlässlich — sie ersetzt für geholte
Dateien den Fuzzy-Vergleich, der raten muss.

Jeder Fehler führt zu ``None``: Läuft noch die alte Software, ist der Dienst
gerade aus oder antwortet er unerwartet, verhält sich der Abgleich wie bisher.
Ein Ausfall dieser Schnittstelle darf nie eine Karte umstellen oder
zurückschalten.
"""

from __future__ import annotations

import logging
from typing import Optional

import httpx

log = logging.getLogger(__name__)


async def downloads(base_url: str, *, timeout: float = 5.0) -> Optional[dict]:
    """``{"dir": str, "tracks": {uri: {rank, path, size, at}}}`` oder None.

    Einträge ohne ``path`` fallen weg: Das sind Alt-Einträge des Forks, die nur
    den Rang kennen — einzuräumen ist an ihnen nichts.
    """
    url = base_url.rstrip("/") + "/downloads"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            antwort = await client.get(url)
        if antwort.status_code == 404:
            log.debug("own-librespot kennt /downloads nicht (ältere Fassung)")
            return None
        antwort.raise_for_status()
        daten = antwort.json()
    except Exception as e:
        log.debug("Download-Auskunft nicht verfügbar: %s", e)
        return None

    if not isinstance(daten, dict):
        log.debug("Unerwartete Antwort auf /downloads: %s", type(daten).__name__)
        return None

    roh = daten.get("tracks")
    tracks = {}
    if isinstance(roh, dict):
        for uri, eintrag in roh.items():
            if isinstance(eintrag, dict) and eintrag.get("path"):
                tracks[uri] = eintrag

    return {"dir": str(daten.get("dir") or ""), "tracks": tracks}


# ── Hol-Vorgang ────────────────────────────────────────────────────────────
#
# own-librespot kann Titel auch ohne Wiedergabe holen. Die Schnittstelle:
#   POST   /downloads/fetch  {uris, bitrate, force}  → 202 + Anfangsstand
#   GET    /downloads/fetch                          → Stand
#   DELETE /downloads/fetch                          → bricht ab
#
# Antwortcodes des Forks: 409 ein Vorgang läuft schon, 204 keine Spotify-Sitzung,
# 422 Export abgeschaltet oder leere Liste. Die Sitzungsprüfung greift **vor** der
# Inhaltsprüfung — eine leere Liste ohne Sitzung ergibt 204, nicht 422.

_LEERER_STAND = {"running": False, "total": 0, "done": 0, "current": "",
                 "cancelled": False, "failures": [], "stopped_reason": ""}


async def fetch_start(base_url: str, uris: list, *, bitrate: int = 320,
                      timeout: float = 10.0) -> dict:
    """Startet den Hol-Vorgang. Liefert {ok, status, reason}.

    ``force`` ist dauerhaft gesetzt: Nach dem Einräumen liegt die Datei nicht
    mehr im Download-Ordner, der Index des Forks hält sie aber für vorhanden.
    Was der Box wirklich fehlt, hat sie ohnehin selbst bestimmt, bevor sie
    diese Liste schickt.
    """
    url = base_url.rstrip("/") + "/downloads/fetch"
    körper = {"uris": list(uris), "bitrate": int(bitrate), "force": True}
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            antwort = await client.post(url, json=körper)
    except Exception as e:
        log.info("Hol-Vorgang nicht startbar: %s", e)
        return {"ok": False, "reason": "unreachable", "status": dict(_LEERER_STAND)}

    if antwort.status_code in (200, 202):
        return {"ok": True, "reason": "", "status": _stand(_json_oder_leer(antwort))}
    grund = {409: "busy", 204: "no_session", 422: "rejected",
             404: "unsupported"}.get(antwort.status_code, "error")
    log.info("Hol-Vorgang abgelehnt (%s → %s)", antwort.status_code, grund)
    return {"ok": False, "reason": grund, "status": dict(_LEERER_STAND)}


async def fetch_status(base_url: str, *, timeout: float = 5.0) -> Optional[dict]:
    """Stand des laufenden Vorgangs — oder None, wenn der Dienst schweigt."""
    return await _stand_holen(base_url, "GET", timeout)


async def fetch_cancel(base_url: str, *, timeout: float = 5.0) -> Optional[dict]:
    """Bricht den Vorgang ab und liefert den Stand danach."""
    return await _stand_holen(base_url, "DELETE", timeout)


async def _stand_holen(base_url: str, methode: str, timeout: float) -> Optional[dict]:
    url = base_url.rstrip("/") + "/downloads/fetch"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            antwort = await client.request(methode, url)
        antwort.raise_for_status()
    except Exception as e:
        log.debug("Stand des Hol-Vorgangs nicht abrufbar: %s", e)
        return None
    return _stand(_json_oder_leer(antwort))


def _json_oder_leer(antwort) -> dict:
    try:
        daten = antwort.json()
    except Exception:
        return {}
    return daten if isinstance(daten, dict) else {}


def _stand(daten: dict) -> dict:
    fehler = daten.get("failures")
    return {
        "running": bool(daten.get("running", False)),
        "total": int(daten.get("total") or 0),
        "done": int(daten.get("done") or 0),
        "current": str(daten.get("current") or ""),
        "cancelled": bool(daten.get("cancelled", False)),
        "failures": fehler if isinstance(fehler, list) else [],
        # own-librespot beendet einen Lauf selbst, wenn Spotify mehrfach die
        # Audio-Schlüssel verweigert, und nennt hier den Grund. Ältere
        # Fassungen kennen das Feld nicht.
        "stopped_reason": str(daten.get("stopped_reason") or ""),
    }
