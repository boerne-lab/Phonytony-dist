"""Wann der Abgleich von selbst laufen darf.

Kein zeitgesteuerter Nachtlauf: Die Box fährt nach Inaktivität herunter, ein
Lauf um 03:30 Uhr fände in der Regel nie statt. Stattdessen läuft der Abgleich,
sobald die Box eine Weile an ist und niemand hört.

``should_run`` ist eine reine Funktion — die Schleife drumherum wird nur
verdrahtet, entschieden wird hier.
"""

from __future__ import annotations

import asyncio
import logging
import time

log = logging.getLogger(__name__)

MIN_UPTIME_S = 600.0        # 10 Minuten: Start der Box hat Vorrang
RECENT_PLAY_S = 300.0       # 5 Minuten seit dem letzten Scan gilt als "spielt noch"
MIN_INTERVAL_S = 20 * 3600  # höchstens einmal am Tag
_CHECK_INTERVAL_S = 60.0


def should_run(*, enabled: bool, uptime_s: float, present_uid, active_uid,
               last_scanned_at: float, now: float, last_run_at: float) -> bool:
    if not enabled:
        return False
    if uptime_s < MIN_UPTIME_S:
        return False
    if present_uid:
        return False
    if active_uid and (now - last_scanned_at) < RECENT_PLAY_S:
        return False
    seit_letztem = now - last_run_at
    if 0 <= seit_letztem < MIN_INTERVAL_S:
        return False
    # Negativer Abstand heißt: die Uhr ist gesprungen (der Pi Zero hat keine
    # Echtzeituhr). Dann lieber laufen als für immer blockieren.
    return True


async def idle_loop(app_state) -> None:
    """Prüft jede Minute, ob ein Lauf angebracht ist."""
    from pathlib import Path

    from . import index as ix
    from . import runner

    start = time.monotonic()
    while True:
        try:
            await asyncio.sleep(_CHECK_INTERVAL_S)
            settings_store = app_state.settings_store
            settings_store.reload_if_changed()
            state_store = app_state.state_store
            state_store.load()
            zustand = state_store.state
            index_pfad = Path(app_state.settings.data_dir) / "offline_index.json"
            letzter = (ix.load(index_pfad).last_run or {}).get("at", 0.0)

            if should_run(
                enabled=bool(settings_store.data.get("offline_scan_enabled", True)),
                uptime_s=time.monotonic() - start,
                present_uid=zustand.present_uid,
                active_uid=zustand.active_uid,
                last_scanned_at=zustand.last_scanned_at,
                now=time.time(),
                last_run_at=letzter,
            ):
                bericht = await runner.run(app_state, trigger="leerlauf")
                log.info("Offline-Abgleich (Leerlauf): %s", bericht)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("Offline-Abgleich im Leerlauf fehlgeschlagen: %s", e)
