"""Hol-Vorgang: die fehlenden Titel einer Karte gezielt herunterladen.

own-librespot kann Titel ohne Wiedergabe holen. Diese Seite bestimmt, **was**
fehlt, beauftragt den Fork, wartet den Vorgang ab und stößt danach den
regulären Abgleich an — der räumt die Dateien ein und stellt die Karte um.

Der Hol-Vorgang fasst selbst keine Karte an. Das ist Absicht: Umwandlung und
Rückfall liegen an genau einer Stelle (``reconcile``), und die bleibt die
einzige, die Karten verändert.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from . import index as ix
from . import librespot_api
from . import runner
from .matcher import match

log = logging.getLogger(__name__)

# Nebenbei läuft 160 kbit/s; was bewusst geholt wird, soll in besserer Qualität
# bleiben — die Datei ist die Fassung, die dauerhaft auf der Box liegt.
BITRATE = 320

# Abstand zwischen zwei Standabfragen.
_PAUSE_S = 2.0

# So oft darf der Stand noch "nicht angelaufen" melden, bevor wir aufgeben.
# own-librespot nimmt den Auftrag mit 202 an und startet ihn asynchron; die
# erste Abfrage kommt regelmäßig zu früh. Ohne diese Anlaufphase gilt der
# Vorgang sofort als beendet, der Abgleich läuft ins Leere, und die geholten
# Titel bleiben im Download-Ordner liegen.
_ANLAUF_VERSUCHE = 15

# Höchstens so viele Titel je Auftrag. Spotify verweigert die Audio-Schlüssel,
# wenn zu viele in kurzer Folge angefragt werden: Auf der Box liefen 120 Titel
# sauber durch, danach scheiterten 75 von 100 am Stück mit "failed retrieving
# aes key with code 2". Der Rest folgt in weiteren Aufträgen — mit der Pause
# des Forks dazwischen und der Möglichkeit, zwischendurch abzubrechen.
# Auf 12 statt ursprünglich 20 gesenkt: der Sammellauf geriet mit 20er-Häppchen
# trotz Pausen erneut in die Drosselung — der Gesamtdurchsatz soll niedriger
# liegen, nicht nur die Reaktion darauf robuster sein.
_HAEPPCHEN = 12

# Ab so vielen Schlüsselfehlern in einem Auftrag gilt die Vergabe als gedrosselt.
_DROSSEL_SCHWELLE = 3

# Ein Auftrag zur Zeit. Der Fork lehnt einen zweiten ohnehin ab (409); dieser
# Zustand trägt zusätzlich, für wen der laufende Auftrag gedacht ist.
_AUFTRAG: dict = {"running": False, "key": "", "label": "", "category": "musik",
                  "task": None, "importing": False, "import_error": False}
_START_LOCK = asyncio.Lock()


async def start(app_state, key: str, *, category: str = "musik") -> dict:
    """Bestimmt die fehlenden Titel und beauftragt den Fork.

    Liefert ``{ok, reason, missing}``. ``reason`` ist bei Erfolg leer oder
    ``"complete"`` (nichts zu holen)."""
    if _START_LOCK.locked() or _AUFTRAG["running"]:
        return {"ok": False, "reason": "busy", "missing": 0}

    async with _START_LOCK:
        return await _start(app_state, key, category=category)


async def _start(app_state, key: str, *, category: str) -> dict:
    eintrag = _finde(app_state, key)
    if eintrag is None:
        return {"ok": False, "reason": "not_found", "missing": 0}
    entry, _ = eintrag

    tracks = await runner.tracklist(app_state, entry)
    if not tracks:
        # Ohne Trackliste wüssten wir nicht, was zu holen ist — und würden im
        # Zweifel alles noch einmal laden.
        return {"ok": False, "reason": "no_tracklist", "missing": 0}

    index = ix.load(_index_pfad(app_state))
    # Dieselbe Beurteilung wie beim Abgleich: Ein Titel fehlt, wenn er dort
    # nicht als sicher vorhanden gilt. Nur auf bestätigte Zuordnungen zu sehen
    # wäre zu eng — ein über die Metadaten sicher erkannter Titel läge vor und
    # würde trotzdem erneut geladen.
    ergebnis = match(tracks, index,
                     excluded_uris=set(entry.get("excluded_tracks") or []))
    wartend = await _wartende_exporte(app_state)
    offen = [t.uri for t in ergebnis.tracks
             if t.status not in ("sure", "excluded") and t.uri]
    fehlend = [uri for uri in offen if uri not in wartend]

    if not fehlend:
        # "complete" heißt für den Sammellauf: fertig, weiter zum nächsten
        # Eintrag. Steht nur das Einräumen aus, wäre das falsch — die Titel
        # sind geholt, liegen aber noch nicht in der Bibliothek.
        if offen:
            _starte_begleitung(app_state, key, entry, category, nur_import=True)
        grund = "einraeumen_laeuft" if offen else "complete"
        return {"ok": True, "reason": grund, "missing": 0,
                "wartend": len(offen)}

    # Nur ein Häppchen je Auftrag; der Rest kommt beim nächsten Anstoß.
    haeppchen = fehlend[:_HAEPPCHEN]
    antwort = await librespot_api.fetch_start(
        _url(app_state), haeppchen, bitrate=BITRATE)
    if not antwort["ok"]:
        return {"ok": False, "reason": antwort["reason"], "missing": len(fehlend)}

    log.info("Hol-Vorgang für %s gestartet: %d von %d Titeln",
             key, len(haeppchen), len(fehlend))
    _starte_begleitung(app_state, key, entry, category)
    return {"ok": True, "reason": "", "missing": len(haeppchen),
            "verbleibend": len(fehlend) - len(haeppchen)}


def _starte_begleitung(app_state, key, entry, category, *, nur_import=False):
    _AUFTRAG.update(running=True, key=key, label=entry.get("label") or key,
                    category=category, importing=nur_import, import_error=False)
    _AUFTRAG["task"] = asyncio.create_task(
        _begleiten(app_state, nur_import=nur_import), name="offline-fetch")


async def _wartende_exporte(app_state) -> set:
    """URIs, für die eine geholte Datei noch im Download-Ordner liegt.

    Der Offline-Index kennt eine Datei erst, wenn der Abgleich sie eingeräumt
    hat — und das rechnet ReplayGain, dauert auf der Box Minuten je Datei.
    Ohne diese Auskunft galten gerade eben geholte Titel als weiterhin fehlend
    und wurden im nächsten Auftrag erneut angefordert: beobachtet auf der Box,
    zwölf Titel zweimal geholt, im Abstand von zweieinhalb Minuten. Jede
    doppelte Anfrage treibt die Drosselung, gegen die die Häppchen gedacht sind.

    Ein Eintrag im Index des Forks allein genügt nicht: Der bleibt bestehen,
    auch wenn die Datei längst in der Bibliothek liegt. Es zählt, ob die Datei
    noch dort ist, wo der Fork sie hingelegt hat.

    Schweigt die Auskunft, wird wie zuvor entschieden — ein Ausfall darf keinen
    Titel unterschlagen.
    """
    auskunft = await librespot_api.downloads(_url(app_state))
    if not auskunft or not auskunft.get("tracks"):
        return set()

    export_dir = Path(auskunft["dir"] or "")

    def vorhanden() -> set:
        return {uri for uri, eintrag in auskunft["tracks"].items()
                if (export_dir / eintrag["path"]).is_file()}

    # Ein Zugriff je Eintrag: auf der Box sind das schnell hundert, und der
    # Ereignisschleife soll das nicht im Weg stehen.
    return await asyncio.to_thread(vorhanden)


async def status(app_state) -> dict:
    """Stand des Vorgangs, verbunden mit dem, wofür er läuft."""
    stand = await librespot_api.fetch_status(_url(app_state))
    if stand is None:
        stand = {"running": False, "total": 0, "done": 0, "current": "",
                 "cancelled": False, "failures": [], "stopped_reason": ""}
    schluessel = [f for f in stand["failures"] if ist_schluesselfehler(f)]
    # Der Abbruchgrund des Forks ist die verlässlichere Auskunft; unsere eigene
    # Zählung trägt ältere Fassungen, die das Feld nicht kennen.
    gedrosselt = bool(stand.get("stopped_reason")) or len(schluessel) >= _DROSSEL_SCHWELLE
    return {**stand, "key": _AUFTRAG["key"], "label": _AUFTRAG["label"],
            "running": bool(stand["running"] or _AUFTRAG["running"]),
            "importing": _AUFTRAG["importing"],
            "import_error": _AUFTRAG["import_error"],
            "throttled": gedrosselt,
            "key_errors": len(schluessel)}


def ist_schluesselfehler(fehler: dict) -> bool:
    """Verweigert Spotify den Audio-Schlüssel, heißt das "zu schnell" — nicht
    "gibt es nicht mehr". Die Unterscheidung ist für die Nutzerin wesentlich:
    Das eine wartet sich aus, das andere nie."""
    text = (fehler or {}).get("error", "").lower()
    return "aes key" in text or "audio key" in text


async def cancel(app_state) -> dict:
    """Bricht den Vorgang ab. Was schon geholt wurde, bleibt."""
    stand = await librespot_api.fetch_cancel(_url(app_state))
    if stand is None:
        return {"ok": False, "reason": "unreachable"}
    return {"ok": True, "reason": "", "status": stand}


async def warte_auf_ende(app_state) -> None:
    """Wartet, bis der begleitende Task durch ist — samt anschließendem Abgleich.

    Wird von den Tests genutzt und von der Route, die den Vorgang abbricht;
    im Normalbetrieb pollt die Weboberfläche stattdessen ``status``.
    """
    task = _AUFTRAG.get("task")
    if task is not None:
        await asyncio.shield(asyncio.gather(task, return_exceptions=True))


async def _begleiten(app_state, *, nur_import=False) -> None:
    """Verfolgt den Vorgang und gleicht danach ab.

    Der Abgleich läuft auch nach einem Abbruch: Was bis dahin geholt wurde,
    soll eingeräumt werden statt im Download-Ordner liegen zu bleiben.
    """
    try:
        if not nur_import:
            try:
                await _warte_auf_den_fork(app_state)
            except Exception as e:
                log.warning("Hol-Vorgang konnte nicht verfolgt werden: %s", e)
        _AUFTRAG["importing"] = True
        await _gleiche_ab(app_state)
    finally:
        # Erst nach dem Import darf der nächste Auftrag den Index lesen und
        # key/category ersetzen. Sonst werden Dateien erneut angefordert, die
        # gerade verschoben, aber noch nicht im Index gespeichert sind.
        _AUFTRAG.update(running=False, importing=False)


async def _warte_auf_den_fork(app_state) -> None:
    """Wartet, bis der Vorgang wirklich durch ist.

    Zwei Phasen, weil ``running: false`` zweierlei heißen kann: noch nicht
    angelaufen oder schon fertig. Erst wenn er einmal lief — oder Titel
    erledigt sind —, gilt ein ``false`` als Ende.
    """
    angelaufen = False
    anlauf = 0

    while True:
        await asyncio.sleep(_PAUSE_S)
        stand = await librespot_api.fetch_status(_url(app_state))
        if stand is None:
            # Der Dienst schweigt — weiter zu warten hätte keinen Zweck.
            return

        if stand["running"]:
            angelaufen = True
            continue

        if angelaufen or stand["done"] > 0 or stand["cancelled"]:
            return

        anlauf += 1
        if anlauf >= _ANLAUF_VERSUCHE:
            log.warning("Hol-Vorgang ist nicht angelaufen — gebe auf")
            return


async def _gleiche_ab(app_state) -> None:
    """Stößt den Abgleich an; prallt er an der Sperre ab, wird es wiederholt.

    Ohne die Wiederholung bliebe alles Geholte im Download-Ordner liegen, bloß
    weil zufällig ein anderer Lauf aktiv war.
    """
    # Ein Import kann auf dem Pi mehrere Minuten dauern. Eine feste Zahl
    # von Versuchen ließ den Folgeauftrag schon nach 80 Sekunden verfallen.
    wartet = False
    while True:
        try:
            bericht = await runner.run(app_state, trigger="hol-vorgang",
                                       category=_AUFTRAG.get("category"),
                                       nur_key=_AUFTRAG.get("key") or None)
        except Exception as e:
            _AUFTRAG["import_error"] = True
            log.warning("Abgleich nach dem Hol-Vorgang fehlgeschlagen: %s", e)
            return

        if not bericht.get("busy"):
            log.info("Abgleich nach dem Hol-Vorgang: %s", bericht)
            return

        if not wartet:
            log.info("Abgleich läuft bereits — warte und versuche es erneut")
            wartet = True
        await asyncio.sleep(_PAUSE_S * 2)


def _finde(app_state, key: str):
    mapping = app_state.mapping_store
    mapping.reload_if_changed()
    eintrag = mapping.all_cards().get(key)
    if eintrag is not None:
        return eintrag, False
    eintrag = mapping.library_all().get(key)
    if eintrag is not None:
        return eintrag, True
    return None


def _index_pfad(app_state) -> Path:
    return Path(app_state.settings.data_dir) / "offline_index.json"


def _url(app_state) -> str:
    return getattr(app_state.settings, "librespot_url", "") or "http://127.0.0.1:3678"
