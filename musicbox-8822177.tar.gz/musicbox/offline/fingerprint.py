"""Fingerabdruck einer Audiodatei — Titel, Künstler, Album, Dauer.

Der Vergleich mit einer Spotify-Trackliste braucht Werte, die sich trotz
unterschiedlicher Schreibweisen treffen: "Für Elise" und "Fur Elise" sollen
dasselbe sein, "Bohemian Rhapsody (Remastered 2011)" dasselbe wie "Bohemian
Rhapsody". Deshalb wird alles normalisiert abgelegt.

Gelesen wird mit mutagen (bereits Abhängigkeit des Sticker-Generators). Fehlt
das Titel-Tag oder ist die Datei unlesbar, trägt der Dateiname.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

# Fassungs-Suffixe nach " - ": "Wonderwall - Remastered" meint dasselbe Lied.
_VERSION_SUFFIXES = (
    "live", "remaster", "remastered", "radio edit", "single version",
    "version", "mono", "stereo",
)

_FEAT = re.compile(r"\s(feat\.|ft\.|featuring)\s.*$", re.IGNORECASE)
_BRACKETS = re.compile(r"[\(\[][^\)\]]*[\)\]]")
_LEADING_TRACKNO = re.compile(r"^\d{1,3}[\s._-]+")
# Apostrophe fallen ersatzlos weg ("don't" → "dont"), alles andere wird zum
# Trenner ("rock&roll" → "rock roll").
_APOSTROPHE = re.compile(r"['’ʼ`]")
_NON_ALNUM = re.compile(r"[^a-z0-9 ]")
_SPACES = re.compile(r"\s+")


@dataclass(frozen=True)
class Fingerprint:
    path: str                    # relativ zu music_dir, z.B. "musik/03 - Bibi.mp3"
    title: str                   # normalisiert
    artist: str                  # normalisiert
    album: str                   # normalisiert
    duration_s: Optional[float]
    source: str                  # "tags" | "filename"


def normalize(text: str) -> str:
    """Vergleichbare Form: ohne Diakritika, Klammerzusätze, Fassungs-Suffixe."""
    if not text:
        return ""
    # Diakritika entfalten und verwerfen: ä → a, é → e
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.lower()
    text = _BRACKETS.sub(" ", text)
    text = _strip_version_suffix(text)
    text = _FEAT.sub("", text)
    text = _APOSTROPHE.sub("", text)
    text = _NON_ALNUM.sub(" ", text)
    return _SPACES.sub(" ", text).strip()


def _strip_version_suffix(text: str) -> str:
    """Schneidet ' - remastered' & Co. ab — aber nur diese, sonst würde
    'Bibi und Tina - Der Sattel' seinen Titel verlieren."""
    idx = text.rfind(" - ")
    if idx == -1:
        return text
    rest = _NON_ALNUM.sub(" ", text[idx + 3:])
    rest = _SPACES.sub(" ", rest).strip()
    if rest in _VERSION_SUFFIXES:
        return text[:idx]
    return text


def parse_filename(name: str) -> tuple[str, str]:
    """(Künstler, Titel) aus dem Dateinamen — roh, nicht normalisiert."""
    stem = Path(name).stem
    stem = _LEADING_TRACKNO.sub("", stem).strip()
    if " - " in stem:
        artist, _, title = stem.partition(" - ")
        return artist.strip(), title.strip()
    return "", stem


def read(abs_path: Path, rel_path: str) -> Fingerprint:
    """Fingerabdruck einer Datei. Tags haben Vorrang, der Dateiname trägt sonst."""
    tags = _open_tags(abs_path)
    title = _first(tags, "title")
    artist = _first(tags, "artist")
    album = _first(tags, "album")
    duration = _length(tags)

    source = "tags"
    if not title:
        source = "filename"
        fn_artist, fn_title = parse_filename(rel_path)
        title = fn_title
        # Ein vorhandenes Künstler-Tag ist verlässlicher als der Dateiname.
        artist = artist or fn_artist

    return Fingerprint(
        path=rel_path,
        title=normalize(title),
        artist=normalize(artist),
        album=normalize(album),
        duration_s=duration,
        source=source,
    )


def _open_tags(path: Path) -> Any:
    """mutagen-Objekt oder None. Kapselt den Import, damit Tests es ersetzen können."""
    try:
        import mutagen
        return mutagen.File(str(path), easy=True)
    except Exception:
        return None


def _first(tags: Any, key: str) -> str:
    if not tags:
        return ""
    try:
        value = tags.get(key)
    except Exception:
        return ""
    if not value:
        return ""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    return str(value).strip()


def _length(tags: Any) -> Optional[float]:
    info = getattr(tags, "info", None)
    length = getattr(info, "length", None)
    if isinstance(length, (int, float)) and length > 0:
        return float(length)
    return None
