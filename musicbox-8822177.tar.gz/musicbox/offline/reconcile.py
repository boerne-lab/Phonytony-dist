"""Matchergebnis in die Speicher überführen — Umwandlung und Rückfall.

Umwandlung: Eine Karte, deren Tracks vollständig lokal vorliegen, zeigt danach
auf eine lokale Playlist. Herkunft, Playlist-Kennung und bei eigenen
Zusammenstellungen auch die ursprüngliche Trackliste bleiben am Eintrag
erhalten — nur damit kann der Rückfall die Karte später wiederherstellen.

Rückfall: Fehlt eine Datei, geht der Eintrag auf seine Herkunft zurück. Die
lokale Playlist bleibt dabei bestehen; die noch vorhandenen Dateien sind ja
weiter nutzbar.
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from .matcher import MatchResult

log = logging.getLogger(__name__)


@dataclass
class Stores:
    mapping: object
    playlists: object
    music_dir: Path


def apply(key: str, entry: dict, result: MatchResult, *, stores: Stores,
          is_library: bool, spotify_name: str) -> str:
    """Stellt den Eintrag offline, wenn das Ergebnis vollständig ist.
    Liefert "converted" oder "unchanged"."""
    if not result.complete:
        return "unchanged"

    pfade = [t.path for t in result.tracks if t.status == "sure" and t.path]
    if not pfade:
        return "unchanged"

    if entry.get("type") == "local" and entry.get("offline_of") \
            and _schon_aktuell(entry, pfade, stores):
        # Beim erneuten Prüfen: die Karte ist längst offline und die Titel
        # stimmen noch. Nichts zu tun — und nichts zu melden.
        return "unchanged"

    neu = dict(entry)
    neu["offline_of"] = entry.get("offline_of") or entry["ref"]
    neu["offline_origin_type"] = entry.get("offline_origin_type") or entry["type"]
    neu["offline_since"] = datetime.now().astimezone().isoformat(timespec="seconds")
    neu.pop("offline_reverted_at", None)

    if neu["offline_origin_type"] == "spotify_queue":
        # Der Ref einer Queue ist nur ein synthetischer Schlüssel; ohne die
        # Trackliste ließe sich die Karte später nicht wiederherstellen.
        neu["offline_queue_tracks"] = list(entry.get("tracks") or [])

    if len(pfade) == 1 and _ist_einzeltrack(neu["offline_of"], result):
        neu["type"] = "local"
        neu["ref"] = pfade[0]
        neu.pop("offline_playlist_id", None)
    else:
        playlist = _schreibe_playlist(key, neu, pfade, stores, spotify_name)
        neu["type"] = "local"
        neu["ref"] = playlist["m3u8_path"]
        neu["offline_playlist_id"] = playlist["id"]

    _speichern(key, neu, stores, is_library)
    log.info("Karte %s spielt jetzt lokal (%d Titel aus %s)",
             key, len(pfade), neu["offline_of"])
    return "converted"


def _schon_aktuell(entry: dict, pfade: list, stores: Stores) -> bool:
    playlist_id = entry.get("offline_playlist_id")
    if playlist_id:
        playlist = stores.playlists.get(playlist_id)
        return playlist is not None and playlist.get("tracks") == pfade and entry.get("ref") == playlist.get("m3u8_path")
    return len(pfade) == 1 and entry.get("ref") == pfade[0]


def revert(key: str, entry: dict, *, stores: Stores, is_library: bool) -> str:
    """Stellt einen offline gestellten Eintrag auf seine Herkunft zurück."""
    herkunft = entry.get("offline_of")
    if not herkunft:
        return "unchanged"

    neu = dict(entry)
    neu["type"] = entry.get("offline_origin_type") or "spotify"
    neu["offline_reverted_at"] = datetime.now().astimezone().isoformat(timespec="seconds")

    if neu["type"] == "spotify_queue":
        neu["tracks"] = list(entry.get("offline_queue_tracks") or [])
        neu["ref"] = herkunft
        if not neu["tracks"]:
            # Ohne Tracks wäre der Eintrag ungültig und nicht abspielbar.
            log.warning("Queue-Karte %s hat keine gemerkten Tracks — bleibt lokal", key)
            return "unchanged"
    else:
        neu["ref"] = herkunft

    _speichern(key, neu, stores, is_library)
    log.info("Karte %s spielt wieder über Spotify (%s)", key, herkunft)
    return "reverted"


def _ist_einzeltrack(herkunft: str, result: MatchResult) -> bool:
    return ":track:" in herkunft and len(result.tracks) == 1


def _schreibe_playlist(key: str, entry: dict, pfade: list, stores: Stores,
                       spotify_name: str) -> dict:
    name = entry.get("label") or spotify_name or f"Offline {key}"
    kategorie = _kategorie(pfade)
    playlist_id = entry.get("offline_playlist_id")

    if playlist_id and stores.playlists.get(playlist_id) is not None:
        aktualisiert = stores.playlists.update(playlist_id, name=name,
                                                category=kategorie, tracks=pfade)
        if aktualisiert is not None:
            return aktualisiert

    geteilt = _playlist_eines_geschwisters(key, entry, pfade, stores)
    if geteilt is not None:
        return geteilt

    return stores.playlists.create(name, kategorie, pfade)


def _playlist_eines_geschwisters(key: str, entry: dict, pfade: list,
                                 stores: Stores) -> Optional[dict]:
    """Die Playlist eines anderen Eintrags derselben Herkunft — oder None.

    Für dasselbe Album gibt es oft zwei Einträge: die Karte, die das Kind
    auflegt, und den Bibliothekseintrag, über den man sie in der Oberfläche
    findet. Ohne diese Prüfung bekam jeder eine eigene Playlist, und in der
    Übersicht stand jedes Album doppelt — auf der Box bei drei Alben zugleich.

    Geteilt wird nur bei **gleicher** Titelliste. Ein Eintrag, der einen Titel
    ausschließt, hat eine andere Liste; ihm die fremde Playlist zu geben würde
    ihm Titel unterschieben, die er nicht haben soll.
    """
    herkunft = entry.get("offline_of")
    if not herkunft:
        return None

    for anderer_key, anderer in _alle_eintraege(stores):
        if anderer_key == key or anderer.get("offline_of") != herkunft:
            continue
        fremde_id = anderer.get("offline_playlist_id")
        if not fremde_id:
            continue
        playlist = stores.playlists.get(fremde_id)
        if playlist is not None and playlist.get("tracks") == pfade:
            log.info("Eintrag %s teilt sich die Playlist von %s (%s)",
                     key, anderer_key, herkunft)
            return playlist
    return None


def _alle_eintraege(stores: Stores):
    """Karten und Bibliothekseinträge in einem Durchlauf."""
    yield from stores.mapping.all_cards().items()
    yield from (stores.mapping.library_all() or {}).items()


def _kategorie(pfade: list) -> str:
    """Die Kategorie, in der die meisten Dateien liegen; bei Gleichstand musik."""
    zähler = Counter(p.split("/")[0] for p in pfade if "/" in p)
    if not zähler:
        return "musik"
    häufigste = zähler.most_common()
    spitze = häufigste[0][1]
    kandidaten = {k for k, n in häufigste if n == spitze}
    if len(kandidaten) > 1 or häufigste[0][0] not in ("musik", "hoerbuch"):
        return "musik"
    return häufigste[0][0]


def _speichern(key: str, entry: dict, stores: Stores, is_library: bool) -> None:
    if is_library:
        stores.mapping.library_set(key, entry)
    else:
        stores.mapping.set(key, entry)
