"""Eine von own-librespot exportierte Datei in die Bibliothek einräumen.

Der Fork legt seine Dateien nach ``<Künstler>/<Album>/03. Titel.ogg`` ab. Die
Bibliothek der Box ist flach (``musik/``, ``hoerbuch/``) und der Offline-Index
sieht nur dort nach — eine exportierte Datei bliebe also unsichtbar.

Dieses Modul verschiebt sie an ihren Platz, rechnet die Lautheit nach und
hinterlegt die Zuordnung Track-URI → Datei als **gesichert**. Damit muss für
geholte Dateien nichts geraten werden; der Fuzzy-Vergleich bleibt für Dateien
zuständig, die von Hand in die Bibliothek kommen.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Optional

from . import index as ix

log = logging.getLogger(__name__)

CATEGORIES = ("musik", "hoerbuch")

# Zeichen, die im Dateisystem oder auf Freigaben stören. Umlaute und Akzente
# bleiben erhalten — die Bibliothek zeigt die Namen auch in der Weboberfläche.
_UNSAFE = re.compile(r'[/\\:*?"<>|\x00]')
_SPACES = re.compile(r"\s+")
# Führende Tracknummer des Exports ("03. Titel") und angehängte Kennung, die der
# Fork bei einer Namenskollision setzt ("Intro [spotify:track:…]").
_LEADING_TRACKNO = re.compile(r"^\d{1,3}\.\s*")
_KENNUNG = re.compile(r"\s*\[spotify:[^\]]+\]\s*$")


def take(export_path: Path, uri: str, *, music_dir: Path, category: str,
         index: ix.OfflineIndex, meta: Optional[dict] = None) -> Optional[str]:
    """Räumt eine exportierte Datei ein und liefert ihren Pfad relativ zu
    music_dir — oder None, wenn die Quelle nicht (mehr) da ist."""
    export_path = Path(export_path)
    if not export_path.is_file():
        log.info("Exportierte Datei nicht gefunden: %s", export_path)
        return None

    if category not in CATEGORIES:
        category = "musik"

    ziel_dir = Path(music_dir) / category
    ziel_dir.mkdir(parents=True, exist_ok=True)

    name = zielname(meta, uri, export_path)
    ziel = ziel_dir / name
    if ziel.exists():
        # Ein anderer Titel belegt den Namen bereits — die Kennung trennt sie.
        ziel = ziel_dir / _mit_kennung(name, uri)

    if not _ist_lesbar(export_path):
        # Der Export hat schon unbrauchbare Dateien geliefert (Ogg ohne
        # Setup-Header). Eine kaputte Datei in der Bibliothek ist schlimmer als
        # gar keine: Sie gilt als gesicherte Zuordnung, die Karte wird darauf
        # umgestellt und spielt danach still nicht mehr. Die Datei bleibt im
        # Download-Ordner liegen, damit sie untersucht werden kann.
        log.warning("Exportierte Datei ist nicht lesbar, bleibt liegen: %s",
                    export_path.name)
        return None

    try:
        os.replace(export_path, ziel)
    except OSError as e:
        # Anderes Dateisystem oder fehlende Rechte: kopieren wäre hier falsch,
        # denn dann läge die Datei doppelt und der Platz ginge zweimal drauf.
        log.warning("Konnte %s nicht einräumen: %s", export_path, e)
        return None

    try:
        os.chmod(ziel, 0o644)
    except OSError:
        pass

    rel = f"{category}/{ziel.name}"
    _nachbearbeiten(ziel, False)
    ix.confirm(index, uri, rel)
    log.info("Eingeräumt: %s → %s", uri, rel)
    return rel


def meta_aus_pfad(rel_path: str) -> dict:
    """Künstler und Titel aus dem Ablageschema des Forks ablesen.

    ``<Künstler>/<Album>/03. Titel.ext`` für Tracks, ``<Show>/<Episode>.ext``
    für Podcast-Episoden. Das erspart einen Netzzugriff nur für die Namen — und
    funktioniert auch dann, wenn Spotify gerade nicht erreichbar ist.
    """
    teile = [t for t in str(rel_path).replace("\\", "/").split("/") if t]
    if not teile:
        return {"name": "", "by": ""}

    titel = Path(teile[-1]).stem
    titel = _LEADING_TRACKNO.sub("", titel)
    titel = _KENNUNG.sub("", titel).strip()
    kuenstler = teile[0] if len(teile) > 1 else ""
    return {"name": titel, "by": kuenstler}


def zielname(meta: Optional[dict], uri: str, export_path: Path) -> str:
    """"<Künstler> - <Titel>.<ext>" aus den Metadaten; sonst der Name des
    Exports, der den Titel bereits enthält."""
    endung = export_path.suffix
    titel = _sauber((meta or {}).get("name", ""))
    kuenstler = _sauber((meta or {}).get("by", ""))

    if titel and kuenstler:
        return f"{kuenstler} - {titel}{endung}"
    if titel:
        return f"{titel}{endung}"
    return _sauber(export_path.stem) + endung


def _mit_kennung(name: str, uri: str) -> str:
    stamm, punkt, endung = name.rpartition(".")
    kennung = uri.split(":")[-1]
    if not punkt:
        return f"{name} [{kennung}]"
    return f"{stamm} [{kennung}].{endung}"


def _sauber(text: str) -> str:
    text = _UNSAFE.sub("", text or "")
    text = _SPACES.sub(" ", text).strip().lstrip(".")
    return text


def _ist_lesbar(pfad: Path) -> bool:
    """Kann ein Decoder die Datei überhaupt öffnen?

    Prüft mit mutagen (ohnehin Abhängigkeit): Ein Audioformat, das erkannt wird
    und eine plausible Spieldauer meldet, ist brauchbar. Eine Ogg-Datei ohne
    Setup-Header fällt hier durch, obwohl ihre Tags noch lesbar wären.
    """
    try:
        import mutagen
        datei = mutagen.File(str(pfad))
    except Exception as e:
        log.debug("Lesbarkeitsprüfung von %s fehlgeschlagen: %s", pfad.name, e)
        return False

    if datei is None:
        return False
    dauer = getattr(getattr(datei, "info", None), "length", 0)
    return isinstance(dauer, (int, float)) and dauer > 0


def _nachbearbeiten(pfad: Path, trim: bool) -> None:
    """ReplayGain nachrechnen. Eigene Funktion, damit Tests sie ersetzen können.

    Ohne diesen Schritt wären geholte Titel hörbar lauter oder leiser als
    hochgeladene. Getrimmt wird bewusst **nicht**: bei einem Spotify-Track
    gehört die Anfangsstille zur Aufnahme, und ein Trimmen würde die Dauer
    verändern — womit der Dauervergleich des Matchers ins Leere liefe.
    """
    try:
        from musicbox.audio import reprocess
        reprocess.process_one(pfad, trim=trim)
    except Exception as e:
        # Eine fehlende Lautheitsanpassung ist ein Schönheitsfehler, kein Grund,
        # die eingeräumte Datei wieder zu verwerfen.
        log.warning("Nachbearbeitung von %s fehlgeschlagen: %s", pfad.name, e)
