"""LocalBackend: steuert mpv via Unix-Socket JSON-IPC."""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
from pathlib import Path
from typing import Any, Optional

from .base import AudioBackend
from musicbox.store.local_tracks import playlist_tracks

log = logging.getLogger(__name__)

_MPV_LAUNCH_TIMEOUT = 5.0
_IPC_TIMEOUT = 2.0


class LocalBackend(AudioBackend):
    def __init__(self, socket_path: str, alsa_card: str, music_dir: Path, playlists_dir: Path) -> None:
        self._socket = socket_path
        self._alsa_card = alsa_card
        self._music_dir = music_dir
        self._playlists_dir = playlists_dir
        self._mpv_proc: Optional[asyncio.subprocess.Process] = None
        self._req_id = 0

    async def _ensure_mpv(self) -> None:
        if await self._socket_alive():
            return
        log.info("Starte mpv ...")
        self._mpv_proc = await asyncio.create_subprocess_exec(
            "mpv",
            "--no-video",
            "--idle=yes",
            f"--input-ipc-server={self._socket}",
            # PipeWire teilt das Gerät zwischen mpv, go-librespot und Feedback-Tönen
            # und bedient zusätzlich Bluetooth-Sinks (früher: gemeinsame dmix-Karte).
            "--audio-device=pipewire",
            # ReplayGain-Tags anwenden (Lautheits-Normalisierung), Clipping vermeiden
            "--replaygain=track",
            "--replaygain-clip=yes",
            "--volume=75",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        deadline = asyncio.get_event_loop().time() + _MPV_LAUNCH_TIMEOUT
        while asyncio.get_event_loop().time() < deadline:
            if await self._socket_alive():
                return
            await asyncio.sleep(0.2)
        raise RuntimeError("mpv hat Socket nicht rechtzeitig geöffnet")

    async def _socket_alive(self) -> bool:
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_unix_connection(self._socket), timeout=0.5
            )
            writer.close()
            await writer.wait_closed()
            return True
        except Exception:
            return False

    async def _send(self, command: list) -> Any:
        self._req_id += 1
        req_id = self._req_id
        msg = json.dumps({"command": command, "request_id": req_id}) + "\n"
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_unix_connection(self._socket), timeout=_IPC_TIMEOUT
            )
            writer.write(msg.encode())
            await writer.drain()
            line = await asyncio.wait_for(reader.readline(), timeout=_IPC_TIMEOUT)
            writer.close()
            await writer.wait_closed()
            return json.loads(line).get("data")
        except Exception as e:
            log.warning("mpv IPC Fehler: %s", e)
            return None

    _AUDIO_SUFFIXES = {".mp3", ".flac", ".ogg", ".m4a"}

    def resolve(self, ref: str) -> Path:
        """Ref zu einem Pfad auflösen — relativ zu music_dir oder absolut.

        Öffentlich, weil auch der Controller wissen muss, wo eine Karte hinzeigt:
        gegen das CWD des Dienstes aufgelöst läge jeder relative Ref daneben."""
        path = Path(ref)
        if path.is_absolute():
            return path
        return self._music_dir / ref

    def _build_playlist(self, ref: str) -> str:
        """ref = Pfad (Datei oder Verzeichnis), relativ zu music_dir oder absolut."""
        path = self.resolve(ref)
        if path.is_file():
            return str(path)
        # Verzeichnis → .m3u generieren (Endungen case-insensitive)
        files = sorted(f for f in path.rglob("*") if f.is_file() and f.suffix.lower() in self._AUDIO_SUFFIXES)
        self._playlists_dir.mkdir(parents=True, exist_ok=True)
        playlist_path = self._playlists_dir / f"{path.name}.m3u8"
        playlist_path.write_text("\n".join(str(f) for f in files))
        return str(playlist_path)

    async def load(self, ref: str, options: dict) -> None:
        await self._ensure_mpv()
        target = self._build_playlist(ref)
        if target.endswith(".m3u8"):
            excluded = set(options.get("excluded_local_tracks") or [])
            if excluded:
                tracks = [t for t in playlist_tracks(target, self._music_dir)
                          if t not in excluded]
                if not tracks:
                    # Eine leere Auswahl darf nicht die vorige Playlist
                    # weiterspielen lassen.
                    await self._send(["stop"])
                    return
                self._playlists_dir.mkdir(parents=True, exist_ok=True)
                filtered = self._playlists_dir / ".musicbox-active.m3u8"
                filtered.write_text("\n".join(str(self.resolve(t)) for t in tracks))
                target = str(filtered)
            await self._send(["loadlist", target, "replace"])
        else:
            await self._send(["loadfile", target, "replace"])
        if options.get("shuffle"):
            await self._send(["playlist-shuffle"])
        # Repeat: off | track (Einzeltitel) | all (ganze Playlist)
        repeat = options.get("repeat", "off")
        await self._send(["set_property", "loop-file", "inf" if repeat == "track" else "no"])
        await self._send(["set_property", "loop-playlist", "inf" if repeat == "all" else "no"])
        await self._send(["set_property", "pause", False])

    async def play(self) -> None:
        await self._send(["set_property", "pause", False])

    async def pause(self) -> None:
        await self._send(["set_property", "pause", True])

    async def next_track(self) -> None:
        await self._send(["playlist-next"])

    async def prev_track(self) -> None:
        await self._send(["playlist-prev"])

    async def seek(self, position_ms: int) -> None:
        await self._send(["set_property", "time-pos", position_ms / 1000])

    async def set_volume(self, pct: int) -> None:
        await self._send(["set_property", "volume", max(0, min(100, pct))])

    async def set_eq(self, af: str) -> None:
        """mpv-Audiofilter (Equalizer) setzen; leerer String = kein Filter."""
        await self._send(["set_property", "af", af])

    async def get_status(self) -> dict:
        if not await self._socket_alive():
            return {"playing": False, "position_ms": 0, "track_name": ""}
        paused = await self._send(["get_property", "pause"])
        pos = await self._send(["get_property", "time-pos"]) or 0
        filename = await self._send(["get_property", "filename/no-ext"]) or ""
        return {
            "playing": paused is False,
            "position_ms": int(pos * 1000),
            "track_name": filename,
        }

    async def is_available(self) -> bool:
        return await self._socket_alive()
