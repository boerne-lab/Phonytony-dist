"""Haupt-Einstiegspunkt für musicbox-core."""

from __future__ import annotations

import asyncio
import logging
import signal
import subprocess
import time
from typing import Callable

from musicbox.audio.feedback import FeedbackPlayer
from musicbox.audio.volume import AlsaVolume
from musicbox.backends.local import LocalBackend
from musicbox.backends.spotify import SpotifyBackend
from musicbox.connectivity import bluetooth
from musicbox.core.controller import MusicBoxController
from musicbox.core.ipc_server import IPCServer
from musicbox.rfid.reader import RC522Reader
from musicbox.settings import load_settings
from musicbox.store.mapping import MappingStore
from musicbox.store.settings_store import SettingsStore
from musicbox.store.state import StateStore

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
)
log = logging.getLogger(__name__)


async def _periodic_reload(mapping_store, settings_store, interval: int = 5) -> None:
    while True:
        await asyncio.sleep(interval)
        mapping_store.reload_if_changed()
        settings_store.reload_if_changed()


# Sentinel für "noch nie abgefragt": nicht None, damit der allererste Poll auch
# dann ein Event erzeugt, wenn gar kein Kopfhörer verbunden ist.
_UNKNOWN = object()

# Root-Helfer wie in der Weboberfläche: bluetoothctl connect braucht Rechte, die
# der Dienstnutzer nur über diesen per sudoers freigegebenen Helfer hat.
_BT_HELPER = "/opt/musicbox/scripts/bt_helper.sh"
# Ein erreichbarer Kopfhörer ist in rund fünf Sekunden verbunden (auf der Box
# gemessen: 4,6 s). Ein ausgeschalteter dagegen lässt den Aufruf bis zum Timeout
# stehen und belegt die Funkstrecke solange mit Page-Versuchen. 15 Sekunden lassen
# dem Normalfall das Dreifache an Luft und halbieren die Blockade.
_BT_CONNECT_TIMEOUT = 15
# Deutlich länger als das Poll-Intervall: ein ausgeschalteter Kopfhörer soll die
# Funkstrecke nicht alle drei Sekunden mit Verbindungsversuchen belegen.
_BT_RECONNECT_INTERVAL = 60.0
# Nach jedem Fehlschlag verdoppelt sich der Abstand bis zu dieser Grenze. Ohne das
# pagt die Box eine ganze Nacht lang im Minutentakt gegen ein ausgeschaltetes Gerät
# — auf diesem ohnehin wackligen Controller keine Kleinigkeit. Die Deckelung auf
# fünf Minuten hält den Rückfallweg trotzdem brauchbar: Seit die Box HFP/HSP
# anbietet, meldet sich der Kopfhörer ohnehin meist selbst zurück; die Box wählt
# nur noch, wenn er das nicht tut (etwa weil er zuletzt am Handy hing).
_BT_RECONNECT_INTERVAL_MAX = 300.0


def _naechste_wartezeit(aktuell: float, *, erfolg: bool,
                        start: float = _BT_RECONNECT_INTERVAL,
                        maximum: float = _BT_RECONNECT_INTERVAL_MAX) -> float:
    """Abstand bis zum nächsten Selbstheilungs-Versuch."""
    if erfolg:
        return start
    return min(max(aktuell, start) * 2, maximum)


# Ein nicht aufrufbarer Helfer ist ein Konfigurationsfehler und gehört genau
# einmal ins Journal — nicht alle 60 Sekunden.
_bt_helper_warned = False


def _bt_connect(mac: str, *, runner: Callable = subprocess.run) -> bool:
    """Verbindet ein bekanntes Gerät über den root-Helfer. Blockiert (Thread!)."""
    global _bt_helper_warned
    try:
        mac = bluetooth.validate_mac(mac)
        r = runner(["sudo", "-n", _BT_HELPER, "connect", "--mac", mac],
                   capture_output=True, text=True, timeout=_BT_CONNECT_TIMEOUT)
    except Exception:
        log.debug("Bluetooth-Verbindungsversuch fehlgeschlagen", exc_info=True)
        return False
    if getattr(r, "returncode", 1) == 0:
        return True
    # Unterscheidung, die auf der Box teuer gelernt wurde: Ein ausgeschalteter
    # Kopfhörer ist der Normalfall — der Helfer läuft und meldet sein Ergebnis
    # auf stdout. Schreibt dagegen etwas auf stderr, kam der Helfer gar nicht
    # erst zum Zug (fehlende sudo-Rechte, Datei nicht ausführbar). Das ist kein
    # Normalfall, sondern ein Fehler, der sonst unsichtbar bleibt: der Reconnect
    # scheiterte monatelang still an NoNewPrivileges=true im Core-Dienst.
    fehler = (getattr(r, "stderr", "") or "").strip()
    if fehler and not _bt_helper_warned:
        _bt_helper_warned = True
        log.warning("Bluetooth-Helfer nicht aufrufbar — die Box kann einen "
                    "bekannten Kopfhörer nicht selbst zurückholen: %s", fehler)
    else:
        log.debug("Kopfhörer %s nicht verbunden (Rückgabecode %s)%s", mac,
                  getattr(r, "returncode", None),
                  f": {fehler}" if fehler else "")
    return False


async def _bt_try_reconnect() -> bool:
    """Ein einziger, stiller Versuch, einen bekannten Kopfhörer zurückzuholen.

    Nur für ein Gerät, das die Box kennt (gekoppelt UND trusted) und das gerade
    nicht verbunden ist. Klappt es, meldet der normale Poll ohnehin bt_connected
    — hier wird also kein Event erzeugt. Klappt es nicht, ist das der Normalfall
    (Kopfhörer ausgeschaltet) und bleibt auf Debug-Ebene.

    Liefert True, wenn eine Verbindung zustande kam — der Aufrufer steuert damit
    den Abstand bis zum nächsten Versuch.
    """
    res = await asyncio.to_thread(bluetooth.list_devices)
    if not res.get("ok"):
        return False
    kandidat = next((d for d in res.get("devices", [])
                     if d.get("paired") and d.get("trusted")
                     and not d.get("connected")), None)
    if kandidat is None:
        return False
    mac = kandidat["mac"]
    if await asyncio.to_thread(_bt_connect, mac):
        log.info("Bekannten Kopfhörer %s selbst wieder verbunden", mac)
        return True
    log.debug("Kopfhörer %s nicht erreichbar (vermutlich ausgeschaltet)", mac)
    return False


async def _bt_watch(queue: asyncio.Queue, interval: int = 3,
                    reconnect_interval: float = _BT_RECONNECT_INTERVAL) -> None:
    """Meldet Bluetooth-Verbindungswechsel als Events an den Controller.

    Bewusst Polling statt D-Bus-Signalen: eine Abfrage alle paar Sekunden ist auf
    dieser Box billig und übersteht Neustarts von bluetoothd ohne Sonderbehandlung.

    Der erste Poll meldet immer den vorgefundenen Zustand. Das ist wichtig für den
    Start: output_mode wird persistiert, eine mit verbundenem Kopfhörer ausgeschaltete
    Box startet also im Bluetooth-Modus — mit stummgeschalteten ALSA-Endstufen. Ohne
    ein erstes bt_disconnected bliebe sie ohne Kopfhörer lautlos.

    Ist gerade nichts verbunden, versucht der Monitor höchstens alle
    `reconnect_interval` Sekunden einmal, einen bekannten Kopfhörer selbst
    zurückzuholen (siehe _bt_try_reconnect).
    """
    last_mac = _UNKNOWN
    # Erst nach einem vollen Intervall selbst verbinden: direkt nach dem Start
    # hat ein eingeschalteter Kopfhörer noch Zeit, sich selbst zu melden.
    last_reconnect = time.monotonic()
    wartezeit = reconnect_interval
    while True:
        try:
            res = await asyncio.to_thread(bluetooth.connected)
            if not res.get("ok"):
                # Zustand unbekannt (bluetoothd-Neustart durch bt_watchdog.sh,
                # Timeout, D-Bus noch nicht bereit). Kein Event und last_mac
                # unverändert lassen — sonst käme ein falsches bt_disconnected
                # und der Ton spränge zurück auf den Lautsprecher, obwohl der
                # Kopfhörer verbunden ist. Der nächste erfolgreiche Poll stellt
                # die Wahrheit wieder her.
                log.debug("Bluetooth-Status unbekannt — Poll übersprungen")
                await asyncio.sleep(interval)
                continue
            device = res.get("device")
            mac = device["mac"] if device else None
            if mac != last_mac:
                if mac:
                    await queue.put({"event": "bt_connected", "mac": mac,
                                     "name": device.get("name", "")})
                else:
                    await queue.put({"event": "bt_disconnected"})
                last_mac = mac
            if mac is not None:
                # Er ist da — sei es durch den eigenen Versuch oder weil er sich
                # selbst gemeldet hat. Aufgelaufener Rückstand ist damit hinfällig.
                wartezeit = reconnect_interval
            elif time.monotonic() - last_reconnect >= wartezeit:
                last_reconnect = time.monotonic()
                erfolg = await _bt_try_reconnect()
                wartezeit = _naechste_wartezeit(wartezeit, erfolg=erfolg,
                                                start=reconnect_interval)
        except Exception:
            log.debug("Bluetooth-Status konnte nicht gelesen werden", exc_info=True)
        await asyncio.sleep(interval)


async def _amain() -> None:
    settings = load_settings()

    mapping_store = MappingStore(settings.mapping_file)
    mapping_store.load()

    state_store = StateStore(settings.state_file)
    state_existed = settings.state_file.exists()
    state = state_store.load()
    if not state_existed:
        # Erstinbetriebnahme: konfigurierten Default-Volume statt Hardcoded-75 übernehmen
        state.volume = settings.volume_default

    settings_store = SettingsStore(settings.settings_file)
    settings_store.load()

    alsa_volume = AlsaVolume(settings.alsa_card, settings.alsa_controls)
    alsa_volume.initialize(state.volume)
    # Pro-Ausgang-Deckel + Ausgangsmodus aus den Einstellungen/State anwenden
    # (Startpegel respektiert die globale Mindestlautstärke)
    _min_vol = int(settings_store.data.get("min_volume", 0))
    _start_vol = max(state.volume, _min_vol)
    alsa_volume.apply(_start_vol, settings_store.data.get("max_volume", {}), state.output_mode)
    state_store.set_volume(_start_vol)

    # Die Lautstärke der Warntöne wird bei jedem Ton frisch gelesen, damit ein
    # Schieben des Reglers sofort hörbar ist — _periodic_reload hält den Store
    # aktuell.
    feedback = FeedbackPlayer(
        settings.feedback_dir, settings.alsa_card,
        volume=lambda: settings_store.data.get("feedback_volume", 50))
    spotify_backend = SpotifyBackend(settings.librespot_url)
    local_backend = LocalBackend(
        socket_path=settings.mpv_socket,
        alsa_card=settings.alsa_card,
        music_dir=settings.music_dir,
        playlists_dir=settings.playlists_dir,
    )

    event_queue: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_running_loop()

    rfid_reader = RC522Reader()
    try:
        rfid_reader.start()
    except Exception:
        log.warning("RC522 nicht verfügbar — RFID deaktiviert")
        rfid_reader = None

    controller = MusicBoxController(
        mapping_store=mapping_store,
        state_store=state_store,
        spotify_backend=spotify_backend,
        local_backend=local_backend,
        alsa_volume=alsa_volume,
        feedback=feedback,
        settings_store=settings_store,
        enc_volume_step=settings.enc_volume_step,
    )

    # GPIO (nur wenn auf echtem Pi verfügbar)
    button_handler = None
    encoder_handler = None
    try:
        from musicbox.gpio.buttons import ButtonHandler
        from musicbox.gpio.encoder import EncoderHandler

        button_handler = ButtonHandler(
            queue=event_queue,
            loop=loop,
            pin_play_pause=settings.gpio_play_pause,
            pin_next=settings.gpio_next,
            pin_prev=settings.gpio_prev,
            bounce_ms=settings.btn_bounce_ms,
            # Ein Knopf ohne Lang-Aktion feuert schon beim Drücken. Die
            # Belegung wird beim Start gelesen; wer später eine Lang-Aktion
            # einstellt, bekommt beim nächsten Start wieder das Loslassen.
            long_belegt=lambda btn: (
                settings_store.data.get("buttons", {})
                .get(btn, {}).get("long", "none") != "none"),
        )
        button_handler.start()

        encoder_handler = EncoderHandler(
            queue=event_queue,
            loop=loop,
            pin_clk=settings.gpio_enc_clk,
            pin_dt=settings.gpio_enc_dt,
            pin_sw=settings.gpio_enc_sw,
        )
        encoder_handler.start()
    except Exception:
        log.warning("GPIO nicht verfügbar — Buttons/Encoder deaktiviert")

    ipc_server = IPCServer(settings.control_socket, event_queue)

    # SSE-Listener für Spotify-Statusänderungen
    async def on_spotify_event(event: dict) -> None:
        kind = event.get("type")
        if kind == "stopped":
            await controller.on_spotify_stopped()
        elif kind == "will_play":
            uri = (event.get("data") or {}).get("uri", "")
            event_queue.put_nowait({"event": "spotify_will_play", "uri": uri})

    spotify_backend.start_sse_listener(on_spotify_event)

    # Shutdown-Handler
    stop_event = asyncio.Event()

    def _on_signal():
        log.info("Signal empfangen, beende ...")
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _on_signal)

    await feedback.play("startup")
    log.info("MusicBox Core gestartet")

    tasks = [
        asyncio.create_task(controller.run(event_queue), name="controller"),
        asyncio.create_task(ipc_server.serve(), name="ipc-server"),
        asyncio.create_task(_periodic_reload(mapping_store, settings_store), name="reload"),
        asyncio.create_task(_bt_watch(event_queue), name="bt-watch"),
    ]
    if rfid_reader:
        tasks.append(asyncio.create_task(
            rfid_reader.poll_forever(event_queue), name="rfid-reader"
        ))

    await stop_event.wait()

    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)

    if button_handler:
        button_handler.stop()
    if encoder_handler:
        encoder_handler.stop()
    await spotify_backend.close()
    log.info("MusicBox Core beendet")


def run() -> None:
    asyncio.run(_amain())


if __name__ == "__main__":
    run()
