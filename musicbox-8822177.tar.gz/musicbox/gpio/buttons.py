"""ButtonHandler: gpiozero Buttons → asyncio.Queue Events.

Jeder der drei Knöpfe sendet ein generisches Event
  {"event": "button", "btn": "btn1|btn2|btn3", "press": "short|long"}
Der Controller bildet btn+press über die Einstellungen auf eine Aktion ab.
Kurz = Tippen, Lang = halten für >= hold_time (Standard 5 s).

Wann ein Knopf feuert, hängt von seiner Belegung ab: Ohne Lang-Aktion löst er
schon beim **Drücken** aus — das fühlt sich unmittelbar an, statt die Zeit
abzuwarten, die der Finger auf dem Knopf liegt. Ist eine Lang-Aktion belegt,
bleibt es beim Loslassen; sonst wäre die Kurz-Aktion bereits passiert, bevor
der Lang-Druck überhaupt greifen kann.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Callable, Optional

log = logging.getLogger(__name__)

_HOLD_TIME = 5.0  # Sekunden bis "lang halten" auslöst


class ButtonHandler:
    def __init__(
        self,
        queue: asyncio.Queue,
        loop: asyncio.AbstractEventLoop,
        pin_play_pause: int,
        pin_next: int,
        pin_prev: int,
        bounce_ms: int = 50,
        hold_time: float = _HOLD_TIME,
        long_belegt: Optional[Callable[[str], bool]] = None,
    ) -> None:
        self._queue = queue
        self._loop = loop
        # btn1/btn2/btn3 = die drei physischen Knöpfe (in dieser Reihenfolge konfigurierbar)
        self._pins = {
            "btn1": pin_play_pause,
            "btn2": pin_next,
            "btn3": pin_prev,
        }
        self._bounce = bounce_ms / 1000
        self._hold_time = hold_time
        self._buttons: list = []
        self._held: dict[str, bool] = {}
        # Auskunft, ob für einen Knopf eine Lang-Aktion eingestellt ist. Ohne
        # Angabe bleibt es beim alten Verhalten — so verliert kein Knopf seine
        # Lang-Aktion, nur weil der Aufrufer die Einstellungen nicht kennt.
        self._long_belegt = long_belegt

    def start(self) -> None:
        from gpiozero import Button

        for btn_id, pin in self._pins.items():
            btn = Button(
                pin, pull_up=True, bounce_time=self._bounce, hold_time=self._hold_time
            )
            self._held[btn_id] = False
            bid = btn_id  # closure capture
            btn.when_held = lambda b=bid: self._on_held(b)
            if self._feuert_beim_druecken(btn_id):
                btn.when_pressed = lambda b=bid: self._emit(b, "short")
            else:
                btn.when_released = lambda b=bid: self._on_released(b)
            self._buttons.append(btn)
        sofort = [b for b in self._pins if self._feuert_beim_druecken(b)]
        log.info(
            "Buttons initialisiert: %s (lang halten = %.0fs, beim Drücken: %s)",
            list(self._pins.keys()),
            self._hold_time,
            ", ".join(sofort) or "keiner",
        )

    def _feuert_beim_druecken(self, btn_id: str) -> bool:
        """Ein Knopf ohne Lang-Aktion darf sofort auslösen.

        Eine unlesbare Einstellung führt zum alten Verhalten: Lieber ein Knopf,
        der sich träge anfühlt, als einer, der seine Lang-Aktion verliert.
        """
        if self._long_belegt is None:
            return False
        try:
            return not self._long_belegt(btn_id)
        except Exception:
            log.debug("Belegung von %s nicht lesbar — feuert beim Loslassen", btn_id)
            return False

    def _on_held(self, btn_id: str) -> None:
        self._held[btn_id] = True
        self._emit(btn_id, "long")

    def _on_released(self, btn_id: str) -> None:
        if self._held.get(btn_id):
            self._held[btn_id] = False  # war ein Lang-Druck → kein zusätzliches Kurz-Event
        else:
            self._emit(btn_id, "short")

    def _emit(self, btn_id: str, press: str) -> None:
        self._loop.call_soon_threadsafe(
            self._queue.put_nowait, {"event": "button", "btn": btn_id, "press": press}
        )

    def stop(self) -> None:
        for btn in self._buttons:
            btn.close()
        self._buttons.clear()
