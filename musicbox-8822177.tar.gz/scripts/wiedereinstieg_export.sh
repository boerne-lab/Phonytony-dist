#!/usr/bin/env bash
# Schaltet den Track-Export von own-librespot an oder aus und spielt dabei
# optional ein mitgebrachtes Binary ein.
#
# Der Export bleibt im Alltag bewusst abgeschaltet: Er zieht den vollständigen
# Strom zusätzlich zur Wiedergabe, und das WLAN der Box verträgt das nicht
# immer. Für einen Testlauf schaltet dieses Skript ihn ein — und wieder aus.
#
# Auf der Box als root ausführen:
#
#   sudo bash wiedereinstieg_export.sh /tmp/own-librespot-arm64   # Binary + Export an
#   sudo bash wiedereinstieg_export.sh                            # nur Export an
#   sudo bash wiedereinstieg_export.sh --aus                      # Export aus
#
# Danach einen Titel abspielen und pruefe_export.sh laufen lassen.

set -euo pipefail

BINARY="${1:-}"
CFG="/etc/musicbox/config.yml"

if [ "$(id -u)" -ne 0 ]; then
    echo "FEHLER: bitte mit sudo ausführen." >&2
    exit 1
fi

# Schaltet download.enabled um — und zwar NUR dort.
#
# Ein naheliegendes `sed 's/enabled: true/enabled: false/'` trifft auch
# server.enabled und legt damit die HTTP-API von own-librespot still. Die Box
# kann dann keine einzige Spotify-Karte mehr abspielen, und der Fehler sieht im
# Journal so aus, als läge er am Daemon. Genau das ist hier schon passiert;
# deshalb steht die Umschaltung als Funktion im Skript statt als Einzeiler in
# einem Hinweistext, den jemand kopiert.
schalte_export() {
    local wert="$1"
    python3 - "$CFG" "$wert" <<'PYEOF'
import re
import sys

pfad, wert = sys.argv[1], sys.argv[2]
gegenwert = "false" if wert == "true" else "true"
text = open(pfad).read()

if not re.search(r"(?m)^download:", text):
    print(f"FEHLER: kein download-Block in {pfad}.", file=sys.stderr)
    raise SystemExit(1)

def um(treffer):
    return treffer.group(0).replace(f"enabled: {gegenwert}", f"enabled: {wert}")

neu = re.sub(r"(?ms)^download:.*?(?=^\S|\Z)", um, text)

if neu == text:
    print(f"   download.enabled war schon {wert}")
else:
    open(pfad, "w").write(neu)
    print(f"   download.enabled auf {wert} gesetzt")

# Gegenprobe: Die API darf dabei unter keinen Umständen abgeschaltet worden sein.
server = re.search(r"(?ms)^server:.*?(?=^\S|\Z)", neu)
if server and "enabled: false" in server.group(0):
    print("FEHLER: server.enabled steht auf false — die API wäre still.", file=sys.stderr)
    raise SystemExit(1)
PYEOF
}

if [ "$BINARY" = "--aus" ]; then
    echo ">> Track-Export abschalten"
    schalte_export false
    systemctl restart own-librespot
    # Der Daemon meldet sich erst bei Spotify an, bevor er bereitsteht; nach
    # vier Sekunden war er hier regelmäßig noch nicht so weit, und das Skript
    # warnte, obwohl alles in Ordnung war. Eine Falschmeldung an dieser Stelle
    # ist teuer: Sie schickt einen auf die Suche nach einem Fehler, den es
    # nicht gibt — genau das hat hier schon einmal Zeit gekostet.
    for _ in 1 2 3 4 5 6 7 8 9 10; do
        sleep 2
        if [ "$(curl -s --max-time 3 -o /dev/null -w '%{http_code}' \
                http://127.0.0.1:3678/status)" = "200" ]; then
            echo "   own-librespot läuft und antwortet"
            exit 0
        fi
    done
    echo "   WARNUNG: own-librespot antwortet nach 20 s nicht" >&2
    systemctl is-active --quiet own-librespot \
        || echo "   der Dienst läuft auch nicht" >&2
    exit 0
fi

if [ -n "$BINARY" ]; then
    if [ ! -s "$BINARY" ]; then
        echo "FEHLER: $BINARY ist leer oder fehlt." >&2
        exit 1
    fi
    echo ">> Binary einspielen"
    # Den laufenden Stand beiseitelegen, damit ein Rückschritt möglich bleibt.
    if [ -f /usr/local/bin/own-librespot ]; then
        cp /usr/local/bin/own-librespot "/usr/local/bin/own-librespot.vorher"
    fi
    install -m 0755 "$BINARY" /usr/local/bin/own-librespot
    echo "   $(stat -c '%s Bytes' /usr/local/bin/own-librespot)"

    # Fehlende Bibliotheken sind der häufigste Startfehler und in der Meldung
    # von systemd schlecht zu sehen. Die Box lief zeitweise auf einer anderen
    # Debian-Generation als das Bausystem — dabei fiel genau das auf.
    fehlend="$(ldd /usr/local/bin/own-librespot 2>/dev/null | grep 'not found' || true)"
    if [ -n "$fehlend" ]; then
        echo "FEHLER: dem Binary fehlen Bibliotheken auf diesem System:" >&2
        echo "$fehlend" >&2
        echo "   Gegen die Bibliotheken dieser Box bauen (Debian $(. /etc/os-release; echo "$VERSION_ID"))." >&2
        exit 1
    fi
    echo "   alle Bibliotheken vorhanden"
fi

echo ">> Track-Export einschalten"
schalte_export true

echo ">> Dienst neu starten"
systemctl restart own-librespot

# Der Daemon braucht ein paar Sekunden bis zur Anmeldung; ein Wiedergabebefehl
# davor läuft ins Leere.
for _ in 1 2 3 4 5 6 7 8 9 10; do
    sleep 3
    if [ "$(curl -s --max-time 4 -o /dev/null -w '%{http_code}' http://127.0.0.1:3678/status)" = "200" ]; then
        bereit=ja
        break
    fi
done

if [ "${bereit:-nein}" != "ja" ]; then
    echo "FEHLER: die API von own-librespot antwortet nicht." >&2
    echo "   Steht server.enabled in $CFG auf true?" >&2
    journalctl -u own-librespot -n 15 --no-pager >&2
    exit 1
fi

version="$(journalctl -u own-librespot -n 40 --no-pager | grep -oE 'running go-librespot [0-9a-f]+' | tail -1)"
echo "   läuft und antwortet — $version"

echo
echo "Nächste Schritte:"
echo "  1. Einen Titel über Spotify Connect abspielen (oder eine Karte auflegen)"
echo "  2. bash /opt/musicbox/scripts/pruefe_export.sh"
echo
echo "Nach dem Test den Export wieder abschalten, solange die Box zum Hören"
echo "genutzt wird — er zieht den vollständigen Strom zusätzlich zur Wiedergabe:"
echo "  sudo bash $0 --aus"
