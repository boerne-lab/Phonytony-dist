#!/usr/bin/env bash
# Deployt einen gestageten Stand nach /opt/musicbox, installiert/aktiviert die
# System-Teile (Self-Update + WLAN-Onboarding + PipeWire/Bluetooth), kopiert Sounds
# und startet neu.
#
# WICHTIG: Ab dem PipeWire-Stand ist dieses Skript der einzige Weg, eine bestehende
# Box zu migrieren. Der Self-Updater tauscht nur Code aus und installiert weder
# Pakete noch sudoers — eine per Auto-Update auf diesen Stand gesprungene, aber
# unmigrierte Box hat kein PipeWire und bleibt stumm.
# Auf der Box als root ausführen:
#
#   sudo bash /home/pi/musicbox-deploy/scripts/box_deploy.sh
#
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "FEHLER: bitte mit sudo ausführen:  sudo bash $0" >&2
  exit 1
fi

SRC="${1:-/home/pi/musicbox-deploy}"
DEST="/opt/musicbox"
DATA="${MUSICBOX_DATA_DIR:-/var/lib/musicbox}"
OWNER="musicbox:musicbox"

echo ">> Sync $SRC/ -> $DEST/"
# Eigentümer/Gruppe der Quelle (pi) NICHT übernehmen, sondern direkt musicbox setzen.
rsync -rlptD --delete --chown="$OWNER" \
  --exclude '.git' --exclude 'venv' --exclude 'data' --exclude 'config' \
  --exclude '__pycache__' --exclude '*.pyc' --exclude '.pytest_cache' \
  "$SRC"/ "$DEST"/
chown -R "$OWNER" "$DEST"

# Installierte Version (für Self-Update-Vergleich)
if [ -f "$SRC/VERSION" ]; then
  cp "$SRC/VERSION" "$DEST/VERSION"
else
  echo "deploy" > "$DEST/VERSION"
fi
chown "$OWNER" "$DEST/VERSION"

# Ablösung von go-librespot durch own-librespot: Der alte Dienst muss weg,
# BEVOR der neue startet — beide würden sonst dasselbe Audiogerät und dieselbe
# API-Adresse (127.0.0.1:3678) belegen.
if [ -f /etc/systemd/system/go-librespot.service ]; then
  echo ">> Ablösung: go-librespot abräumen (ersetzt durch own-librespot)"
  systemctl stop go-librespot 2>/dev/null || true
  systemctl disable go-librespot 2>/dev/null || true
  rm -f /etc/systemd/system/go-librespot.service
  rm -rf /etc/systemd/system/go-librespot.service.d
  rm -f /usr/local/bin/go-librespot
  systemctl daemon-reload
fi

echo ">> systemd-Units installieren"
cp "$DEST/systemd/"*.service /etc/systemd/system/
cp "$DEST/systemd/"*.timer  /etc/systemd/system/ 2>/dev/null || true

systemctl daemon-reload

# ── Bootzeit: was gemessen etwas bringt ─────────────────────────────────────
# Messwerte vom 24.08.2026 (absolut seit Kernel-Start):
#   vorher   Kernel 4,38 s | Core 11,9 s | Ton ~20 s | gesamt 21,3 s
#   nachher  Kernel 2,99 s | Core 11,2 s | Ton ~19,9 s | gesamt 19,9 s
# Der Gewinn steckt fast vollständig im weggelassenen initramfs. Was NICHT
# wirkte, steht in docs/superpowers/notes/2026-08-24-boot-und-startton.md —
# dort auch die verbliebenen großen Posten (Benutzersitzung 9 s für PipeWire,
# NetworkManager 7 s).
echo ">> Bootzeit: bildschirmloses Ziel und entbehrliche Dienste"
# graphical.target zieht display-manager und udisks2 nach. Die Box hat keinen
# Bildschirm und keine Wechselmedien.
systemctl set-default multi-user.target >/dev/null

# avahi: own-librespot bringt einen eigenen mDNS-Responder mit.
# rpi-resize-swap-file: läuft bei jedem Boot, obwohl die Swap-Datei längst passt.
# udisks2: für Wechselmedien, die es hier nicht gibt.
for dienst in avahi-daemon.service avahi-daemon.socket \
              rpi-resize-swap-file.service udisks2.service; do
  systemctl disable --now "$dienst" >/dev/null 2>&1 || true
done

# Der Entsperr-Dienst rief rfkill auf, bevor /dev/rfkill existierte. Die
# Rennbedingung gab es schon vorher, sie ging nur meist gut aus; ohne initramfs
# fällt sie zuverlässig auf.
if systemctl list-unit-files wifi-rfkill-unblock.service >/dev/null 2>&1; then
  install -d /etc/systemd/system/wifi-rfkill-unblock.service.d
  install -m0644 "$DEST/systemd/wifi-rfkill-warten.conf" \
      /etc/systemd/system/wifi-rfkill-unblock.service.d/warten.conf
fi

# Das initramfs kostet 1,4 s: 16 MB lesen, entpacken, eigenes /init laufen
# lassen — nur um dann dasselbe Root einzubinden, das der Kernel auch selbst
# einbinden kann. Voraussetzung ist, dass Dateisystem und SD-Treiber fest im
# Kernel sind; ohne sie startet die Box nicht mehr, und die Rettung geht nur
# über die ausgebaute SD-Karte. Deshalb wird das hier geprüft, nicht geglaubt.
BOOTCFG="/boot/firmware/config.txt"
KCFG="/boot/config-$(uname -r)"
if [ -f "$BOOTCFG" ] && [ -f "$KCFG" ] \
   && grep -q "^CONFIG_EXT4_FS=y" "$KCFG" \
   && grep -qE "^CONFIG_MMC_(BCM2835|SDHCI_IPROC)=y" "$KCFG"; then
  cp -n "$BOOTCFG" "$BOOTCFG.vor-boot-tuning" 2>/dev/null || true
  if grep -q "^auto_initramfs=1" "$BOOTCFG"; then
    sed -i "s/^auto_initramfs=1/auto_initramfs=0/" "$BOOTCFG"
    echo "   initramfs abgeschaltet (Sicherung: $BOOTCFG.vor-boot-tuning)"
  fi
else
  echo "   initramfs bleibt an: Voraussetzungen nicht nachweisbar"
fi

# Der Boot hängt an der Lesegeschwindigkeit der SD-Karte, nicht am Kernel: Der
# Kernel sieht die Karte bei 2,3 s und hat Root bei 2,5 s eingebunden, aber
# systemd braucht von seinem Start (3,1 s) bis zur ersten fertigen Unit (6,4 s)
# über drei Sekunden — in denen PID 1 im Wesentlichen Unit-Dateien von genau
# dieser Karte liest. Mit 84 statt 50 MHz Bustakt liest sie 36 statt 23 MB/s.
# Gemessen (25.08.2026, je drei bzw. zwei Neustarts, keine Überlappung):
#   ohne   gesamt 20,3-20,7 s | Ton 14,2-14,6 s
#   mit    gesamt 18,2-18,5 s | Ton 12,6-12,8 s
# ACHTUNG, kartenabhängig: 100 MHz hielt die hier verbaute Karte NICHT — der
# Treiber meldete "reducing overclock due to errors" und regelte selbst auf
# 80 MHz zurück. Deshalb der vorsichtige Wert 84, und deshalb wird eine Karte,
# die bereits Übertaktungsfehler meldet, wieder auf den Normaltakt gesetzt.
# (dtoverlay=sdtweak führt hier nicht zum Ziel: das Overlay ist abgekündigt,
#  die .dtbo fehlt, und die Firmware ignoriert die Zeile kommentarlos.)
if [ -f "$BOOTCFG" ]; then
  cp -n "$BOOTCFG" "$BOOTCFG.vor-boot-tuning" 2>/dev/null || true
  if dmesg 2>/dev/null | grep -qi "reducing overclock"; then
    if grep -q "^dtparam=sd_overclock=" "$BOOTCFG"; then
      sed -i "/^dtparam=sd_overclock=/d" "$BOOTCFG"
      echo "   SD-Takt zurückgenommen: diese Karte meldet Übertaktungsfehler"
    else
      echo "   SD-Takt nicht gesetzt: diese Karte meldet Übertaktungsfehler"
    fi
  elif ! grep -q "^dtparam=sd_overclock=" "$BOOTCFG"; then
    echo "dtparam=sd_overclock=84" >> "$BOOTCFG"
    echo "   SD-Bustakt auf 84 MHz (Sicherung: $BOOTCFG.vor-boot-tuning)"
    echo "   Nach dem Neustart prüfen: dmesg | grep -i 'reducing overclock'"
    echo "   Ein Treffer heißt: Wert senken oder Zeile entfernen."
  fi
fi

# PipeWire läuft in der Benutzersitzung, und deren Manager trägt ein implizites
# After=systemd-user-sessions.service — systemd ergänzt das selbst, es steht in
# keiner Unit-Datei. systemd-user-sessions wiederum wartet auf network.target.
# Damit hing jeder Ton hinter der WLAN-Anmeldung: Ton bei 20,1 s statt 14,4 s.
# Ein Drop-In mit After= (Reset) wirkt hier NICHT; nur eine Datei in /etc, die
# die Originalunit vollständig ersetzt, hebt die Abhängigkeit auf.
echo ">> Ton nicht hinter der WLAN-Anmeldung anstellen"
install -m0644 "$DEST/systemd/systemd-user-sessions-ohne-netz.service" \
    /etc/systemd/system/systemd-user-sessions.service

echo ">> Bootlast ordnen: Musik zuerst"
# Die Benutzersitzung mit PipeWire startet im Leerlauf in 1,04 s, beim Boot
# erst nach 9 s — der Unterschied ist CPU-Konkurrenz auf vier schwachen Kernen.
# Abgeschaltet wird nichts; was zum Abspielen nicht gebraucht wird, tritt nur
# zurück.
for unit in musicbox-core own-librespot musicbox-web musicbox-netwatch; do
  if [ -f "$DEST/systemd/prio-$unit.conf" ]; then
    install -d "/etc/systemd/system/$unit.service.d"
    install -m0644 "$DEST/systemd/prio-$unit.conf" \
        "/etc/systemd/system/$unit.service.d/prio.conf"
  fi
done
# PipeWire hängt an der Slice der Benutzersitzung, nicht an einer Unit.
install -d "/etc/systemd/system/user-${MB_UID:-$(id -u musicbox)}.slice.d"
install -m0644 "$DEST/systemd/prio-user-slice.conf" \
    "/etc/systemd/system/user-${MB_UID:-$(id -u musicbox)}.slice.d/prio.conf"
systemctl daemon-reload

echo ">> sudoers-Drop-ins (Update + WLAN + Shutdown + Bluetooth)"
install -m0440 "$DEST/systemd/musicbox-update.sudoers" /etc/sudoers.d/musicbox-update
install -m0440 "$DEST/systemd/musicbox-wifi.sudoers"   /etc/sudoers.d/musicbox-wifi
install -m0440 "$DEST/systemd/musicbox-shutdown.sudoers" /etc/sudoers.d/musicbox-shutdown
install -m0440 "$DEST/systemd/musicbox-bluetooth.sudoers" /etc/sudoers.d/musicbox-bluetooth
chmod 0755 "$DEST/scripts/bt_helper.sh"
chmod 0755 "$DEST/scripts/bt_watchdog.sh"
visudo -cf /etc/sudoers.d/musicbox-update >/dev/null
visudo -cf /etc/sudoers.d/musicbox-wifi   >/dev/null
visudo -cf /etc/sudoers.d/musicbox-shutdown >/dev/null
visudo -cf /etc/sudoers.d/musicbox-bluetooth >/dev/null

# ── Migration einer bestehenden Box auf PipeWire + Bluetooth ────────────────
# Reihenfolge wie im Spike belegt (docs/superpowers/notes/2026-08-22-pipewire-spike.md):
# Pakete → Dienste stoppen → asound.conf entfernen → Linger/Drop-ins/WirePlumber-Konfig/
# Maskierung/bt-power → wireplumber neu starten → Dienste starten (weiter unten).
# Ohne das Stoppen der Dienste hält die alte dmix-Konfiguration die WM8960-Karte
# exklusiv und PipeWire sieht nur auto_null.
echo ">> PipeWire + Bluetooth-Stack installieren"
apt-get update -qq
apt-get install -y \
  pipewire pipewire-audio pipewire-alsa pipewire-pulse wireplumber \
  libspa-0.2-bluetooth pulseaudio-utils bluez rfkill

echo ">> Dienste für die Audio-Umstellung stoppen"
systemctl stop own-librespot go-librespot musicbox-core musicbox-web 2>/dev/null || true

# dmix beiseite: PipeWire mischt selbst. Sicherungskopie fürs Rollback.
if [ -f /etc/asound.conf ]; then
  cp -n /etc/asound.conf /etc/asound.conf.dmix-backup || true
  rm -f /etc/asound.conf
  echo "   /etc/asound.conf entfernt (Sicherung: /etc/asound.conf.dmix-backup)"
fi

echo ">> PipeWire: Linger + XDG_RUNTIME_DIR-Drop-ins"
loginctl enable-linger "musicbox" || true
MB_UID="$(id -u musicbox)"
for unit in musicbox-core musicbox-web own-librespot; do
  mkdir -p "/etc/systemd/system/${unit}.service.d"
  cat > "/etc/systemd/system/${unit}.service.d/pipewire.conf" << EOF
[Service]
Environment=XDG_RUNTIME_DIR=/run/user/${MB_UID}
Environment=PULSE_RUNTIME_PATH=/run/user/${MB_UID}/pulse
EOF
done
systemctl daemon-reload
sudo -u musicbox XDG_RUNTIME_DIR="/run/user/${MB_UID}" \
  systemctl --user enable pipewire pipewire-pulse wireplumber || true

echo ">> BlueZ-Einstellungen (Class/FastConnectable/JustWorksRepairing/AutoEnable)"
echo ">> Persistentes Journal (mit Deckel gegen SD-Verschleiß)"
# Ohne das schreibt journald nach /run und die Fehlerhistorie ist nach jedem
# Neustart weg — genau die Fälle, die man untersuchen will, überleben dann nicht.
mkdir -p /etc/systemd/journald.conf.d /var/log/journal
install -m0644 "$DEST/systemd/journald-musicbox.conf" \
  /etc/systemd/journald.conf.d/50-musicbox.conf
systemd-tmpfiles --create --prefix /var/log/journal >/dev/null 2>&1 || true
systemctl restart systemd-journald || true
# Der Neustart allein lässt das bereits geschriebene Journal unter /run liegen —
# erst der Flush schiebt es nach /var/log/journal, sonst wirkt der Umstieg erst
# nach dem nächsten Boot.
journalctl --flush >/dev/null 2>&1 || true

# --- BlueZ: Box-eigene Einstellungen in /etc/bluetooth/main.conf ---
# main.conf ist eine Paketdatei voller auskommentierter Vorgaben. Deshalb wird sie nicht
# ersetzt, sondern nur um einen klar markierten Block am Ende ergaenzt; ein erneuter Lauf
# entfernt den alten Block zuerst (idempotent, keine Duplikate). Vorher eine Sicherung.
apply_bluetooth_main_conf() {
    local root="${1:-}"
    local conf="$root/etc/bluetooth/main.conf"
    mkdir -p "$root/etc/bluetooth"
    [ -f "$conf" ] || : > "$conf"
    cp -n "$conf" "$conf.bak" 2>/dev/null || true
    # Fassungen aus der Zeit vor den Markern mitnehmen: sie beginnen mit einer
    # "# --- Musicbox: ..."-Ueberschrift und reichen bis zum Marker-Block bzw. bis
    # zum Dateiende. Ohne das bleibt der alte Block fuer immer liegen und der
    # Block steht doppelt in der Datei (auf der Box so vorgefunden).
    sed -i '/^# --- Musicbox:/,/^# >>> musicbox-bluetooth >>>$/{/^# >>> musicbox-bluetooth >>>$/!d}' "$conf"
    sed -i '/^# >>> musicbox-bluetooth >>>$/,/^# <<< musicbox-bluetooth <<<$/d' "$conf"
    # Nachlaufende Leerzeilen abschneiden, damit der Block bei jedem Lauf gleich aussieht.
    printf '%s\n' "$(cat "$conf")" > "$conf"
    {
        echo
        echo "# >>> musicbox-bluetooth >>>"
        cat "$DEST/systemd/bluetooth-main.conf.block"
        echo "# <<< musicbox-bluetooth <<<"
    } >> "$conf"
}

apply_bluetooth_main_conf
# Der Neustart von bluetooth.service kommt bewusst erst NACH dem WirePlumber-
# Neustart weiter unten (siehe dort) — hier wäre er zu früh.

echo ">> WirePlumber: Headless-Bluetooth-Konfiguration"
# Seat-Monitoring aus (musicbox ist ein lingernder Systemnutzer ohne Seat) und
# Rollenbeschränkung auf a2dp_source (die Box ist die Quelle, der Kopfhörer die Senke).
mkdir -p /etc/wireplumber/wireplumber.conf.d
install -m0644 "$DEST/systemd/wireplumber-headless-bluetooth.conf" \
  /etc/wireplumber/wireplumber.conf.d/50-headless-bluetooth.conf

echo ">> PipeWire für Login-Nutzer maskieren (nur musicbox betreibt den Soundserver)"
# Zwei parallele Soundserver streiten sich um denselben A2DP-Transport — der
# Kopfhörer-Sink verschwindet dann aus PipeWire des Dienstnutzers.
mask_pipewire_for_home() {
  local home="$1" owner="$2"
  mkdir -p "$home/.config/systemd/user"
  for unit in pipewire.service pipewire.socket pipewire-pulse.service pipewire-pulse.socket wireplumber.service; do
    ln -sf /dev/null "$home/.config/systemd/user/$unit"
  done
  if [ -n "$owner" ]; then chown -R "$owner:$owner" "$home/.config"; fi
}
while IFS=: read -r uname _ uid _ _ uhome _; do
  [ "$uid" -ge 1000 ] || continue
  [ -d "$uhome" ] || continue
  mask_pipewire_for_home "$uhome" "$uname"
done < /etc/passwd
mask_pipewire_for_home /etc/skel ""

echo ">> own-librespot auf PipeWire umstellen"
# Auf einer bestehenden Box zeigt /etc/musicbox/config.yml noch auf die dmix-Karte
# und synchronisiert die Lautstärke mit dem WM8960-Mixer — der für Bluetooth nicht gilt.
LIBRESPOT_CFG="/etc/musicbox/config.yml"
if [ -f "$LIBRESPOT_CFG" ]; then
  cp -n "$LIBRESPOT_CFG" "$LIBRESPOT_CFG.bak" || true
  sed -i -E 's|^[[:space:]]*audio_device:.*|audio_device: "pipewire"|' "$LIBRESPOT_CFG"
  sed -i -E 's|^[[:space:]]*(mixer_device:.*)|# \1  # PipeWire-Migration: kein ALSA-Mixer-Sync|' "$LIBRESPOT_CFG"
  sed -i -E 's|^[[:space:]]*(mixer_control_name:.*)|# \1  # PipeWire-Migration: kein ALSA-Mixer-Sync|' "$LIBRESPOT_CFG"

  # Track-Export des eigenen Forks: Die Konfiguration einer bestehenden Box wird
  # bewusst nie überschrieben (cp -n), der Block käme also sonst nie an.
  if ! grep -q '^download:' "$LIBRESPOT_CFG"; then
    cat >> "$LIBRESPOT_CFG" << 'DLEOF'

# Track-Export (own-librespot): legt beim Abspielen die entschlüsselte Datei ab.
# size_limit bleibt 0 — die Musikbox räumt die Dateien in ihre eigene Bibliothek
# um und verwaltet den Platz selbst.
download:
  enabled: true
  dir: "/var/lib/musicbox/spotify-downloads"
  size_limit: "0"
DLEOF
    echo "   Download-Block ergänzt"
  fi
fi

# Zielordner des Exports anlegen; der Daemon bricht sonst beim Start ab.
install -d -o musicbox -g musicbox -m 0755 "$DATA/spotify-downloads"

echo ">> Bluetooth-Adapter beim Boot entsperren (musicbox-bt-power)"
systemctl enable musicbox-bt-power >/dev/null 2>&1 || true
systemctl restart musicbox-bt-power || true

echo ">> Bluetooth-Wachhund aktivieren (musicbox-bt-watchdog, alle 5 Minuten)"
systemctl enable musicbox-bt-watchdog.timer >/dev/null 2>&1 || true
systemctl restart musicbox-bt-watchdog.timer || true

echo ">> WirePlumber und Bluetooth-Controller neu aufsetzen"
# Teuer gelernt, zweimal auf der Box gemessen: Wenn die Box ihre Rollen ändert
# (a2dp_source, hfp_ag, hsp_ag), genügt ein Neustart von bluetooth.service NICHT.
# Der Controller quittiert dann jede UUID mit "Failed to add UUID: Authentication
# Failed (0x05)" und ist anschließend funktaub (Inquiry findet nichts, 0 RSSI).
# Was zuverlässig funktioniert, ist die Neubindung des UART-Treibers: dabei wird
# die Controller-Firmware neu geladen. Danach: null Fehler, beide Profile
# registriert, Funk lebt. Derselbe Griff, den bt_watchdog.sh zur Heilung nutzt.
BT_UART_DRIVER="/sys/bus/serial/drivers/hci_uart_bcm"

bt_uart_device() {
  local entry name
  for entry in "$BT_UART_DRIVER"/*; do
    [ -L "$entry" ] || continue
    name="$(basename "$entry")"
    case "$name" in bind|unbind|uevent|module|bind_mode) continue ;; esac
    printf '%s' "$name"; return 0
  done
  return 1
}

systemctl stop bluetooth || true
# WirePlumber setzt seine Rollen neu auf, während bluetoothd aus ist.
sudo -u musicbox XDG_RUNTIME_DIR="/run/user/${MB_UID}" \
  systemctl --user restart pipewire pipewire-pulse wireplumber || true
sleep 2

bt_dev="$(bt_uart_device || true)"
if [ -n "$bt_dev" ] && [ -w "$BT_UART_DRIVER/unbind" ]; then
  echo "   Controller-Firmware neu laden ($bt_dev)"
  printf '%s' "$bt_dev" > "$BT_UART_DRIVER/unbind" 2>/dev/null || true
  sleep 3
  printf '%s' "$bt_dev" > "$BT_UART_DRIVER/bind" 2>/dev/null || true
  sleep 5
else
  # Andere Hardware (USB-Dongle o. ä.) — dort gibt es diesen Treiber nicht.
  echo "   Kein hci_uart_bcm gefunden, nur bluetooth.service neu starten"
fi

systemctl restart bluetooth || true
sleep 3
# Adapter-Flags (piscan, pairable) leben im Kernel und sind nach der Neubindung weg.
systemctl restart musicbox-bt-power || true

echo ">> WLAN-Onboarding: AP-Profil, Captive-DNS, tmpfiles"
install -m600 -o root -g root "$DEST/systemd/musicbox-ap.nmconnection" \
  /etc/NetworkManager/system-connections/musicbox-ap.nmconnection
mkdir -p /etc/NetworkManager/dnsmasq-shared.d
cp "$DEST/systemd/captive-dnsmasq.conf" /etc/NetworkManager/dnsmasq-shared.d/captive.conf
cp "$DEST/systemd/musicbox-tmpfiles.conf" /etc/tmpfiles.d/musicbox.conf
systemd-tmpfiles --create /etc/tmpfiles.d/musicbox.conf || true
nmcli connection reload || true

echo ">> Bestätigungstöne kopieren -> $DATA/sounds"
mkdir -p "$DATA/sounds"
cp "$DEST"/musicbox/audio/sounds/*.wav "$DATA/sounds/"
chown -R "$OWNER" "$DATA/sounds"

echo ">> Dienste aktivieren/neu starten"
systemctl enable musicbox-update.timer musicbox-netwatch >/dev/null 2>&1 || true
# own-librespot mit neu starten: es wurde für die Audio-Umstellung gestoppt und
# braucht das XDG_RUNTIME_DIR-Drop-in, um PipeWire zu erreichen.
systemctl enable own-librespot >/dev/null 2>&1 || true
systemctl restart own-librespot musicbox-core musicbox-web
systemctl start  musicbox-update.timer musicbox-netwatch || true
sleep 2
for u in own-librespot musicbox-core musicbox-web musicbox-netwatch; do
  printf "  %-18s " "$u:"; systemctl is-active "$u" || true
done
printf "  %-18s " "musicbox-update.timer:"; systemctl is-active musicbox-update.timer || true
printf "  %-18s " "musicbox-bt-watchdog.timer:"; systemctl is-active musicbox-bt-watchdog.timer || true

echo ">> Rauchtest"
# Auf den Web-Start warten (uvicorn braucht auf dem Pi Zero ein paar Sekunden)
for _ in $(seq 1 20); do
  curl -s -o /dev/null "http://localhost:8080/" && break
  sleep 1
done
smoke_failed=0
for p in / /cards /playlists /device /device/setup /device/wifi; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:8080$p" || echo "ERR")
  echo "  $p -> $code"
  [ "$code" = "200" ] || smoke_failed=1
done
if [ "$smoke_failed" = "1" ]; then
  echo "FEHLER: Rauchtest fehlgeschlagen — mindestens eine Seite lieferte keinen 200er." >&2
  exit 1
fi

echo ">> Fertig. Für die Spotify-Bibliothek im Web-UI einmal 'Spotify neu verbinden'."
