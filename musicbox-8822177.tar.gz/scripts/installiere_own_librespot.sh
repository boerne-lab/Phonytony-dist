#!/usr/bin/env bash
# Tauscht go-librespot gegen ein mitgebrachtes own-librespot-Binary aus.
#
# Für den ersten Versuch gedacht, solange es noch kein Release gibt: Das Binary
# wird von Hand mitgebracht statt heruntergeladen. Sobald der Release-Workflow
# im Fork gelaufen ist, erledigt setup.sh dasselbe von selbst.
#
# Auf der Box als root ausführen:
#
#   sudo bash installiere_own_librespot.sh /pfad/zum/own-librespot-arm64
#
# Rückgängig machen: das alte Binary wieder einspielen und den alten Dienst
# aktivieren. Die Sicherungskopie der Konfiguration liegt daneben.

set -euo pipefail

BINARY="${1:-}"
DATA="${MUSICBOX_DATA_DIR:-/var/lib/musicbox}"
CFG="/etc/musicbox/config.yml"
DL_DIR="$DATA/spotify-downloads"

if [ "$(id -u)" -ne 0 ]; then
    echo "FEHLER: bitte mit sudo ausführen:  sudo bash $0 <binary>" >&2
    exit 1
fi

if [ -z "$BINARY" ] || [ ! -s "$BINARY" ]; then
    echo "FEHLER: Binary angeben:  sudo bash $0 /pfad/zum/own-librespot-arm64" >&2
    exit 1
fi

echo ">> Binary prüfen"
if ! head -c 20 "$BINARY" | grep -q ELF; then
    echo "FEHLER: $BINARY ist keine ausführbare Datei." >&2
    exit 1
fi
echo "   $(stat -c '%s Bytes' "$BINARY")"

echo ">> Alten Dienst abräumen"
systemctl stop go-librespot 2>/dev/null || true
systemctl disable go-librespot 2>/dev/null || true
if [ -f /usr/local/bin/go-librespot ]; then
    mv /usr/local/bin/go-librespot "/usr/local/bin/go-librespot.vor-own-$(date +%Y%m%d)"
    echo "   altes Binary beiseitegelegt"
fi

echo ">> Neues Binary einspielen"
install -m 0755 "$BINARY" /usr/local/bin/own-librespot

echo ">> Unit installieren"
UNIT_QUELLE="/opt/musicbox/systemd/own-librespot.service"
if [ -f "$UNIT_QUELLE" ]; then
    cp "$UNIT_QUELLE" /etc/systemd/system/own-librespot.service
else
    echo "   (keine Unit unter $UNIT_QUELLE — box_deploy.sh zuerst laufen lassen)" >&2
    exit 1
fi

# Das PipeWire-Drop-in des alten Dienstes gilt nicht für den neuen Namen.
MB_UID="$(id -u musicbox)"
mkdir -p /etc/systemd/system/own-librespot.service.d
cat > /etc/systemd/system/own-librespot.service.d/pipewire.conf << EOF
[Service]
Environment=XDG_RUNTIME_DIR=/run/user/${MB_UID}
EOF
rm -rf /etc/systemd/system/go-librespot.service.d
rm -f /etc/systemd/system/go-librespot.service
systemctl daemon-reload

echo ">> Konfiguration ergänzen"
if [ -f "$CFG" ]; then
    cp -n "$CFG" "$CFG.vor-own-librespot" || true
    if grep -q '^download:' "$CFG"; then
        echo "   download-Block ist schon da"
    else
        cat >> "$CFG" << 'DLEOF'

# Track-Export (own-librespot): legt beim Abspielen die entschlüsselte Datei ab.
# size_limit bleibt 0 — die Musikbox räumt die Dateien in ihre eigene Bibliothek
# um und verwaltet den Platz selbst.
download:
  enabled: true
  dir: "/var/lib/musicbox/spotify-downloads"
  size_limit: "0"
DLEOF
        echo "   download-Block ergänzt"
    fi
else
    echo "FEHLER: $CFG nicht gefunden." >&2
    exit 1
fi

echo ">> Zielordner anlegen"
install -d -o musicbox -g musicbox -m 0755 "$DL_DIR"

echo ">> Dienst starten"
systemctl enable own-librespot >/dev/null 2>&1 || true
systemctl restart own-librespot
sleep 3

if systemctl is-active --quiet own-librespot; then
    echo "   own-librespot läuft"
else
    echo "FEHLER: own-librespot startet nicht. Die letzten Zeilen:" >&2
    journalctl -u own-librespot -n 20 --no-pager >&2
    exit 1
fi

echo
echo "Fertig. Nächster Schritt:"
echo "  1. Einen Titel über Spotify Connect auf der Box abspielen"
echo "  2. bash /opt/musicbox/scripts/pruefe_export.sh"
