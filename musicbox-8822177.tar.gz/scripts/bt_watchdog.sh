#!/usr/bin/env bash
# Wachhund für den Bluetooth-Adapter (BCM43430A1, Pi Zero 2 W — WLAN und BT auf einem
# Chip). Der Controller verklemmt sich nach vielen Scan-/Kopplungszyklen gelegentlich:
# "bluetoothctl show" meldet dann "Powered: no", jeder Einschaltversuch scheitert mit
# "status 0x05 (Authentication Failed)" — bisher hat sich das nur durch einen Neustart
# der Box erholt (siehe musicbox-bt-power.service, docs/superpowers/notes/
# 2026-08-22-pipewire-spike.md). Ebenso kann der Adapter seinen Page-Scan verlieren,
# wodurch sich ein bereits vertrauenswürdiger Kopfhörer nicht mehr von selbst verbindet.
#
# btmgmt ist hier TABU: es kehrt ohne Terminal/stdin nicht zurück und blockiert dabei den
# Management-Socket so, dass sogar ein späteres "btmgmt info" hängt — auf der Box
# beobachtet (siehe musicbox-bt-power.service). Alle Aufrufe deshalb über bluetoothctl/
# hciconfig, mit "timeout" und "</dev/null" gegen Hänger abgesichert.
#
# ZWEITER, HEIMTÜCKISCHER FEHLERFALL — "toter Funk" (auf der Box gemessen):
# Nach längerem Betrieb verklemmt sich der Controller in einem Zustand, den KEINE
# Statusabfrage erkennt — das ist der Kern des Problems. "hciconfig hci0" meldet
# "UP RUNNING PSCAN ISCAN", "bluetoothctl show" meldet "Powered: yes" und
# "PowerState: on", "systemctl status bluetooth" ist aktiv, WirePlumber registriert
# A2DP-Endpunkte. Alle Statusabfragen lügen also. Aufdecken lässt sich das nur, indem
# man misst, ob überhaupt noch Funkpakete ankommen — siehe radio_activity_count().
#
# Was NICHT hilft: "systemctl restart bluetooth" und "hciconfig hci0 down/up" (der
# Adapter bleibt danach DOWN, "up" scheitert mit "status 0x05"). Was nachweislich hilft,
# ist das Neubinden des UART-Treibers (hci_uart_bcm) — dabei wird die Controller-
# Firmware neu geladen. Das ist die einzige Heilung ohne Neustart der Box.
#
# Weil auch bei gesundem Adapter mal eine Runde still bleiben kann, ist ein einzelner
# Leerlauf nur ein VERDACHT. Geheilt wird erst, wenn sich der Verdacht zweimal
# hintereinander bestätigt (zwei Timer-Läufe = 10 Minuten). Der Zähler liegt unter /run
# (flüchtig — ein Neustart setzt den Controller ohnehin zurück).
#
# WICHTIG, teuer gelernt: Die Heilung ist ein grober Eingriff und darf NICHT leichtfertig
# ausgelöst werden. Der erste Lebendtest zählte per "hcitool scan" die gefundenen Geräte
# — eine reine BR/EDR-Inquiry, die nur Geräte im Discoverable-Modus sieht. In einer
# normalen Wohnung ist das regelmäßig null, auch bei kerngesundem Funk. Der Wachhund
# heilte deshalb ins Blaue, riss dabei musicbox-bt-power.service mit und hinterließ
# einen Adapter ohne "Pairable: yes" — die Box konnte sich danach keinen Kopfhörer mehr
# merken. Deshalb misst der Lebendtest heute den tatsächlichen Funkempfang, und die
# Heilung setzt die Adaptereinstellungen hinterher wieder.
#
# Der Lebendtest läuft NUR, wenn kein Gerät verbunden ist: ein Scan stört laufende
# A2DP-Wiedergabe hörbar. Läuft Musik über einen Kopfhörer, tut der Wachhund nichts.
#
# Läuft als root über musicbox-bt-watchdog.timer alle 5 Minuten. Darf NIE mit einem
# Fehler enden, der die Unit/den Timer als "failed" markiert — deshalb kein "set -e",
# stattdessen expliziter exit 0 am Ende. Ist alles in Ordnung, tut das Skript nichts und
# loggt nichts (kein Journal-Rauschen alle paar Minuten).
set -uo pipefail

log() {
    logger -t musicbox-bt "$1"
}

# Setzt die Box-eigenen Adaptereinstellungen neu (rfkill unblock, power on, piscan,
# pairable on). Die stecken alle in musicbox-bt-power.service — ein Neustart der Unit
# ist der eine Ort, an dem sie gepflegt werden, statt sie hier zu verdoppeln.
restore_adapter_settings() {
    timeout 30 systemctl restart musicbox-bt-power.service >/dev/null 2>&1
}

adapter_status="$(timeout 5 bluetoothctl show </dev/null 2>/dev/null)"

if ! printf '%s' "$adapter_status" | grep -q "Powered: yes"; then
    log "Adapter nicht eingeschaltet (kein 'Powered: yes') – rfkill unblock bluetooth"
    timeout 5 rfkill unblock bluetooth </dev/null >/dev/null 2>&1

    log "bluetoothctl power on"
    timeout 5 bluetoothctl power on </dev/null >/dev/null 2>&1
    adapter_status="$(timeout 5 bluetoothctl show </dev/null 2>/dev/null)"

    if ! printf '%s' "$adapter_status" | grep -q "Powered: yes"; then
        log "Adapter weiterhin aus – starte bluetooth.service neu"
        timeout 15 systemctl restart bluetooth >/dev/null 2>&1
        sleep 3

        log "erneuter Versuch: bluetoothctl power on"
        timeout 5 bluetoothctl power on </dev/null >/dev/null 2>&1
        adapter_status="$(timeout 5 bluetoothctl show </dev/null 2>/dev/null)"

        if printf '%s' "$adapter_status" | grep -q "Powered: yes"; then
            log "Adapter nach Neustart von bluetooth.service wieder eingeschaltet"
        else
            log "Adapter bleibt aus – vermutlich verklemmt (status 0x05), hilft nur ein Neustart der Box"
        fi
    else
        log "Adapter wieder eingeschaltet"
    fi
fi

# Adaptereinstellungen prüfen, sobald der Adapter an ist. Zwei Flags leben im Kernel
# und überstehen keine Treiber-Neubindung, weil BlueZ sie nicht persistiert (im
# Adapter-"settings" steht nur Discoverable):
#
#   PSCAN    – ohne Page-Scan kann sich ein bereits vertrauenswürdiger Kopfhörer nach
#              dem Einschalten nie von selbst verbinden ("Connection refused").
#   Pairable – ohne das nimmt der Adapter gar keine neue Kopplung an. Es kommt dann
#              kein Bonding zustande, die Box legt keinen Link-Key unter
#              /var/lib/bluetooth an und "vergisst" den Kopfhörer bei jedem
#              Ausschalten. Genau dieser Zustand war auf der Box zu messen.
#
# Gesetzt werden beide von musicbox-bt-power.service. Fehlt eines, wird die Unit neu
# angestoßen — kein Grund, dafür gleich den Treiber neu zu binden.
if printf '%s' "$adapter_status" | grep -q "Powered: yes"; then
    hci_status="$(timeout 5 hciconfig hci0 </dev/null 2>/dev/null)"
    missing=""
    printf '%s' "$hci_status" | grep -q "PSCAN" || missing="Page-Scan (PSCAN)"
    if ! printf '%s' "$adapter_status" | grep -q "Pairable: yes"; then
        missing="${missing:+$missing und }Kopplungsbereitschaft (Pairable)"
    fi
    if [ -n "$missing" ]; then
        log "Adaptereinstellung fehlt: $missing – musicbox-bt-power.service neu starten"
        restore_adapter_settings
        adapter_status="$(timeout 5 bluetoothctl show </dev/null 2>/dev/null)"
    fi
fi

# ─────────────────────────────────────────────────────────────────────────────
# Lebendtest: findet eine echte Inquiry noch Geräte?
# ─────────────────────────────────────────────────────────────────────────────

# Zähler der aufeinanderfolgenden Leerläufe. /run ist ein tmpfs: der Zähler übersteht
# keinen Neustart — genau richtig, denn ein Neustart heilt den Controller ohnehin.
COUNTER_DIR="${MUSICBOX_RUN_DIR:-/run/musicbox}"
COUNTER_FILE="$COUNTER_DIR/bt_watchdog_quiet_count"

# Pfade des UART-Treibers. Nicht blind voraussetzen: auf anderer Hardware (USB-Dongle,
# anderer Chip) gibt es diesen Treiber nicht.
HCI_UART_DRIVER="${MUSICBOX_HCI_UART_DRIVER:-/sys/bus/serial/drivers/hci_uart_bcm}"

read_counter() {
    local value=0
    if [ -r "$COUNTER_FILE" ]; then
        value="$(cat "$COUNTER_FILE" 2>/dev/null)"
    fi
    case "$value" in
        ''|*[!0-9]*) value=0 ;;
    esac
    printf '%s' "$value"
}

write_counter() {
    mkdir -p "$COUNTER_DIR" 2>/dev/null
    printf '%s\n' "$1" > "$COUNTER_FILE" 2>/dev/null
}

# Zählt die Funkpakete, die der Adapter während eines Scans tatsächlich empfängt.
# Gemessen wird an den RSSI-Meldungen: eine Feldstärke entsteht nur aus einem real
# empfangenen Paket. Die Geräteliste selbst taugt als Maß NICHT — bluetoothctl meldet
# beim Scan-Start auch alle Geräte aus dem Cache als [NEW], die käme also selbst bei
# totem Funk zustande.
#
# Bewusst NICHT "hcitool scan": das ist eine reine BR/EDR-Inquiry und findet nur
# Geräte, die gerade im Discoverable-Modus funken — in einer normalen Wohnung
# regelmäßig null, auch bei kerngesundem Adapter. Auf der Box gegengemessen: hcitool
# fand 3 Geräte, während bluetoothctl zeitgleich 32 sah und 12 RSSI-Meldungen
# eintrudelten. Der alte Test hat deshalb wiederholt falschen Alarm ausgelöst und über
# die Heilung die Adaptereinstellungen zerschossen — das war die eigentliche Ursache
# dafür, dass sich die Box keinen Kopfhörer mehr merken konnte.
SCAN_SECONDS=10

radio_activity_count() {
    local output
    output="$(timeout 25 bluetoothctl --timeout "$SCAN_SECONDS" scan on </dev/null 2>/dev/null)"
    printf '%s\n' "$output" | grep -c "RSSI"
}

# Gerätename des gebundenen UART-Ports aus dem Treiberverzeichnis ermitteln (auf der
# Box "serial0-0") statt ihn hart zu verdrahten.
uart_device_name() {
    local entry name
    for entry in "$HCI_UART_DRIVER"/*; do
        [ -L "$entry" ] || continue
        name="$(basename "$entry")"
        case "$name" in
            bind|unbind|uevent|module|bind_mode) continue ;;
        esac
        printf '%s' "$name"
        return 0
    done
    return 1
}

# Die einzige bekannte Heilung: UART-Treiber neu binden (lädt die Controller-Firmware neu).
heal_controller() {
    local dev
    if [ ! -w "$HCI_UART_DRIVER/unbind" ] || [ ! -w "$HCI_UART_DRIVER/bind" ]; then
        log "Heilung übersprungen: $HCI_UART_DRIVER/{unbind,bind} nicht vorhanden (andere Hardware/anderer Treiber)"
        return 1
    fi
    dev="$(uart_device_name)"
    if [ -z "$dev" ]; then
        log "Heilung übersprungen: kein gebundenes Gerät unter $HCI_UART_DRIVER gefunden"
        return 1
    fi

    log "Heilung: bluetooth.service stoppen"
    timeout 15 systemctl stop bluetooth >/dev/null 2>&1

    log "Heilung: $dev vom Treiber lösen (unbind)"
    printf '%s' "$dev" > "$HCI_UART_DRIVER/unbind" 2>/dev/null
    sleep 3

    log "Heilung: $dev wieder an den Treiber binden (bind) – lädt die Controller-Firmware neu"
    printf '%s' "$dev" > "$HCI_UART_DRIVER/bind" 2>/dev/null
    sleep 6

    log "Heilung: bluetooth.service starten"
    timeout 20 systemctl start bluetooth >/dev/null 2>&1

    # Die Neubindung erzeugt hci0 komplett neu — sämtliche Adapter-Flags des Kernels
    # sind damit auf Werkseinstellung zurück, auch "pairable". BlueZ persistiert das
    # nicht (es steht nicht im Adapter-settings), also muss es hier neu gesetzt werden.
    log "Heilung: Adaptereinstellungen neu setzen (musicbox-bt-power.service)"
    restore_adapter_settings
    return 0
}

# Der Lebendtest ist nur gefahrlos, wenn gerade nichts verbunden ist — ein Scan
# würde sonst die laufende Wiedergabe stören.
connected_devices="$(timeout 10 bluetoothctl devices Connected </dev/null 2>/dev/null | grep -c '^Device ')"

if [ "$connected_devices" -eq 0 ] && printf '%s' "$adapter_status" | grep -q "Powered: yes"; then
    received="$(radio_activity_count)"

    if [ "$received" -gt 0 ]; then
        # Funk lebt – Verdacht zurücknehmen.
        [ "$(read_counter)" -eq 0 ] || write_counter 0
    else
        strikes=$(( $(read_counter) + 1 ))
        if [ "$strikes" -lt 2 ]; then
            log "Scan empfing kein einziges Funkpaket (Verdacht $strikes/2) – warte auf Bestätigung im nächsten Lauf"
            write_counter "$strikes"
        else
            log "Scan empfing zweimal hintereinander kein Funkpaket – Funk gilt als tot, heile über Treiber-Neubindung"
            if heal_controller; then
                after="$(radio_activity_count)"
                if [ "$after" -gt 0 ]; then
                    log "Heilung erfolgreich: Funk empfängt wieder ($after Meldungen)"
                else
                    log "Heilung ohne Wirkung: weiterhin kein Funkempfang – hilft evtl. nur ein Neustart der Box"
                fi
            fi
            write_counter 0
        fi
    fi
fi

exit 0
