#!/usr/bin/env bash
# Prüft auf der Box, ob der Track-Export von own-librespot funktioniert.
#
# Hintergrund: Auf der Fork-Seite hat nie ein echter Abspielvorgang mit einem
# Spotify-Konto stattgefunden — belegt sind nur Konfiguration, Zielordner und
# API-Antworten. Bevor der Offline-Abgleich darauf aufbaut, wird das einmal
# beobachtet statt angenommen.
#
# Auf der Box ausführen:
#
#   bash /opt/musicbox/scripts/pruefe_export.sh
#
# Ohne Argumente wird nur der Zustand erhoben (nichts verändert).

set -uo pipefail

DL_DIR="${MUSICBOX_DOWNLOAD_DIR:-/var/lib/musicbox/spotify-downloads}"
CFG="${MUSICBOX_LIBRESPOT_CFG:-/etc/musicbox/config.yml}"
API="${MUSICBOX_LIBRESPOT_URL:-http://127.0.0.1:3678}"
SERVICE="own-librespot"

fehler=0

ok()   { printf "  \033[32m✓\033[0m %s\n" "$1"; }
warn() { printf "  \033[33m!\033[0m %s\n" "$1"; }
bad()  { printf "  \033[31m✗\033[0m %s\n" "$1"; fehler=$((fehler + 1)); }

echo "== 1. Dienst =="
if systemctl is-active --quiet "$SERVICE" 2>/dev/null; then
    ok "$SERVICE läuft"
    seit=$(systemctl show -p ActiveEnterTimestamp --value "$SERVICE" 2>/dev/null)
    [ -n "$seit" ] && echo "     seit $seit"
else
    bad "$SERVICE läuft nicht — 'systemctl status $SERVICE' zeigt warum"
fi

if [ -x /usr/local/bin/own-librespot ]; then
    ok "Binary vorhanden: /usr/local/bin/own-librespot"
else
    bad "Binary fehlt: /usr/local/bin/own-librespot"
fi

if [ -e /usr/local/bin/go-librespot ] || systemctl list-unit-files 2>/dev/null | grep -q "^go-librespot"; then
    warn "Reste von go-librespot vorhanden — box_deploy.sh räumt sie ab"
fi

echo
echo "== 2. Konfiguration =="
if [ -f "$CFG" ]; then
    if grep -q '^download:' "$CFG"; then
        ok "download-Block vorhanden"
        sed -n '/^download:/,/^[^ #]/p' "$CFG" | grep -E '^\s+(enabled|dir|size_limit):' | sed 's/^/     /'
        if grep -qE '^\s+enabled:\s*true' "$CFG"; then
            ok "Export ist eingeschaltet"
        else
            bad "download.enabled steht nicht auf true — es wird nichts exportiert"
        fi
        if grep -qE '^\s+size_limit:\s*"?0"?\s*$' "$CFG"; then
            ok "size_limit ist 0 (die Musikbox verwaltet den Platz selbst)"
        else
            warn "size_limit ist nicht 0 — die Verdrängung des Forks würde Einträge"
            warn "für Dateien löschen, die längst in der Bibliothek liegen"
        fi
    else
        bad "kein download-Block in $CFG — Export ist nicht konfiguriert"
    fi
else
    bad "Konfiguration nicht gefunden: $CFG"
fi

echo
echo "== 3. Zielordner =="
if [ -d "$DL_DIR" ]; then
    ok "vorhanden: $DL_DIR"
    echo "     Eigentümer: $(stat -c '%U:%G %a' "$DL_DIR" 2>/dev/null)"
    if sudo -u musicbox test -w "$DL_DIR" 2>/dev/null; then
        ok "für den Benutzer musicbox schreibbar"
    else
        warn "Schreibrecht für musicbox nicht bestätigt (Prüfung braucht root)"
    fi
    frei=$(df -h --output=avail "$DL_DIR" 2>/dev/null | tail -1 | tr -d ' ')
    [ -n "$frei" ] && echo "     frei auf dem Datenträger: $frei"
else
    bad "fehlt: $DL_DIR — der Daemon bricht beim Start ab, wenn er ihn nicht anlegen kann"
fi

echo
echo "== 4. Schnittstelle =="
antwort=$(curl -s --max-time 5 "$API/downloads" 2>/dev/null)
if [ -n "$antwort" ]; then
    ok "GET /downloads antwortet"
    if command -v python3 >/dev/null; then
        python3 - "$antwort" <<'PY'
import json, sys
try:
    daten = json.loads(sys.argv[1])
except Exception:
    print("     Antwort ist kein JSON:", sys.argv[1][:120]); raise SystemExit
tracks = daten.get("tracks") or {}
print(f"     Ordner: {daten.get('dir') or '(leer)'}")
print(f"     verzeichnete Titel: {len(tracks)}")
for uri, e in list(tracks.items())[:5]:
    print(f"       {uri}  rang={e.get('rank')}  {e.get('path')}")
PY
    fi
else
    bad "GET $API/downloads antwortet nicht — läuft eine Fassung ohne diese Route?"
fi

echo
echo "== 5. Was liegt im Ordner =="
if [ -d "$DL_DIR" ]; then
    anzahl=$(find "$DL_DIR" -type f ! -name '.*' 2>/dev/null | wc -l)
    echo "     Dateien: $anzahl"
    find "$DL_DIR" -type f ! -name '.*' -printf '     %s  %p\n' 2>/dev/null | head -10
    reste=$(find "$DL_DIR" -name '.dl.*.tmp' 2>/dev/null | wc -l)
    [ "$reste" -gt 0 ] && warn "$reste angefangene Datei(en) (.dl.*.tmp) — ein Export brach ab"

    neueste=$(find "$DL_DIR" -type f ! -name '.*' -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)
    if [ -n "$neueste" ]; then
        echo
        echo "== 6. Neueste Datei =="
        echo "     $neueste"
        if command -v ffprobe >/dev/null; then
            ffprobe -v error -show_entries \
                format=duration,bit_rate:format_tags=title,artist,album,track \
                -of default=noprint_wrappers=1 "$neueste" 2>/dev/null | sed 's/^/     /'
            if ffprobe -v error -select_streams v -show_entries stream=codec_name \
                -of csv=p=0 "$neueste" 2>/dev/null | grep -qE 'mjpeg|png'; then
                ok "Cover eingebettet"
            else
                warn "kein Cover gefunden (kein Fehler — der Abruf ist best-effort)"
            fi
        else
            warn "ffprobe nicht vorhanden — Tags nicht prüfbar (apt install ffmpeg)"
        fi
    else
        echo
        warn "noch keine exportierte Datei — bitte einen Titel abspielen und erneut prüfen"
    fi
fi

echo
echo "== 7. Letzte Meldungen des Dienstes =="
journalctl -u "$SERVICE" -n 15 --no-pager 2>/dev/null \
    | grep -iE 'export|download|error|warn' | tail -10 | sed 's/^/     /' \
    || echo "     (keine passenden Zeilen)"

echo
if [ "$fehler" -eq 0 ]; then
    echo "Ergebnis: keine Fehler gefunden."
else
    echo "Ergebnis: $fehler Punkt(e) zu klären — siehe ✗ oben."
fi
exit "$fehler"
