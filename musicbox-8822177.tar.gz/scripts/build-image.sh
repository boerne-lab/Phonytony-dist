#!/usr/bin/env bash
# Baut ein fertig flashbares MusicBox-Image für Raspberry Pi Zero 2 W.
# Aufruf: sudo -E bash scripts/build-image.sh [QUELLE.img] [ZIEL.img]
#
# Benötigte Umgebungsvariablen:
#   WLAN_SSID           – WLAN-Netzwerkname
#   WLAN_PASSWORD       – WLAN-Passwort
#   SPOTIFY_CLIENT_ID   – Spotify App Client-ID (developer.spotify.com)
#
# Benötigte Pakete (Ubuntu/Debian):
#   qemu-user-static binfmt-support kpartx parted e2fsprogs rsync

set -euo pipefail

SOURCE_IMG="${1:?Aufruf: build-image.sh QUELLE.img ZIEL.img}"
OUTPUT_IMG="${2:?Aufruf: build-image.sh QUELLE.img ZIEL.img}"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"

: "${WLAN_SSID:?WLAN_SSID Umgebungsvariable nicht gesetzt}"
: "${WLAN_PASSWORD:?WLAN_PASSWORD Umgebungsvariable nicht gesetzt}"
: "${SPOTIFY_CLIENT_ID:?SPOTIFY_CLIENT_ID Umgebungsvariable nicht gesetzt}"

MOUNT_ROOT="$(mktemp -d /tmp/mbox-root.XXXX)"
MOUNT_BOOT="$(mktemp -d /tmp/mbox-boot.XXXX)"
LOOP_DEV=""

log() { echo "[$(date '+%H:%M:%S')] $*"; }

cleanup() {
    log "=== Cleanup ==="
    # Chroot-Mounts in umgekehrter Reihenfolge lösen
    for sub in dev/pts dev proc sys run; do
        umount -lf "$MOUNT_ROOT/$sub" 2>/dev/null || true
    done
    # Boot-Bind
    umount -lf "$MOUNT_ROOT/boot/firmware" 2>/dev/null || true
    umount -lf "$MOUNT_BOOT" 2>/dev/null || true
    umount -lf "$MOUNT_ROOT" 2>/dev/null || true
    [[ -n "$LOOP_DEV" ]] && losetup -d "$LOOP_DEV" 2>/dev/null || true
    rm -rf "$MOUNT_ROOT" "$MOUNT_BOOT"
}
trap cleanup EXIT

# ─────────────────────────────────────────────
# 1. Image kopieren und Partition vergrößern
# ─────────────────────────────────────────────
log "=== Image kopieren ==="
cp "$SOURCE_IMG" "$OUTPUT_IMG"

log "=== Root-Partition um 4 GB erweitern ==="
dd if=/dev/zero bs=1M count=4096 >> "$OUTPUT_IMG" status=none
parted -s "$OUTPUT_IMG" resizepart 2 100%

LOOP_DEV=$(losetup -f --show -P "$OUTPUT_IMG")
log "Loop-Device: $LOOP_DEV"

e2fsck -f -y "${LOOP_DEV}p2" || true
resize2fs "${LOOP_DEV}p2"

# ─────────────────────────────────────────────
# 2. Mounten
# ─────────────────────────────────────────────
log "=== Mounten ==="
mount "${LOOP_DEV}p2" "$MOUNT_ROOT"
mount "${LOOP_DEV}p1" "$MOUNT_BOOT"
mount --bind "$MOUNT_BOOT" "$MOUNT_ROOT/boot/firmware"

# ─────────────────────────────────────────────
# 3. QEMU + chroot vorbereiten
# ─────────────────────────────────────────────
log "=== QEMU + chroot vorbereiten ==="
# QEMU-Binary für ARM64 in den Chroot kopieren
cp /usr/bin/qemu-aarch64-static "$MOUNT_ROOT/usr/bin/"

mount -t proc    proc    "$MOUNT_ROOT/proc"
mount -t sysfs   sysfs   "$MOUNT_ROOT/sys"
mount --bind     /dev    "$MOUNT_ROOT/dev"
mount --bind     /dev/pts "$MOUNT_ROOT/dev/pts"
mount -t tmpfs   tmpfs   "$MOUNT_ROOT/run"

# DNS für Paket-Downloads
cp /etc/resolv.conf "$MOUNT_ROOT/etc/resolv.conf"

# ─────────────────────────────────────────────
# 4. Systempakete + own-librespot installieren
# ─────────────────────────────────────────────
log "=== Pakete installieren (~10–15 Min.) ==="
chroot "$MOUNT_ROOT" /usr/bin/qemu-aarch64-static /bin/bash << 'CHROOT_PKGS'
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

apt-get update -qq
apt-get install -y \
    python3-pip python3-venv python3-dev python3-lgpio \
    i2c-tools \
    python3-spidev \
    mpv \
    alsa-utils libasound2-plugins \
    pipewire pipewire-audio pipewire-alsa pipewire-pulse wireplumber \
    libspa-0.2-bluetooth pulseaudio-utils bluez rfkill \
    avahi-daemon libnss-mdns \
    wireless-regdb \
    watchdog \
    fake-hwclock \
    git curl wget

# Audio-HAT: Waveshare WM8960 Hi-Fi Sound Card (WM8960-Codec, I2C-Steuerung + I2S-Audio).
# Pi OS enthält den wm8960-soundcard-Overlay bereits → kein externer Installer nötig.
# Getrennte Ausgänge Headphone (LOUT1/ROUT1) und Speaker (LOUT2/ROUT2, Class-D), beide
# per ALSA-Control steuerbar (Software-Umschaltung; kein Auto-Jack-Detect auf dem Board).
# Hinweis: das frühere RASPIAUDIO Pi MIC V3 war ein googlevoicehat-I2S-Board OHNE diese
# Umschaltung — falls wieder ein solches Board genutzt wird: dtoverlay=googlevoicehat-soundcard.

# own-librespot (ARM64) — eigener Fork mit Track-Export.
#
# Der Fork ist privat und bleibt es. Dieses Skript laeuft auf dem Rechner der
# Nutzerin, die Zugriff darauf hat — hier darf das Binary geholt werden, auf der
# Box selbst nicht. Es wandert fest ins Image; ein fertiges Geraet laedt nie
# etwas nach und braucht keine Zugangsdaten.
OWNLIBRESPOT_VERSION="${OWNLIBRESPOT_VERSION:-v0.9.1}"
if [ -n "${OWNLIBRESPOT_BINARY:-}" ]; then
    # Vorgebautes Binary mitgebracht (etwa aus einem lokalen Bau).
    [ -s "$OWNLIBRESPOT_BINARY" ] || { echo "FEHLER: $OWNLIBRESPOT_BINARY ist leer." >&2; exit 1; }
    install -m 0755 "$OWNLIBRESPOT_BINARY" /usr/local/bin/own-librespot
elif command -v gh >/dev/null 2>&1; then
    tmpd_olr="$(mktemp -d)"
    if ! (cd "$tmpd_olr" && gh release download "$OWNLIBRESPOT_VERSION" \
            --repo boerne-lab/own-librespot \
            --pattern "own-librespot_linux_arm64.tar.gz" 2>/dev/null); then
        rm -rf "$tmpd_olr"
        echo "FEHLER: own-librespot $OWNLIBRESPOT_VERSION nicht abrufbar." >&2
        echo "        Das Repository ist privat — 'gh auth login' noetig," >&2
        echo "        oder OWNLIBRESPOT_BINARY=/pfad/zum/binary setzen." >&2
        exit 1
    fi
    tar -xzf "$tmpd_olr/own-librespot_linux_arm64.tar.gz" -C "$tmpd_olr"
    [ -s "$tmpd_olr/own-librespot" ] || { echo "FEHLER: Archiv ohne Binary." >&2; exit 1; }
    install -m 0755 "$tmpd_olr/own-librespot" /usr/local/bin/own-librespot
    rm -rf "$tmpd_olr"
else
    echo "FEHLER: own-librespot laesst sich nicht beschaffen." >&2
    echo "        Der Fork ist privat: entweder 'gh' installieren und anmelden," >&2
    echo "        oder OWNLIBRESPOT_BINARY=/pfad/zum/binary setzen." >&2
    exit 1
fi
echo "✓ own-librespot ins Image gelegt ($(stat -c %s /usr/local/bin/own-librespot) Bytes)"cd /

# musicbox-User
id -u musicbox &>/dev/null \
    || useradd -r -s /usr/sbin/nologin -m -d /var/lib/musicbox musicbox
usermod -aG audio,gpio,i2c,spi musicbox

# --- PipeWire: Linger + XDG_RUNTIME_DIR ---
# PipeWire läuft als User-Dienst von musicbox. Linger sorgt dafür, dass die Instanz
# ohne Login startet; alle drei Dienste zeigen über XDG_RUNTIME_DIR auf dieselbe.
# loginctl braucht eine laufende logind-Instanz (D-Bus) — im QEMU-Chroot beim Image-Bau
# gibt es die nicht. Falls der Aufruf deshalb ins Leere läuft, wird der Marker, den
# enable-linger unter der Haube setzt, direkt angelegt.
loginctl enable-linger musicbox 2>/dev/null || {
    mkdir -p /var/lib/systemd/linger
    touch /var/lib/systemd/linger/musicbox
}
MB_UID="$(id -u musicbox)"
for unit in musicbox-core musicbox-web own-librespot; do
    mkdir -p "/etc/systemd/system/${unit}.service.d"
    cat > "/etc/systemd/system/${unit}.service.d/pipewire.conf" << EOF
[Service]
Environment=XDG_RUNTIME_DIR=/run/user/${MB_UID}
Environment=PULSE_RUNTIME_PATH=/run/user/${MB_UID}/pulse
EOF
done
# Keine laufende User-Sitzung im Chroot → PipeWire/Wireplumber global statt
# "systemctl --user" aktivieren (wirkt für jeden lingernden User, hier musicbox).
systemctl --global enable pipewire pipewire-pulse wireplumber

echo "Pakete OK"
CHROOT_PKGS

# ─────────────────────────────────────────────
# 5. Python-Pakete installieren
# ─────────────────────────────────────────────
log "=== Python-Pakete vorab herunterladen (Runner, außerhalb QEMU) ==="
# Ohne --only-binary und ohne --platform: pure-Python-Pakete kommen als
# py3-none-any-Wheel oder sdist, beides läuft auf ARM64.
# C-Extensions (x86_64) werden ignoriert; im Chroot greift --system-site-packages
# (lgpio, spidev von apt) oder PyPI-Fallback via pip.conf.
mkdir -p "$MOUNT_ROOT/tmp/pip-wheels"
# spidev + lgpio kommen von apt (python3-spidev, python3-lgpio); kein pip nötig.
# adafruit-circuitpython-mfrc522 existiert nicht auf PyPI → entfernt; RC522
# wird jetzt direkt via spidev angesprochen (musicbox/rfid/reader.py).
pip3 download --no-cache-dir \
    -d "$MOUNT_ROOT/tmp/pip-wheels" \
    "gpiozero>=2.0" \
    "fastapi>=0.110" \
    "uvicorn>=0.27" \
    "jinja2>=3.1" \
    "python-multipart>=0.0.9" \
    "aiofiles>=23.0" \
    "httpx[http2]>=0.27" \
    "websockets>=12" \
    "spotipy>=2.24" \
    "Pillow>=10" \
    "mutagen>=1.47" \
    "python-dotenv>=1.0"
log "Heruntergeladene Pakete: $(ls "$MOUNT_ROOT/tmp/pip-wheels" | wc -l)"

log "=== Repo in Chroot kopieren ==="
mkdir -p "$MOUNT_ROOT/opt/musicbox"
rsync -a --delete \
    --exclude='.git' --exclude='__pycache__' --exclude='*.pyc' \
    --exclude='venv' --exclude='.venv' \
    --exclude='*.img' --exclude='*.img.xz' --exclude='*.xz' \
    --exclude='data/music/*' --exclude='data/tokens/*' \
    --exclude='data/state.json' --exclude='.env' \
    "$REPO_DIR/" "$MOUNT_ROOT/opt/musicbox/"

chroot "$MOUNT_ROOT" /usr/bin/qemu-aarch64-static /bin/bash << 'CHROOT_PY'
set -euo pipefail

# pip.conf überschreiben: PyPI direkt ansprechen, SSL-Hosts vertrauen.
# Pi OS Trixie kann unter QEMU keine HTTPS-Verbindungen zu PyPI aufbauen;
# lokal vorhandene Pakete (--find-links) werden bevorzugt, PyPI ist Fallback.
cat > /etc/pip.conf << 'PIPEOF'
[global]
index-url = https://pypi.org/simple/
extra-index-url = https://www.piwheels.org/simple/
trusted-host =
    pypi.org
    files.pythonhosted.org
    www.piwheels.org
timeout = 120
PIPEOF

# --system-site-packages: lgpio und python3-spidev von apt nutzen
python3 -m venv --system-site-packages /opt/musicbox/venv
/opt/musicbox/venv/bin/pip install \
    --find-links /tmp/pip-wheels \
    -e /opt/musicbox
rm -rf /tmp/pip-wheels
echo "Python OK"
CHROOT_PY

# ─────────────────────────────────────────────
# 6. Verzeichnisse, Konfig, Sounds
# ─────────────────────────────────────────────
log "=== Verzeichnisse und Konfiguration ==="
for d in sounds music tokens playlists librespot-cache; do
    mkdir -p "$MOUNT_ROOT/var/lib/musicbox/$d"
done
mkdir -p "$MOUNT_ROOT/etc/musicbox"

cp "$REPO_DIR/config/config.toml"      "$MOUNT_ROOT/etc/musicbox/config.toml"
cp "$REPO_DIR/config/go-librespot.yml" "$MOUNT_ROOT/etc/musicbox/config.yml"

# Env-Datei für Services
cat > "$MOUNT_ROOT/etc/musicbox/.env" << ENVEOF
MUSICBOX_CONFIG=/etc/musicbox/config.toml
MUSICBOX_DATA_DIR=/var/lib/musicbox
SPOTIFY_CLIENT_ID=${SPOTIFY_CLIENT_ID}
SPOTIFY_REDIRECT_URI=http://127.0.0.1:8080/auth/spotify/callback
ENVEOF

log "=== Audio-Feedback-Sounds kopieren ==="
# Fertig gerenderte WAVs kommen mit dem Repo (musicbox/audio/sounds/) — reiner
# Datei-Kopiervorgang, braucht kein chroot/qemu.
cp "$REPO_DIR"/musicbox/audio/sounds/*.wav "$MOUNT_ROOT/var/lib/musicbox/sounds/"

# Berechtigungen
chroot "$MOUNT_ROOT" /usr/bin/qemu-aarch64-static /bin/bash << 'CHROOT_PERMS'
chown -R musicbox:musicbox /var/lib/musicbox /etc/musicbox /opt/musicbox
chmod 600 /etc/musicbox/.env
CHROOT_PERMS

# ─────────────────────────────────────────────
# 7. Systemd Services aktivieren
# ─────────────────────────────────────────────
log "=== Systemd Services aktivieren ==="
cp "$REPO_DIR/systemd/"*.service "$MOUNT_ROOT/etc/systemd/system/"
cp "$REPO_DIR/systemd/"*.timer "$MOUNT_ROOT/etc/systemd/system/" 2>/dev/null || true

# WirePlumber: Headless-Bluetooth-Konfiguration (Seat-Monitoring aus, A2DP-Quelle)
mkdir -p "$MOUNT_ROOT/etc/wireplumber/wireplumber.conf.d"
install -m0644 "$REPO_DIR/systemd/wireplumber-headless-bluetooth.conf" \
    "$MOUNT_ROOT/etc/wireplumber/wireplumber.conf.d/50-headless-bluetooth.conf"

# --- Persistentes Journal (mit Deckel gegen SD-Verschleiß) ---
# Ohne das schreibt journald nach /run und die Fehlerhistorie ist nach jedem
# Neustart weg. Im Abbild reicht das Anlegen — journald nimmt es beim ersten
# Boot von selbst auf.
mkdir -p "$MOUNT_ROOT/etc/systemd/journald.conf.d" "$MOUNT_ROOT/var/log/journal"
install -m0644 "$REPO_DIR/systemd/journald-musicbox.conf" \
    "$MOUNT_ROOT/etc/systemd/journald.conf.d/50-musicbox.conf"

# --- BlueZ: Box-eigene Einstellungen in /etc/bluetooth/main.conf ---
# main.conf ist eine Paketdatei voller auskommentierter Vorgaben. Deshalb wird sie nicht
# ersetzt, sondern nur um einen klar markierten Block am Ende ergaenzt; ein erneuter Lauf
# entfernt den alten Block zuerst (idempotent, keine Duplikate). Vorher eine Sicherung.
apply_bluetooth_main_conf() {
    local root="${1:-}"
    local conf="$root/etc/bluetooth/main.conf"
    mkdir -p "$root/etc/bluetooth"
    [ -f "$conf" ] || : > "$conf"
    cp -n "$conf" "$conf.bak" 2>/dev/null || true
    # Fassungen aus der Zeit vor den Markern mitnehmen: sie beginnen mit einer
    # "# --- Musicbox: ..."-Ueberschrift und reichen bis zum Marker-Block bzw. bis
    # zum Dateiende. Ohne das bleibt der alte Block fuer immer liegen und der
    # Block steht doppelt in der Datei (auf der Box so vorgefunden).
    sed -i '/^# --- Musicbox:/,/^# >>> musicbox-bluetooth >>>$/{/^# >>> musicbox-bluetooth >>>$/!d}' "$conf"
    sed -i '/^# >>> musicbox-bluetooth >>>$/,/^# <<< musicbox-bluetooth <<<$/d' "$conf"
    # Nachlaufende Leerzeilen abschneiden, damit der Block bei jedem Lauf gleich aussieht.
    printf '%s\n' "$(cat "$conf")" > "$conf"
    {
        echo
        echo "# >>> musicbox-bluetooth >>>"
        cat "$REPO_DIR/systemd/bluetooth-main.conf.block"
        echo "# <<< musicbox-bluetooth <<<"
    } >> "$conf"
}

apply_bluetooth_main_conf "$MOUNT_ROOT"
log "BlueZ-Einstellungen in main.conf gesetzt (Neustart des Dienstes im Image nicht noetig)"

chroot "$MOUNT_ROOT" /usr/bin/qemu-aarch64-static /bin/bash << 'CHROOT_SYSTEMD'
systemctl enable systemd-timesyncd own-librespot musicbox-alsa-init musicbox-core musicbox-web musicbox-bt-power
# Self-Update (wöchentlicher Timer) + WLAN-AP-Fallback + Bluetooth-Wachhund (alle 5 Min.)
systemctl enable musicbox-update.timer musicbox-netwatch musicbox-bt-watchdog.timer

# Boot-Beschleunigung: für eine headless-Appliance unnötige Standarddienste abschalten.
# cloud-init (~5,5s), console/keyboard-setup (~4,8s), udisks2 (2s), e2scrub, wait-online (1,5s).
# avahi-daemon bewusst NICHT anfassen (mDNS für musicbox.local-Onboarding).
# userconfig.service: Pi-Erstboot-Benutzerdialog auf tty8 — wartet headless EWIG auf
# Eingabe und blockiert multi-user.target ("Bootup is not yet finished"). Zwingend maskieren.
systemctl mask userconfig.service 2>/dev/null || true
systemctl mask cloud-init.service cloud-init-local.service cloud-config.service cloud-final.service 2>/dev/null || true
systemctl mask console-setup.service keyboard-setup.service 2>/dev/null || true
systemctl mask udisks2.service 2>/dev/null || true
systemctl mask e2scrub_reap.service 2>/dev/null || true
systemctl disable e2scrub_all.timer 2>/dev/null || true
systemctl disable NetworkManager-wait-online.service 2>/dev/null || true
# cloud-init zusätzlich über Flag-Datei stilllegen (verhindert Re-Aktivierung)
touch /etc/cloud/cloud-init.disabled 2>/dev/null || true

# Akku/Compute: periodische Wartungs-Timer abschalten. Sie wecken den Pi täglich
# für Netz/CPU/SD-Aktivität (schlecht für Akku) und apt-daily kann ungefragt Pakete
# ziehen/aktualisieren (Stabilitätsrisiko). Updates laufen über musicbox-update.timer.
systemctl mask apt-daily.service apt-daily.timer apt-daily-upgrade.service apt-daily-upgrade.timer 2>/dev/null || true
systemctl mask man-db.service man-db.timer 2>/dev/null || true
systemctl mask dpkg-db-backup.service dpkg-db-backup.timer 2>/dev/null || true
# rpi-resize-swap-file: einmalige dphys-Swap-Resize; Box nutzt zram-Swap → unnötig (~0,7s Boot)
systemctl mask rpi-resize-swap-file.service 2>/dev/null || true
CHROOT_SYSTEMD

# Self-Update: installierte Version + sudoers (Web darf nur den Update-Service starten)
git -C "$REPO_DIR" rev-parse --short HEAD > "$MOUNT_ROOT/opt/musicbox/VERSION" 2>/dev/null || echo "image" > "$MOUNT_ROOT/opt/musicbox/VERSION"
install -m0440 "$REPO_DIR/systemd/musicbox-update.sudoers" "$MOUNT_ROOT/etc/sudoers.d/musicbox-update"

# WLAN-Onboarding: AP-Profil, Captive-DNS, tmpfiles, wifi-Helfer-sudoers
mkdir -p "$MOUNT_ROOT/etc/NetworkManager/system-connections"
install -m600 -o root -g root "$REPO_DIR/systemd/musicbox-ap.nmconnection" \
    "$MOUNT_ROOT/etc/NetworkManager/system-connections/musicbox-ap.nmconnection"
mkdir -p "$MOUNT_ROOT/etc/NetworkManager/dnsmasq-shared.d"
cp "$REPO_DIR/systemd/captive-dnsmasq.conf" "$MOUNT_ROOT/etc/NetworkManager/dnsmasq-shared.d/captive.conf"
cp "$REPO_DIR/systemd/musicbox-tmpfiles.conf" "$MOUNT_ROOT/etc/tmpfiles.d/musicbox.conf"
install -m0440 "$REPO_DIR/systemd/musicbox-wifi.sudoers" "$MOUNT_ROOT/etc/sudoers.d/musicbox-wifi"
install -m0440 "$REPO_DIR/systemd/musicbox-bluetooth.sudoers" "$MOUNT_ROOT/etc/sudoers.d/musicbox-bluetooth"
install -m0440 "$REPO_DIR/systemd/musicbox-shutdown.sudoers" "$MOUNT_ROOT/etc/sudoers.d/musicbox-shutdown"

# ─────────────────────────────────────────────
# 8. Hardware-Overlays in config.txt
# ─────────────────────────────────────────────
log "=== Hardware-Overlays setzen ==="
CONFIG_TXT="$MOUNT_BOOT/config.txt"
add_config() {
    grep -qxF "$1" "$CONFIG_TXT" || echo "$1" >> "$CONFIG_TXT"
}
# I2C für den WM8960-Codec (Steuerregister des Waveshare-Boards laufen über I2C)
add_config "dtparam=i2c_arm=on"
# SPI für RC522 RFID-Reader
add_config "dtparam=spi=on"
# I2S für RASPIAUDIO MIC+
add_config "dtparam=i2s=on"
# Waveshare WM8960 Audio HAT Overlay (in Pi OS enthalten)
add_config "dtoverlay=wm8960-soundcard"
# Hardware-Watchdog für unbeaufsichtigten Dauerbetrieb
add_config "dtparam=watchdog=on"

# SD-Bustakt: Der Boot hängt an der Lesegeschwindigkeit der Karte — systemd
# startet bei 3,1 s, die erste fertige Unit kommt erst bei 6,4 s, dazwischen
# liest PID 1 Unit-Dateien von der Karte. 84 statt 50 MHz: 36 statt 23 MB/s,
# gemessen gesamt 20,5 -> 18,4 s und Ton 14,4 -> 12,7 s.
# KARTENABHÄNGIG: 100 MHz hielt die Testkarte nicht (Treiber meldet "reducing
# overclock due to errors"). Nach dem ersten Boot prüfen mit:
#   dmesg | grep -i "reducing overclock"   -> Treffer heißt: Wert senken.
add_config "dtparam=sd_overclock=84"

# ─────────────────────────────────────────────
# Headless-Optimierung: ungenutzte Subsysteme abschalten (kein Display, keine Kamera,
# kein Onboard-Audio — der WM8960 läuft über I2S/I2C). Spart RAM + Strom auf der Akku-Box.
# (Voll headless gewählt; bei Bedarf eines Bildschirms diese Zeilen wieder einkommentieren.)
disable_config() {  # kommentiert eine exakt passende Zeile aus (idempotent)
    sed -i -E "s|^[[:space:]]*($1)[[:space:]]*\$|#&  # headless-deaktiviert|" "$CONFIG_TXT"
}
disable_config "dtoverlay=vc4-kms-v3d"
disable_config "max_framebuffers=2"
disable_config "display_auto_detect=1"
# Onboard-Audio (bcm2835 PWM/HDMI) aus — WM8960 ist separat über I2S
sed -i -E "s|^[[:space:]]*dtparam=audio=on.*|dtparam=audio=off|" "$CONFIG_TXT"
grep -q "^dtparam=audio=off" "$CONFIG_TXT" || add_config "dtparam=audio=off"
# Kamera-Autodetect aus
sed -i -E "s|^[[:space:]]*camera_auto_detect=1.*|camera_auto_detect=0|" "$CONFIG_TXT"
grep -q "^camera_auto_detect=0" "$CONFIG_TXT" || add_config "camera_auto_detect=0"
# Minimaler GPU-Split: headless braucht keinen Framebuffer-Speicher → mehr RAM fürs System
add_config "gpu_mem=16"
# Boot-Splash der Firmware aus (Regenbogen-Screen) — headless unnötig, spart Init
add_config "disable_splash=1"

# Ungenutzte Kamera-Module gar nicht erst laden (kein Kamerasensor verbaut)
cat > "$MOUNT_ROOT/etc/modprobe.d/musicbox-headless.conf" <<'BLACKLIST'
# Headless-Musicbox: keine Kamera → V4L2/ISP/Codec-Module nicht laden
blacklist bcm2835_v4l2
blacklist bcm2835_isp
blacklist bcm2835_codec
BLACKLIST

# ─────────────────────────────────────────────
# 9. SSH aktivieren
# ─────────────────────────────────────────────
log "=== SSH aktivieren ==="
touch "$MOUNT_BOOT/ssh"

# ─────────────────────────────────────────────
# 10. WLAN konfigurieren (NetworkManager / Bookworm)
# ─────────────────────────────────────────────
log "=== WLAN konfigurieren ==="
mkdir -p "$MOUNT_ROOT/etc/NetworkManager/system-connections"

# UUID ist Pflicht für NetworkManager – ohne UUID wird das Profil ignoriert
WIFI_UUID=$(cat /proc/sys/kernel/random/uuid)

# Schreibe nmconnection via Python-Argumente — sicher gegen Sonderzeichen in SSID/Passwort
NMCONN="$MOUNT_ROOT/etc/NetworkManager/system-connections/musicbox-wifi.nmconnection"
python3 - "$NMCONN" "$WIFI_UUID" "$WLAN_SSID" "$WLAN_PASSWORD" << 'PYEOF'
import sys, os
path, uuid_val, ssid, psk = sys.argv[1:]
content = (
    "[connection]\n"
    "id=musicbox-wifi\n"
    "uuid=" + uuid_val + "\n"
    "type=wifi\n"
    "autoconnect=true\n"
    "autoconnect-priority=10\n"
    "\n"
    "[wifi]\n"
    "mode=infrastructure\n"
    "ssid=" + ssid + "\n"
    "\n"
    "[wifi-security]\n"
    "auth-alg=open\n"
    "key-mgmt=wpa-psk\n"
    "psk=" + psk + "\n"
    "\n"
    "[ipv4]\n"
    "method=auto\n"
    "\n"
    "[ipv6]\n"
    "addr-gen-mode=default\n"
    "method=ignore\n"
)
open(path, "w").write(content)
PYEOF
chmod 600 "$MOUNT_ROOT/etc/NetworkManager/system-connections/musicbox-wifi.nmconnection"
chown root:root "$MOUNT_ROOT/etc/NetworkManager/system-connections/musicbox-wifi.nmconnection"

# NM-State-Datei löschen: kann WirelessEnabled=false aus dem Build-Chroot enthalten
rm -f "$MOUNT_ROOT/var/lib/NetworkManager/NetworkManager.state"

# WiFi Power-Save deaktivieren: verhindert Verbindungsabbrüche auf einem always-on Gerät
mkdir -p "$MOUNT_ROOT/etc/NetworkManager/conf.d"
cat > "$MOUNT_ROOT/etc/NetworkManager/conf.d/powersave.conf" << 'PWEOF'
[connection]
wifi.powersave = 2
PWEOF

# mDNS: avahi als vollständiger Responder (systemd-resolved ist NICHT installiert)
cat > "$MOUNT_ROOT/etc/NetworkManager/conf.d/mdns.conf" << 'MDNSEOF'
[connection]
connection.mdns=1
MDNSEOF

# DNS: systemd-resolved ist NICHT installiert → NetworkManager muss /etc/resolv.conf
# selbst aus den per DHCP gelernten Nameservern schreiben. Ohne dies bleibt resolv.conf
# leer/tot und es gibt KEINE Namensauflösung (own-librespot, pip, NTP schlagen fehl).
cat > "$MOUNT_ROOT/etc/NetworkManager/conf.d/dns.conf" << 'DNSEOF'
[main]
dns=default
DNSEOF

# Zeit-Sync robust machen: Pi Zero 2 W hat keine RTC, daher startet die Uhr bei jedem
# Boot falsch, bis NTP synct. Explizite NTP-Server + Fallback; fake-hwclock (s. Pakete)
# überbrückt die Lücke bis zum ersten Sync, damit TLS zu Spotify nicht an einer
# rückwärts laufenden Uhr scheitert.
cat > "$MOUNT_ROOT/etc/systemd/timesyncd.conf" << 'NTPEOF'
[Time]
NTP=time.cloudflare.com pool.ntp.org
FallbackNTP=time.google.com 0.debian.pool.ntp.org
NTPEOF

# WiFi-Ländercode DE (drei Methoden gleichzeitig für maximale Kompatibilität):
# 1. wireless-regdb Konfiguration (Bookworm: crda entfernt, Kernel nutzt eingebaute DB)
echo "REGDOMAIN=DE" > "$MOUNT_ROOT/etc/default/crda" 2>/dev/null || true
# 2. wireless-regdb (neuere Methode via kernel-internal database)
echo "options cfg80211 ieee80211_regdom=DE" > "$MOUNT_ROOT/etc/modprobe.d/cfg80211-regdom.conf"
# 3. Kernel-Parameter (greift bevor Treiber lädt — zuverlässigster Weg)
if ! grep -q "cfg80211.ieee80211_regdom" "$MOUNT_BOOT/cmdline.txt"; then
    sed -i 's/$/ cfg80211.ieee80211_regdom=DE/' "$MOUNT_BOOT/cmdline.txt"
fi

# Boot-Beschleunigung der Kernel-Phase: serielle Konsole entfernen (jede Kernel-Meldung
# wird sonst synchron mit 115200 Baud auf die langsame UART geschrieben) + 'quiet'
# (weniger Konsolen-Logging). tty1 bleibt als Konsole; SSH ist der reguläre Zugang.
sed -i -E 's/console=serial0,[0-9]+[[:space:]]*//' "$MOUNT_BOOT/cmdline.txt"
grep -q '\bquiet\b' "$MOUNT_BOOT/cmdline.txt" || sed -i 's/$/ quiet/' "$MOUNT_BOOT/cmdline.txt"

# rfkill-Block aufheben: Pi OS blockiert WiFi-Radio bis Ländercode gesetzt
mkdir -p "$MOUNT_ROOT/etc/systemd/system"
cat > "$MOUNT_ROOT/etc/systemd/system/wifi-rfkill-unblock.service" << 'RFKILL_EOF'
[Unit]
Description=WiFi rfkill unblock
After=systemd-modules-load.service
Before=NetworkManager.service network-pre.target
DefaultDependencies=no

[Service]
Type=oneshot
ExecStart=/usr/sbin/rfkill unblock wifi

[Install]
WantedBy=multi-user.target
RFKILL_EOF
chroot "$MOUNT_ROOT" /usr/bin/qemu-aarch64-static /bin/bash -c "systemctl enable wifi-rfkill-unblock"

# ─────────────────────────────────────────────
# 11. ALSA Standardkarte
# ─────────────────────────────────────────────
# Ab PipeWire kein dmix mehr: PipeWire mischt selbst und bedient zusätzlich
# Bluetooth-Sinks. ALSA-Anwendungen laufen über pipewire-alsa auf "default".
# ROLLBACK (falls PipeWire Probleme macht) — /etc/asound.conf mit diesem Inhalt anlegen
# und die PipeWire-User-Dienste stoppen:
#   pcm.!default { type plug  slave.pcm "dmixer" }
#   pcm.dmixer   { type dmix  ipc_key 1024
#                  slave { pcm "hw:wm8960soundcard" rate 44100 channels 2
#                          format S16_LE period_size 1024 buffer_size 8192 } }
#   ctl.!default { type hw    card wm8960soundcard }
rm -f "$MOUNT_ROOT/etc/asound.conf"

# ─────────────────────────────────────────────
# 12. Hostname setzen
# ─────────────────────────────────────────────
echo "musicbox" > "$MOUNT_ROOT/etc/hostname"
sed -i 's/raspberrypi/musicbox/g' "$MOUNT_ROOT/etc/hosts" || true

# ─────────────────────────────────────────────
# 13. System-Konfiguration
# ─────────────────────────────────────────────
log "=== System-Konfiguration ==="

# Timezone
ln -sf /usr/share/zoneinfo/Europe/Berlin "$MOUNT_ROOT/etc/localtime"
echo "Europe/Berlin" > "$MOUNT_ROOT/etc/timezone"

# Firstboot-Init entfernen – verhindert Reset unserer Konfiguration beim ersten Boot
sed -i 's| init=/usr/lib/raspberrypi-sys-mods/firstboot||g' "$MOUNT_BOOT/cmdline.txt" 2>/dev/null || true
sed -i 's| sysctl.vm.swappiness=1||g' "$MOUNT_BOOT/cmdline.txt" 2>/dev/null || true

chroot "$MOUNT_ROOT" /usr/bin/qemu-aarch64-static /bin/bash << 'CHROOT_SYSCONF'
set -euo pipefail

# Locale: de_DE.UTF-8
sed -i 's/^# *de_DE.UTF-8 UTF-8/de_DE.UTF-8 UTF-8/' /etc/locale.gen
locale-gen
update-locale LANG=de_DE.UTF-8

# Keyboard-Layout: seit Bookworm 2024-11-19 bricht NM ohne diese Datei beim ersten Boot ab
cat > /etc/default/keyboard << 'KBEOF'
XKBMODEL="pc105"
XKBLAYOUT="de"
XKBVARIANT=""
XKBOPTIONS=""
BACKSPACE="guess"
KBEOF

# Wartungs-User "pi" mit Passwort "musicbox" (bitte nach erstem Login ändern)
# Gruppen entsprechen dem Pi OS Bookworm Standard-User
id -u pi &>/dev/null || useradd -m -s /bin/bash \
    -G sudo,adm,dialout,cdrom,audio,video,plugdev,games,users,input,netdev,gpio,i2c,spi pi
# Shell explizit setzen — Basis-Image hat pi ggf. mit /usr/sbin/nologin vorbelegt
usermod -s /bin/bash pi
usermod -aG sudo,adm,dialout,cdrom,audio,video,plugdev,games,users,input,netdev,gpio,i2c,spi pi
echo "pi:musicbox" | chpasswd
# /etc/nologin entfernen: Basis-Image legt diese Datei als Firstboot-Lock an
rm -f /etc/nologin

# --- PipeWire: Nur der Dienstnutzer betreibt einen Soundserver ---
# Auf der Box liefen musicbox (PipeWire) UND ein per SSH eingeloggter Nutzer (eigene
# PipeWire/WirePlumber-Instanz) gleichzeitig — beide Instanzen kämpften um denselben
# Bluetooth-A2DP-Transport ("Multiple sound server instances ... probably trying to use
# Bluetooth audio at the same time"), der Kopfhörer-Sink verschwand aus PipeWire des
# Dienstnutzers. Deshalb: PipeWire/WirePlumber für alle regulären Login-Nutzer (uid >=
# 1000, hier: pi) maskieren — nur musicbox (System-User, uid < 1000) darf einen
# Soundserver betreiben. /etc/skel mit einschließen, damit künftig angelegte Nutzer es
# erben.
mask_pipewire_for_home() {
    local home="$1" owner="$2"
    mkdir -p "$home/.config/systemd/user"
    for unit in pipewire.service pipewire.socket pipewire-pulse.service pipewire-pulse.socket wireplumber.service; do
        ln -sf /dev/null "$home/.config/systemd/user/$unit"
    done
    if [ -n "$owner" ]; then chown -R "$owner:$owner" "$home/.config"; fi
}
while IFS=: read -r uname _ uid _ _ uhome _; do
    [ "$uid" -ge 1000 ] || continue
    [ -d "$uhome" ] || continue
    mask_pipewire_for_home "$uhome" "$uname"
done < /etc/passwd
mask_pipewire_for_home /etc/skel ""
echo "✓ PipeWire für Login-Nutzer maskiert (nur musicbox betreibt den Soundserver)"

# SSH: explizit aktivieren (touch /boot/firmware/ssh reicht in Bookworm ohne firstboot nicht)
systemctl enable ssh

# SSH: Passwort-Login explizit erlauben
mkdir -p /etc/ssh/sshd_config.d
cat > /etc/ssh/sshd_config.d/musicbox.conf << 'SSHEOF'
PasswordAuthentication yes
PermitRootLogin no
SSHEOF

# SSH-Host-Keys beim ersten Boot neu generieren (jedes Gerät bekommt eigene Keys)
systemctl enable regenerate_ssh_host_keys

# avahi: publish-workstation=yes damit musicbox.local zuverlässig auflöst
sed -i 's/^#*publish-workstation=.*/publish-workstation=yes/' /etc/avahi/avahi-daemon.conf \
    || echo "publish-workstation=yes" >> /etc/avahi/avahi-daemon.conf

# Hardware-Watchdog-Daemon konfigurieren
cat > /etc/watchdog.conf << 'WDEOF'
watchdog-device = /dev/watchdog
watchdog-timeout = 15
max-load-1 = 24
WDEOF
systemctl enable watchdog

echo "System-Config OK"
CHROOT_SYSCONF

# ─────────────────────────────────────────────
# 14. Aufräumen
# ─────────────────────────────────────────────
log "=== Chroot aufräumen ==="
rm -f "$MOUNT_ROOT/usr/bin/qemu-aarch64-static"
rm -f "$MOUNT_ROOT/etc/resolv.conf"
# resolv.conf NICHT auf den systemd-resolved-Stub zeigen lassen (resolved ist nicht
# installiert → Symlink wäre tot, keine DNS-Auflösung). NetworkManager (dns=default,
# s. conf.d/dns.conf) schreibt /run/NetworkManager/resolv.conf; wir verlinken dorthin.
chroot "$MOUNT_ROOT" /bin/ln -sf /run/NetworkManager/resolv.conf /etc/resolv.conf 2>/dev/null || true
# apt-Caches leeren
chroot "$MOUNT_ROOT" /usr/bin/apt-get clean 2>/dev/null || true
rm -rf "$MOUNT_ROOT/var/lib/apt/lists"/*
rm -rf "$MOUNT_ROOT/tmp"/*

# Mounts lösen (trap macht den Rest)
for sub in dev/pts dev proc sys run; do
    umount "$MOUNT_ROOT/$sub" 2>/dev/null || true
done
umount "$MOUNT_ROOT/boot/firmware" 2>/dev/null || true
umount "$MOUNT_BOOT"  2>/dev/null || true
umount "$MOUNT_ROOT"  2>/dev/null || true
losetup -d "$LOOP_DEV"; LOOP_DEV=""

df -h "$OUTPUT_IMG" 2>/dev/null || true

log "=== Build abgeschlossen: $OUTPUT_IMG ==="
log "    Flash mit: rpi-imager → 'Use custom image' → musicbox.img.xz"
