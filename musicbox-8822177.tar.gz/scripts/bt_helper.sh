#!/usr/bin/env bash
# Root-Helfer für die Bluetooth-Verwaltung. Reicht nur an das geprüfte Python-Modul durch.
# Aufruf (vom Web via sudo): bt_helper.sh <scan|list|status|pair|connect|disconnect|forget> [args…]
set -euo pipefail
exec /opt/musicbox/venv/bin/python -m musicbox.connectivity.bluetooth "$@"
