#!/usr/bin/env python3
"""Holt nacheinander alle Spotify-Karten und -Bibliothekseinträge offline.

Der Hol-Vorgang der Weboberfläche arbeitet einen Eintrag zur Zeit — das ist im
Alltag richtig, denn er gehört zu einer Karte, die jemand offline haben will.
Für einen Rundumschlag ("nimm alles mit") stößt dieses Skript ihn der Reihe
nach für jeden Eintrag an und wartet jeweils ab.

Auf der Box ausführen:

    python3 hole_alle_offline.py            # holen
    python3 hole_alle_offline.py --zeigen   # nur auflisten, nichts holen

Es läuft lange (bei einigen hundert Titeln über eine Stunde) und schreibt
seinen Fortschritt fortlaufend, damit man es im Hintergrund laufen lassen und
später nachlesen kann.
"""

from __future__ import annotations

import json
import random
import sys
import time
import urllib.error
import urllib.request

WEB = "http://127.0.0.1:8080"
# Nach jedem Auftrag läuft ein Abgleich: Er räumt die geholten Dateien ein,
# rechnet ReplayGain und stellt den Eintrag um. Das dauert — auf der Box je nach
# Netz mehrere Minuten. So lange wird auf die Umstellung gewartet, bevor der
# nächste Eintrag drankommt; zwei Läufe gleichzeitig gäbe es ohnehin nicht, der
# zweite prallte nur an der Sperre ab.
GEDULD_ABGLEICH_S = 420
# Ein Auftrag umfasst höchstens ein Häppchen (siehe fetch.py). Nach dieser Zeit
# gilt er als hängengeblieben.
GEDULD_JE_EINTRAG_S = 1800
# Ruhe zwischen zwei Aufträgen. Spotify verweigert die Audio-Schlüssel, wenn zu
# viele in kurzer Folge angefragt werden — auf der Box nach rund 120 Titeln.
# Diese Pause hält die Rate deutlich unter dem, was den Ärger ausgelöst hat.
# Bewusst höher als die ursprünglichen 90 s: der Gesamtdurchsatz soll niedrig
# bleiben, nicht nur nach einer Drosselung.
PAUSE_ZWISCHEN_AUFTRAEGEN_S = 150
# Nach einer Drosselung so lange warten, bevor es weitergeht — als Basiswert
# für naechste_drossel_pause(), das mit jeder unmittelbar folgenden Drosselung
# verdoppelt. Eine feste Wartezeit hat sich als zu knapp erwiesen: Ein
# einzelner Sammellauf geriet trotz 15 Minuten Pause erneut in die Drosselung.
PAUSE_NACH_DROSSELUNG_S = 900
# Mehr wird nicht gewartet, auch nach vielen Drosselungen in Folge.
PAUSE_NACH_DROSSELUNG_MAX_S = 3600
# So oft wird nach einer Drosselung insgesamt gewartet, bevor aufgegeben wird.
DROSSEL_VERSUCHE = 3
# Sind alle fehlenden Titel geholt und warten nur noch aufs Einräumen, wird in
# diesem Abstand erneut nachgesehen. Das Einräumen rechnet ReplayGain und
# braucht auf der Box mehrere Minuten je Datei.
PAUSE_EINRAEUMEN_S = 240
# Insgesamt so lange auf das Einräumen eines Eintrags warten, dann weiter zum
# nächsten — der Rest holt sich beim nächsten Lauf von selbst.
GEDULD_EINRAEUMEN_S = 3600
# Streuung um die berechnete Pause, damit nicht jedesmal auf die Minute genau
# dieselbe Wartezeit entsteht — ein Muster, das sich seinerseits wie eine
# feste Taktung anfühlt und leichter erkennbar ist.
_STREUUNG = 0.3


def naechste_drossel_pause(drosselungen: int, zufall: random.Random = random) -> int:
    """Wartezeit nach der n-ten Drosselung in Folge — wächst und streut.

    ``drosselungen`` zählt bei 1 (erste Drosselung dieses Auftrags). Die Pause
    wächst mit jeder weiteren Drosselung, gedeckelt bei
    ``PAUSE_NACH_DROSSELUNG_MAX_S``, und wird zusätzlich um ±``_STREUUNG``
    verwürfelt: mal kürzer, mal länger als der berechnete Wert — nie exakt
    dieselben 15 Minuten. ``zufall`` ist austauschbar, damit der Test
    reproduzierbar bleibt.
    """
    basis = min(PAUSE_NACH_DROSSELUNG_S * (2 ** (drosselungen - 1)),
                PAUSE_NACH_DROSSELUNG_MAX_S)
    return int(basis * zufall.uniform(1 - _STREUUNG, 1 + _STREUUNG))


def hole(pfad: str, koerper: dict | None = None, zeitlimit: float = 30.0):
    daten = json.dumps(koerper).encode() if koerper is not None else None
    anfrage = urllib.request.Request(
        WEB + pfad, data=daten,
        headers={"Content-Type": "application/json"} if daten else {},
        method="POST" if daten is not None else "GET")
    try:
        with urllib.request.urlopen(anfrage, timeout=zeitlimit) as antwort:
            return json.loads(antwort.read())
    except urllib.error.HTTPError as e:
        return {"ok": False, "reason": f"http_{e.code}"}
    except Exception as e:
        return {"ok": False, "reason": str(e)[:60]}


def sag(text: str = "") -> None:
    print(text, flush=True)


def offene_eintraege() -> list:
    """Alles, was noch auf Spotify zeigt — Karten zuerst, sie sind die
    sichtbaren."""
    mapping = json.load(open("/var/lib/musicbox/mapping.json"))
    eintraege = [(u, e, "Karte") for u, e in mapping["cards"].items()]
    eintraege += [(i, e, "Bibliothek") for i, e in (mapping.get("library") or {}).items()]

    offen = []
    for key, e, art in eintraege:
        if e.get("type") == "spotify_queue":
            offen.append((key, e, art))
        elif e.get("type") == "spotify":
            ref = e.get("ref") or ""
            if any(t in ref for t in (":playlist:", ":album:", ":track:")):
                offen.append((key, e, art))
    return offen


def warte_auf_ende(label: str) -> dict:
    """Verfolgt einen laufenden Auftrag und meldet Fortschritt."""
    beginn = time.monotonic()
    zuletzt = -1
    while time.monotonic() - beginn < GEDULD_JE_EINTRAG_S:
        time.sleep(15)
        stand = hole("/api/offline/fetch")
        erledigt, gesamt = stand.get("done", 0), stand.get("total", 0)
        if erledigt != zuletzt:
            fehl = len(stand.get("failures") or [])
            sag(f"      {erledigt}/{gesamt}" + (f", {fehl} Fehlschläge" if fehl else ""))
            zuletzt = erledigt
        if not stand.get("running"):
            return stand
    sag("      Geduld erschöpft — weiter mit dem nächsten Eintrag")
    return {}


def warte_auf_umstellung(key: str) -> bool:
    """Wartet, bis der Abgleich den Eintrag auf lokal umgestellt hat.

    Der Abgleich läuft im Hintergrund des Web-Prozesses; direkt nach dem Holen
    ist er noch nicht durch. Ohne dieses Warten meldete das Skript "noch nicht
    umgestellt", obwohl es kurz darauf geschah.
    """
    beginn = time.monotonic()
    while time.monotonic() - beginn < GEDULD_ABGLEICH_S:
        time.sleep(15)
        mapping = json.load(open("/var/lib/musicbox/mapping.json"))
        eintrag = (mapping["cards"].get(key)
                   or (mapping.get("library") or {}).get(key) or {})
        if eintrag.get("type") == "local" and eintrag.get("offline_of"):
            return True
    return False


def main() -> int:
    nur_zeigen = "--zeigen" in sys.argv
    offen = offene_eintraege()

    sag(f"{len(offen)} Eintrag/Einträge zeigen noch auf Spotify")
    for key, e, art in offen:
        sag(f"   {key:14} {art:11} {(e.get('label') or '')[:40]}")
    sag()

    if nur_zeigen:
        return 0

    umgestellt, vollstaendig, gescheitert = 0, 0, []
    drosselungen = 0

    for nr, (key, e, art) in enumerate(offen, 1):
        label = (e.get("label") or key)[:40]
        sag(f"[{nr}/{len(offen)}] {label}")
        einraeum_wartezeit = 0

        # Ein Eintrag braucht mehrere Aufträge, wenn er mehr Titel hat als ein
        # Häppchen fasst. Hier so lange anstoßen, bis nichts mehr offen ist.
        while True:
            antwort = hole("/api/offline/fetch", {"key": key, "category": "musik"},
                           zeitlimit=120)
            grund = antwort.get("reason")

            if grund == "complete":
                sag("      liegt vollständig vor")
                vollstaendig += 1
                break
            if grund == "einraeumen_laeuft":
                # Alles Fehlende ist geholt und wartet im Download-Ordner. Ein
                # weiterer Auftrag holte nur dieselben Titel erneut — genau der
                # Fehler, der hier zu doppelten Anfragen und damit zur
                # Drosselung geführt hat. Also abwarten, bis der Abgleich sie
                # eingeräumt hat, und dann erneut nachsehen.
                if einraeum_wartezeit >= GEDULD_EINRAEUMEN_S:
                    sag("      Einräumen dauert zu lange — Rest bleibt für später")
                    gescheitert.append((label, "einräumen offen"))
                    break
                sag(f"      {antwort.get('wartend', 0)} Titel geholt, warten aufs "
                    f"Einräumen — schaue in {PAUSE_EINRAEUMEN_S // 60} Minuten erneut")
                time.sleep(PAUSE_EINRAEUMEN_S)
                einraeum_wartezeit += PAUSE_EINRAEUMEN_S
                continue
            if not antwort.get("ok"):
                sag(f"      abgelehnt: {antwort.get('message') or grund}")
                gescheitert.append((label, grund))
                break

            offene = antwort.get("verbleibend") or 0
            sag(f"      {antwort.get('missing')} Titel"
                + (f", danach noch {offene} offen" if offene else ""))
            stand = warte_auf_ende(label)

            if stand.get("throttled"):
                drosselungen += 1
                sag(f"      Spotify drosselt ({stand.get('key_errors')} Titel abgewiesen)")
                if drosselungen > DROSSEL_VERSUCHE:
                    sag("      zu oft gedrosselt — Rest bleibt für später")
                    gescheitert.append((label, "gedrosselt"))
                    break
                pause = naechste_drossel_pause(drosselungen)
                sag(f"      warte {pause // 60} Minuten")
                time.sleep(pause)
                continue

            fehl = len(stand.get("failures") or [])
            if fehl:
                sag(f"      {fehl} Titel nicht verfügbar")

            if not offene:
                break
            time.sleep(PAUSE_ZWISCHEN_AUFTRAEGEN_S)

        if warte_auf_umstellung(key):
            sag("      → spielt jetzt lokal")
            umgestellt += 1
        else:
            sag("      → noch nicht vollständig")
        time.sleep(PAUSE_ZWISCHEN_AUFTRAEGEN_S)

    sag()
    sag(f"Fertig: {umgestellt} umgestellt, {vollstaendig} lagen schon vor, "
        f"{len(gescheitert)} nicht möglich")
    for label, grund in gescheitert:
        sag(f"   {label}: {grund}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
