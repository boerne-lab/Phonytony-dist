#!/usr/bin/env bash
# Erst-Installation der MusicBox auf Raspberry Pi OS Bookworm.
# Aufruf: sudo bash scripts/setup.sh
set -euo pipefail

INSTALL_DIR="/opt/musicbox"
CONFIG_DIR="/etc/musicbox"
DATA_DIR="/var/lib/musicbox"
SERVICE_USER="musicbox"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "=== MusicBox Setup ==="
echo "Repo: $REPO_DIR"
echo "Install: $INSTALL_DIR"

# --- Pakete ---
apt-get update -qq
apt-get install -y \
    python3-pip python3-venv python3-dev python3-lgpio python3-spidev \
    i2c-tools \
    mpv \
    alsa-utils libasound2-plugins \
    pipewire pipewire-audio pipewire-alsa pipewire-pulse wireplumber \
    libspa-0.2-bluetooth pulseaudio-utils bluez rfkill \
    avahi-daemon libnss-mdns \
    git curl wget

# --- Hardware-Overlays ---
CONFIG_TXT="/boot/firmware/config.txt"
[ -f "$CONFIG_TXT" ] || CONFIG_TXT="/boot/config.txt"

add_config() {
    grep -qF "$1" "$CONFIG_TXT" || echo "$1" >> "$CONFIG_TXT"
}
add_config "dtparam=i2c_arm=on"
add_config "dtparam=i2s=on"
# SPI für RC522 RFID-Reader
add_config "dtparam=spi=on"
# Waveshare WM8960 Audio HAT (WM8960-Codec, I2S + I2C)
add_config "dtoverlay=wm8960-soundcard"
# Headless-Optimierung: Display/GPU, Kamera, Onboard-Audio aus (WM8960 läuft über I2S/I2C).
sed -i -E "s|^[[:space:]]*(dtoverlay=vc4-kms-v3d)[[:space:]]*\$|#&  # headless-deaktiviert|" "$CONFIG_TXT"
sed -i -E "s|^[[:space:]]*(max_framebuffers=2)[[:space:]]*\$|#&  # headless-deaktiviert|" "$CONFIG_TXT"
sed -i -E "s|^[[:space:]]*(display_auto_detect=1)[[:space:]]*\$|#&  # headless-deaktiviert|" "$CONFIG_TXT"
sed -i -E "s|^[[:space:]]*dtparam=audio=on.*|dtparam=audio=off|" "$CONFIG_TXT"
sed -i -E "s|^[[:space:]]*camera_auto_detect=1.*|camera_auto_detect=0|" "$CONFIG_TXT"
add_config "gpu_mem=16"
add_config "disable_splash=1"

# SD-Bustakt: Der Boot hängt an der Lesegeschwindigkeit der Karte — systemd
# startet bei 3,1 s, die erste fertige Unit kommt erst bei 6,4 s, dazwischen
# liest PID 1 Unit-Dateien von der Karte. 84 statt 50 MHz: 36 statt 23 MB/s,
# gemessen gesamt 20,5 -> 18,4 s und Ton 14,4 -> 12,7 s.
# KARTENABHÄNGIG: 100 MHz hielt die Testkarte nicht (Treiber meldet "reducing
# overclock due to errors"). Nach dem ersten Boot prüfen mit:
#   dmesg | grep -i "reducing overclock"   -> Treffer heißt: Wert senken.
add_config "dtparam=sd_overclock=84"
# Kernel-Phase: serielle Konsole raus (langsames UART-Logging) + quiet
CMDLINE="$(dirname "$CONFIG_TXT")/cmdline.txt"
if [ -f "$CMDLINE" ]; then
    sed -i -E 's/console=serial0,[0-9]+[[:space:]]*//' "$CMDLINE"
    grep -q '\bquiet\b' "$CMDLINE" || sed -i 's/$/ quiet/' "$CMDLINE"
fi
cat > /etc/modprobe.d/musicbox-headless.conf <<'BLACKLIST'
# Headless-Musicbox: keine Kamera → V4L2/ISP/Codec-Module nicht laden
blacklist bcm2835_v4l2
blacklist bcm2835_isp
blacklist bcm2835_codec
BLACKLIST
echo "✓ /boot/firmware/config.txt aktualisiert (headless: Display/Kamera/Onboard-Audio aus)"

# --- Service-User ---
id -u "$SERVICE_USER" &>/dev/null || useradd -r -s /usr/sbin/nologin -m -d "$DATA_DIR" "$SERVICE_USER"
usermod -aG audio,gpio,i2c,spi "$SERVICE_USER" 2>/dev/null || true
echo "✓ User $SERVICE_USER"

# --- PipeWire: Linger + XDG_RUNTIME_DIR ---
# PipeWire läuft als User-Dienst von musicbox. Linger sorgt dafür, dass die Instanz
# ohne Login startet; alle drei Dienste zeigen über XDG_RUNTIME_DIR auf dieselbe.
loginctl enable-linger "$SERVICE_USER" || true
MB_UID="$(id -u "$SERVICE_USER")"
for unit in musicbox-core musicbox-web own-librespot; do
    mkdir -p "/etc/systemd/system/${unit}.service.d"
    cat > "/etc/systemd/system/${unit}.service.d/pipewire.conf" << EOF
[Service]
Environment=XDG_RUNTIME_DIR=/run/user/${MB_UID}
Environment=PULSE_RUNTIME_PATH=/run/user/${MB_UID}/pulse
EOF
done
sudo -u "$SERVICE_USER" XDG_RUNTIME_DIR="/run/user/${MB_UID}" \
    systemctl --user enable pipewire pipewire-pulse wireplumber || true
echo "✓ PipeWire-Linger und XDG_RUNTIME_DIR-Drop-ins gesetzt"

echo ">> Persistentes Journal (mit Deckel gegen SD-Verschleiß)"
# Ohne das schreibt journald nach /run und die Fehlerhistorie ist nach jedem
# Neustart weg — genau die Fälle, die man untersuchen will, überleben dann nicht.
mkdir -p /etc/systemd/journald.conf.d /var/log/journal
install -m0644 "$REPO_DIR/systemd/journald-musicbox.conf" \
  /etc/systemd/journald.conf.d/50-musicbox.conf
systemd-tmpfiles --create --prefix /var/log/journal >/dev/null 2>&1 || true
systemctl restart systemd-journald || true
# Der Neustart allein lässt das bereits geschriebene Journal unter /run liegen —
# erst der Flush schiebt es nach /var/log/journal, sonst wirkt der Umstieg erst
# nach dem nächsten Boot.
journalctl --flush >/dev/null 2>&1 || true

# --- BlueZ: Box-eigene Einstellungen in /etc/bluetooth/main.conf ---
# main.conf ist eine Paketdatei voller auskommentierter Vorgaben. Deshalb wird sie nicht
# ersetzt, sondern nur um einen klar markierten Block am Ende ergaenzt; ein erneuter Lauf
# entfernt den alten Block zuerst (idempotent, keine Duplikate). Vorher eine Sicherung.
apply_bluetooth_main_conf() {
    local root="${1:-}"
    local conf="$root/etc/bluetooth/main.conf"
    mkdir -p "$root/etc/bluetooth"
    [ -f "$conf" ] || : > "$conf"
    cp -n "$conf" "$conf.bak" 2>/dev/null || true
    # Fassungen aus der Zeit vor den Markern mitnehmen: sie beginnen mit einer
    # "# --- Musicbox: ..."-Ueberschrift und reichen bis zum Marker-Block bzw. bis
    # zum Dateiende. Ohne das bleibt der alte Block fuer immer liegen und der
    # Block steht doppelt in der Datei (auf der Box so vorgefunden).
    sed -i '/^# --- Musicbox:/,/^# >>> musicbox-bluetooth >>>$/{/^# >>> musicbox-bluetooth >>>$/!d}' "$conf"
    sed -i '/^# >>> musicbox-bluetooth >>>$/,/^# <<< musicbox-bluetooth <<<$/d' "$conf"
    # Nachlaufende Leerzeilen abschneiden, damit der Block bei jedem Lauf gleich aussieht.
    printf '%s\n' "$(cat "$conf")" > "$conf"
    {
        echo
        echo "# >>> musicbox-bluetooth >>>"
        cat "$REPO_DIR/systemd/bluetooth-main.conf.block"
        echo "# <<< musicbox-bluetooth <<<"
    } >> "$conf"
}

apply_bluetooth_main_conf
systemctl restart bluetooth || true
echo "✓ BlueZ-Einstellungen gesetzt (Class/FastConnectable/JustWorksRepairing/AutoEnable)"

# --- WirePlumber: Headless-Bluetooth-Konfiguration ---
# Seat-Monitoring aus (musicbox ist ein lingernder Systemnutzer ohne Seat) und
# Rollenbeschränkung auf a2dp_source (die Box ist die Quelle, der Kopfhörer die Senke).
mkdir -p /etc/wireplumber/wireplumber.conf.d
install -m0644 "$REPO_DIR/systemd/wireplumber-headless-bluetooth.conf" \
    /etc/wireplumber/wireplumber.conf.d/50-headless-bluetooth.conf
echo "✓ WirePlumber-Bluetooth-Konfiguration installiert"

# --- PipeWire: Nur der Dienstnutzer betreibt einen Soundserver ---
# Auf der Box liefen musicbox (PipeWire) UND ein per SSH eingeloggter Nutzer (eigene
# PipeWire/WirePlumber-Instanz) gleichzeitig — beide Instanzen kämpften um denselben
# Bluetooth-A2DP-Transport ("Multiple sound server instances ... probably trying to use
# Bluetooth audio at the same time"), der Kopfhörer-Sink verschwand aus PipeWire des
# Dienstnutzers. Deshalb: PipeWire/WirePlumber für alle regulären Login-Nutzer (uid >=
# 1000) maskieren — nur musicbox (System-User, uid < 1000) darf einen Soundserver
# betreiben. /etc/skel mit einschließen, damit künftig angelegte Nutzer es erben.
mask_pipewire_for_home() {
    local home="$1" owner="$2"
    mkdir -p "$home/.config/systemd/user"
    for unit in pipewire.service pipewire.socket pipewire-pulse.service pipewire-pulse.socket wireplumber.service; do
        ln -sf /dev/null "$home/.config/systemd/user/$unit"
    done
    if [ -n "$owner" ]; then chown -R "$owner:$owner" "$home/.config"; fi
}
while IFS=: read -r uname _ uid _ _ uhome _; do
    [ "$uid" -ge 1000 ] || continue
    [ -d "$uhome" ] || continue
    mask_pipewire_for_home "$uhome" "$uname"
done < /etc/passwd
mask_pipewire_for_home /etc/skel ""
echo "✓ PipeWire für Login-Nutzer maskiert (nur musicbox betreibt den Soundserver)"

# --- own-librespot (eigener Fork mit Track-Export) ---
# Das Binary wird hier NICHT geladen. Der Fork ist privat und bleibt es: Eine
# Software, die Spotify-Inhalte entschluesselt und als Dateien ablegt, ist privat
# genutzt etwas anderes als oeffentlich bereitgestellt. Die Box bekommt deshalb
# keine Zugangsdaten — das Binary kommt beim Bauen des Images hinein
# (siehe build-image.sh) oder wird von Hand eingespielt.
if [ ! -x /usr/local/bin/own-librespot ]; then
    echo "FEHLER: /usr/local/bin/own-librespot fehlt." >&2
    echo "        Ohne das Binary bleibt die Box ohne Spotify." >&2
    echo "        Es kommt normalerweise ueber build-image.sh ins Image." >&2
    echo "        Nachtraeglich einspielen:" >&2
    echo "          gh release download v0.9.1 --repo boerne-lab/own-librespot \\" >&2
    echo "            --pattern own-librespot_linux_arm64.tar.gz" >&2
    echo "          tar xzf own-librespot_linux_arm64.tar.gz" >&2
    echo "          sudo install -m 0755 own-librespot /usr/local/bin/own-librespot" >&2
    exit 1
fi
echo "✓ own-librespot vorhanden ($(/usr/local/bin/own-librespot --version 2>/dev/null | head -1 || echo 'Version unbekannt'))"

# --- Python-Paket ---
rsync -a --delete "$REPO_DIR/" "$INSTALL_DIR/" --exclude='.git' --exclude='venv' --exclude='__pycache__'
# --system-site-packages: lgpio + spidev kommen von apt (python3-lgpio/python3-spidev)
python3 -m venv --system-site-packages "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip -q
"$INSTALL_DIR/venv/bin/pip" install -e "$INSTALL_DIR" -q
echo "✓ Python-Paket installiert"

# --- Verzeichnisse & Konfig ---
mkdir -p "$CONFIG_DIR" "$DATA_DIR/sounds" "$DATA_DIR/music" "$DATA_DIR/tokens" "$DATA_DIR/playlists" "$DATA_DIR/librespot-cache"
cp -n "$REPO_DIR/config/config.toml"        "$CONFIG_DIR/config.toml" 2>/dev/null || true
# own-librespot liest config.yml aus --config_dir (/etc/musicbox)
cp -n "$REPO_DIR/config/go-librespot.yml"   "$CONFIG_DIR/config.yml" 2>/dev/null || true
# .env mit AKTIVEN Pfad-Variablen erzeugen (.env.example hat sie auskommentiert →
# sonst landen Daten unter /opt/musicbox statt /var/lib/musicbox).
if [ ! -f "$CONFIG_DIR/.env" ]; then
    cat > "$CONFIG_DIR/.env" << ENVEOF
MUSICBOX_CONFIG=$CONFIG_DIR/config.toml
MUSICBOX_DATA_DIR=$DATA_DIR
SPOTIFY_CLIENT_ID=
SPOTIFY_REDIRECT_URI=http://127.0.0.1:8080/auth/spotify/callback
ENVEOF
fi
chown -R "$SERVICE_USER:$SERVICE_USER" "$CONFIG_DIR" "$DATA_DIR" "$INSTALL_DIR"
echo "✓ Verzeichnisse erstellt"

# --- Sounds: fertig gerenderte WAVs aus dem Repo in den Datenordner kopieren ---
mkdir -p "$DATA_DIR/sounds"
cp "$REPO_DIR"/musicbox/audio/sounds/*.wav "$DATA_DIR/sounds/"

# --- ALSA-Standardkarte ---
# Ab PipeWire kein dmix mehr: PipeWire mischt selbst und bedient zusätzlich
# Bluetooth-Sinks. ALSA-Anwendungen laufen über pipewire-alsa auf "default".
# ROLLBACK (falls PipeWire Probleme macht) — /etc/asound.conf mit diesem Inhalt anlegen
# und die PipeWire-User-Dienste stoppen:
#   pcm.!default { type plug  slave.pcm "dmixer" }
#   pcm.dmixer   { type dmix  ipc_key 1024
#                  slave { pcm "hw:wm8960soundcard" rate 44100 channels 2
#                          format S16_LE period_size 1024 buffer_size 8192 } }
#   ctl.!default { type hw    card wm8960soundcard }
rm -f /etc/asound.conf
echo "✓ /etc/asound.conf entfernt (PipeWire übernimmt das Mischen)"

# --- Systemd ---
cp "$REPO_DIR/systemd/"*.service /etc/systemd/system/
# .timer-Units bisher nicht mitkopiert — für musicbox-bt-watchdog.timer (und künftig
# musicbox-update.timer) nachgezogen, analog zu build-image.sh/box_deploy.sh.
cp "$REPO_DIR/systemd/"*.timer /etc/systemd/system/ 2>/dev/null || true
# Pfade in Services auf DATA_DIR anpassen
sed -i "s|/var/lib/musicbox|$DATA_DIR|g" /etc/systemd/system/musicbox-*.service || true

# sudo-Regel für den Bluetooth-Helfer (die Weboberfläche ruft ihn als musicbox auf)
install -m0440 "$REPO_DIR/systemd/musicbox-bluetooth.sudoers" /etc/sudoers.d/musicbox-bluetooth
chmod 0755 "$INSTALL_DIR/scripts/bt_helper.sh"
chmod 0755 "$INSTALL_DIR/scripts/bt_watchdog.sh"
visudo -c >/dev/null

systemctl daemon-reload
systemctl enable systemd-timesyncd own-librespot musicbox-alsa-init musicbox-core musicbox-web musicbox-bt-power
# Bluetooth-Wachhund: alle 5 Minuten prüfen/beleben, siehe scripts/bt_watchdog.sh
systemctl enable musicbox-bt-watchdog.timer
systemctl start musicbox-bt-watchdog.timer
echo "✓ Services registriert"

# Boot-Beschleunigung: für eine headless-Appliance unnötige Standarddienste abschalten.
# cloud-init (~5,5s), console/keyboard-setup (~4,8s), udisks2 (2s), e2scrub, wait-online (1,5s).
# avahi-daemon bleibt aktiv (mDNS für musicbox.local).
# userconfig.service: Pi-Erstboot-Benutzerdialog auf tty8 — blockiert headless multi-user.target.
systemctl mask userconfig.service 2>/dev/null || true
systemctl mask cloud-init.service cloud-init-local.service cloud-config.service cloud-final.service 2>/dev/null || true
systemctl mask console-setup.service keyboard-setup.service 2>/dev/null || true
systemctl mask udisks2.service 2>/dev/null || true
systemctl mask e2scrub_reap.service 2>/dev/null || true
systemctl disable e2scrub_all.timer 2>/dev/null || true
systemctl disable NetworkManager-wait-online.service 2>/dev/null || true
touch /etc/cloud/cloud-init.disabled 2>/dev/null || true
echo "✓ Boot-Bremsen (cloud-init, console/keyboard-setup, udisks2, wait-online) deaktiviert"

# Akku/Compute: periodische Wartungs-Timer abschalten (tägliche Netz/CPU/SD-Wakeups).
# apt-daily kann ungefragt Pakete ziehen — Updates laufen über musicbox-update.timer.
systemctl mask apt-daily.service apt-daily.timer apt-daily-upgrade.service apt-daily-upgrade.timer 2>/dev/null || true
systemctl mask man-db.service man-db.timer 2>/dev/null || true
systemctl mask dpkg-db-backup.service dpkg-db-backup.timer 2>/dev/null || true
systemctl mask rpi-resize-swap-file.service 2>/dev/null || true
echo "✓ Wartungs-Timer (apt-daily, man-db, dpkg-db-backup, rpi-resize-swap) deaktiviert"

# --- Avahi (musicbox.local) ---
hostnamectl set-hostname musicbox 2>/dev/null || true
systemctl enable avahi-daemon 2>/dev/null || true

echo ""
echo "======================================"
echo "  Setup abgeschlossen!"
echo "  NEUSTART erforderlich:"
echo "    sudo reboot"
echo ""
echo "  Danach:"
echo "  1. http://musicbox.local:8080/auth/spotify/start"
echo "     → Spotify OAuth durchführen"
echo "  2. Tag auflegen → Web-UI zum Zuweisen öffnen"
echo "======================================"
