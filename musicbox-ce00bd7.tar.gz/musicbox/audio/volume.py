"""AlsaVolume: Lautstärke über amixer lesen/setzen.

Der WM8960-Codec (RASPIAUDIO MIC+) hat separate ALSA-Controls für
Headphone-Ausgang (3,5mm-Klinke) und Speaker-Ausgang (Onboard/extern).
Beide werden immer gemeinsam gesteuert.

Tatsächliche Control-Namen auf dem Pi prüfen mit:
  amixer -c wm8960soundcard scontrols
"""

from __future__ import annotations

import logging
import subprocess
import time
from typing import Callable, Optional

log = logging.getLogger(__name__)

# WM8960-typische Control-Namen; werden beim ersten amixer-Aufruf verifiziert
_DEFAULT_CONTROLS = ["Headphone", "Speaker"]

# WM8960: DAC-zu-Output-Mixer-Routing-Switches. Ohne diese bleibt der DAC-Ausgang
# stumm, auch bei voller Lautstärke — das Routing-Path ist schlicht nicht verbunden.
_WM8960_ROUTES = ["Left Output Mixer PCM", "Right Output Mixer PCM"]


class AlsaVolume:
    def __init__(self, card: str, controls: list[str]) -> None:
        self._card = card
        self._controls = controls
        self._current = 75
        # Welche Controls existieren tatsächlich (geprüft in initialize())
        self._available: list[str] = []

    def initialize(self, volume: int) -> None:
        """Beim Start: DAC-Routing aktivieren, Ausgänge einschalten, Lautstärke setzen.

        Prüft gleichzeitig, welche Control-Namen auf diesem Gerät existieren,
        damit fehlende Namen nicht zum Absturz führen.
        """
        existing = self._list_controls()

        # WM8960: DAC→Output-Mixer-Routing-Switches einschalten.
        # Ohne diese ist der DAC nicht mit den Ausgängen verbunden → Stille.
        for route in _WM8960_ROUTES:
            if route in existing:
                self._run("sset", route, "on")

        self._available = [c for c in self._controls if c in existing]

        missing = set(self._controls) - set(self._available)
        if missing:
            log.warning(
                "ALSA-Controls nicht gefunden: %s. "
                "Verfügbare Controls: amixer -c %s scontrols",
                missing,
                self._card,
            )

        for ctrl in self._available:
            # Switch einschalten + Lautstärke setzen in einem Befehl
            self._run("sset", ctrl, f"{volume}%", "on")

        self._current = volume
        log.info(
            "ALSA initialisiert: %s @ %d%% (Card: %s)",
            self._available,
            volume,
            self._card,
        )

    def get(self) -> int:
        """Aktueller Master-Pegel (0–100). Gecacht, da mit Pro-Ausgang-Deckeln der
        tatsächliche amixer-Wert eines Ausgangs vom Master-Pegel abweichen kann."""
        return self._current

    def apply(self, level: int, caps: Optional[dict] = None, mode: str = "both") -> int:
        """Setzt den Master-Pegel mit Pro-Ausgang-Deckel und Ausgangsmodus.

        caps: {"Headphone": 0-100, "Speaker": 0-100} — Obergrenze je Ausgang.
        mode: "both" | "headphone" | "speaker" — welche Ausgänge aktiv sind.
        Inaktive Ausgänge werden stummgeschaltet (Switch off).
        """
        level = max(0, min(100, level))
        caps = caps or {}
        for ctrl in self._available:
            active = (
                mode == "both"
                or (mode == "headphone" and ctrl == "Headphone")
                or (mode == "speaker" and ctrl == "Speaker")
            )
            if active:
                vol = min(level, int(caps.get(ctrl, 100)))
                self._run("sset", ctrl, f"{vol}%", "on")
            else:
                self._run("sset", ctrl, "off")
        self._current = level
        return level

    def fade_out(self, caps: Optional[dict] = None, mode: str = "both",
                 steps: int = 12, step_delay: float = 0.5,
                 sleep: Callable = time.sleep) -> None:
        """Rampt die aktuelle Lautstärke blockierend in `steps` Schritten auf 0.
        Ändert NICHT den gespeicherten Ziel-Pegel — Aufrufer ist dafür verantwortlich,
        die Lautstärke danach per apply() wiederherzustellen, falls gewünscht."""
        if steps <= 0:
            self.apply(0, caps, mode)
            return
        start = self._current
        for i in range(1, steps + 1):
            level = round(start * (1 - i / steps))
            self.apply(level, caps, mode)
            if i < steps:
                sleep(step_delay)

    def set(self, pct: int) -> None:
        # Rückwärtskompatibel: ohne Deckel, beide Ausgänge
        self.apply(pct, {}, "both")

    def _run(self, *args: str) -> bool:
        try:
            subprocess.run(
                # -M: ALSAs "mapped volume" — rechnet Prozentwerte perzeptiv statt
                # roh-linear auf das Hardware-Register um, damit sich Lautstärkeschritte
                # über den ganzen Regelbereich gleichmäßig anfühlen (kein Sprung am oberen Ende).
                ["amixer", "-M", "-c", self._card, *args],
                check=True,
                capture_output=True,
            )
            return True
        except subprocess.CalledProcessError as e:
            log.debug("amixer %s fehlgeschlagen: %s", args, e)
            return False

    def _list_controls(self) -> set[str]:
        """Gibt alle einfachen Mixer-Control-Namen zurück."""
        try:
            out = subprocess.check_output(
                ["amixer", "-c", self._card, "scontrols"],
                stderr=subprocess.DEVNULL,
                text=True,
            )
            controls = set()
            for line in out.splitlines():
                # Format: "Simple mixer control 'Name',0"
                if "'" in line:
                    name = line.split("'")[1]
                    controls.add(name)
            return controls
        except Exception:
            log.warning("Konnte ALSA-Controls nicht auflesen (Card: %s)", self._card)
            return set()
