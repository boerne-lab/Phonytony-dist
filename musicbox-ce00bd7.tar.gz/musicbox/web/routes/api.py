"""REST API: /api/*"""

from __future__ import annotations

import asyncio
import json
import re
import socket
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, Response

from musicbox.web import cover as cover_mod
from musicbox.web import sticker

router = APIRouter()


def _cover_cache_dir(request: Request):
    from pathlib import Path  # noqa: F401  (Pfad-Objekt kommt aus settings)
    s = request.app.state.settings
    return s.music_dir.parent / "cover_cache"


def _ipc(settings, cmd: dict) -> bool:
    """Sendet JSON-Kommando an control.sock; gibt True bei Erfolg zurück."""
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(2.0)
        sock.connect(settings.control_socket)
        sock.sendall((json.dumps(cmd) + "\n").encode())
        resp = json.loads(sock.recv(256))
        sock.close()
        return resp.get("ok", False)
    except Exception:
        return False


@router.get("/status")
def get_status(request: Request) -> dict:
    state_store = request.app.state.state_store
    state_store.load()
    s = state_store.state
    return {
        "volume": s.volume,
        "active_uid": s.active_uid,
        "active_backend": s.active_backend,
        "last_scanned_uid": s.last_scanned_uid,
        "last_scanned_at": s.last_scanned_at,
        "present_uid": s.present_uid,
        "spotify_authorized": _spotify_authorized(request),
    }


def _spotify_authorized(request: Request) -> bool:
    try:
        sp_oauth = request.app.state.sp_oauth
        token = sp_oauth.get_cached_token()
        return token is not None
    except Exception:
        return False


@router.get("/sticker/{uid}.{ext}")
def card_sticker(uid: str, ext: str, request: Request):
    """Kreditkartengroßer Aufkleber (Cover + Titel) als PNG oder PDF."""
    ext = ext.lower()
    if ext not in ("png", "pdf"):
        raise HTTPException(404, "Format")
    uid = uid.upper()
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    card = ms.get(uid)
    if not card:
        raise HTTPException(404, "Karte nicht gefunden")
    s = request.app.state.settings
    covers_dir = s.music_dir.parent / "covers"
    title, cover = sticker.cover_title_for_card(
        card, uid,
        sp_oauth=request.app.state.sp_oauth,
        music_dir=s.music_dir,
        covers_dir=covers_dir,
    )
    data = sticker.render(title, cover, ext, online=(card.get("type") == "spotify"))
    media = "application/pdf" if ext == "pdf" else "image/png"
    safe = "".join(ch for ch in (title or uid) if ch.isalnum() or ch in " -_")[:40].strip() or uid
    return Response(
        content=data,
        media_type=media,
        headers={"Content-Disposition": f'attachment; filename="sticker_{safe}.{ext}"'},
    )


@router.get("/cover/{uid}.jpg")
def card_cover(uid: str, request: Request):
    """Quadratisches Cover-Thumbnail (JPEG) fürs Karten-Grid, gecacht."""
    uid = uid.upper()
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    card = ms.get(uid)
    if not card:
        raise HTTPException(404, "Karte nicht gefunden")
    s = request.app.state.settings
    data = cover_mod.thumbnail_jpeg(
        card, uid,
        sp_oauth=request.app.state.sp_oauth,
        music_dir=s.music_dir,
        covers_dir=s.music_dir.parent / "covers",
        cache_dir=_cover_cache_dir(request),
    )
    return Response(content=data, media_type="image/jpeg",
                    headers={"Cache-Control": "no-cache"})


@router.get("/cover/lib/{lib_id}.jpg")
def library_cover(lib_id: str, request: Request):
    """Cover-Thumbnail für einen Bibliothekseintrag (noch keiner Karte zugewiesen)."""
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    entry = ms.library_get(lib_id)
    if not entry:
        raise HTTPException(404, "Bibliothekseintrag nicht gefunden")
    s = request.app.state.settings
    data = cover_mod.thumbnail_jpeg(
        entry, f"lib-{lib_id}",
        sp_oauth=request.app.state.sp_oauth,
        music_dir=s.music_dir,
        covers_dir=s.music_dir.parent / "covers",
        cache_dir=_cover_cache_dir(request),
    )
    return Response(content=data, media_type="image/jpeg",
                    headers={"Cache-Control": "no-cache"})


@router.get("/settings")
def get_settings(request: Request) -> dict:
    st = request.app.state.settings_store
    st.reload_if_changed()
    return st.data


@router.post("/settings")
async def save_settings(request: Request) -> dict:
    body = await request.json()
    st = request.app.state.settings_store
    data = st.update(body)
    # Core sofort neu laden lassen (sonst greift es erst beim periodischen Reload)
    await asyncio.to_thread(_ipc, request.app.state.settings, {"action": "reload_settings"})
    return {"ok": True, "settings": data}


@router.get("/mappings")
def list_mappings(request: Request) -> dict:
    mapping_store = request.app.state.mapping_store
    mapping_store.reload_if_changed()
    return {
        "defaults": mapping_store.defaults(),
        "cards": mapping_store.all_cards(),
    }


@router.post("/mappings")
async def create_mapping(request: Request) -> dict:
    body = await request.json()
    uid = body.get("uid", "").upper().replace(":", "").replace(" ", "")
    entry = body.get("entry", {})
    if not uid:
        raise HTTPException(400, "uid fehlt")
    try:
        request.app.state.mapping_store.set(uid, entry)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # Cover-Cache für diese UID verwerfen (Ref könnte sich geändert haben)
    cover_mod.invalidate(_cover_cache_dir(request), uid)
    # _ipc ist blockierendes Socket-I/O → nicht im Event-Loop ausführen
    await asyncio.to_thread(_ipc, request.app.state.settings, {"action": "reload_mapping"})
    return {"ok": True, "uid": uid}


@router.delete("/mappings/{uid}")
def delete_mapping(uid: str, request: Request) -> dict:
    uid = uid.upper()
    deleted = request.app.state.mapping_store.delete(uid)
    if not deleted:
        raise HTTPException(404, "UID nicht gefunden")
    cover_mod.invalidate(_cover_cache_dir(request), uid)
    _ipc(request.app.state.settings, {"action": "reload_mapping"})
    return {"ok": True}


@router.get("/library")
def list_library(request: Request) -> dict:
    mapping_store = request.app.state.mapping_store
    mapping_store.reload_if_changed()
    return {"entries": mapping_store.library_all()}


@router.post("/library")
async def create_library_entry(request: Request) -> dict:
    body = await request.json()
    entry = body.get("entry", {})
    try:
        lib_id = request.app.state.mapping_store.library_create(entry)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "id": lib_id}


@router.put("/library/{lib_id}")
async def update_library_entry(lib_id: str, request: Request) -> dict:
    body = await request.json()
    entry = body.get("entry", {})
    try:
        request.app.state.mapping_store.library_set(lib_id, entry)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


@router.delete("/library/{lib_id}")
def delete_library_entry(lib_id: str, request: Request) -> dict:
    deleted = request.app.state.mapping_store.library_delete(lib_id)
    if not deleted:
        raise HTTPException(404, "Bibliothekseintrag nicht gefunden")
    return {"ok": True}


@router.post("/library/{lib_id}/assign")
async def assign_library_entry(lib_id: str, request: Request) -> dict:
    body = await request.json()
    uid = body.get("uid", "").upper().replace(":", "").replace(" ", "")
    if not uid:
        raise HTTPException(400, "uid fehlt")
    try:
        request.app.state.mapping_store.assign_to_card(uid, lib_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    cover_mod.invalidate(_cover_cache_dir(request), uid)
    await asyncio.to_thread(_ipc, request.app.state.settings, {"action": "reload_mapping"})
    return {"ok": True, "uid": uid}


@router.post("/control/{action}")
async def control_action(action: str, request: Request) -> dict:
    settings = request.app.state.settings
    body: dict = {}
    try:
        body = await request.json()
    except Exception:
        pass
    cmd = {"action": action, **body}
    ok = await asyncio.to_thread(_ipc, settings, cmd)
    return {"ok": ok}


@router.get("/search")
async def spotify_search(q: str, request: Request, type: str = "album,playlist") -> Any:
    """Spotify-Suche via spotipy (synchron in Thread-Pool)."""
    import spotipy

    sp_oauth = request.app.state.sp_oauth
    try:
        sp = spotipy.Spotify(auth_manager=sp_oauth)
        results = await asyncio.to_thread(sp.search, q=q, type=type, limit=10)
        return results
    except Exception as e:
        raise HTTPException(503, f"Spotify-Suche fehlgeschlagen: {e}")


def _img(images: list) -> str:
    return images[0]["url"] if images else ""


@router.get("/spotify/library")
async def spotify_library(request: Request, type: str = "playlists",
                          limit: int = 20, offset: int = 0) -> Any:
    """Eigene Spotify-Bibliothek, normalisiert: {items:[{uri,name,by,image}], next}."""
    import spotipy

    sp_oauth = request.app.state.sp_oauth
    sp = spotipy.Spotify(auth_manager=sp_oauth)

    def _fetch():
        items, nxt = [], None
        if type == "playlists":
            res = sp.current_user_playlists(limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            for p in res.get("items", []):
                if p:
                    items.append({"uri": p.get("uri", ""), "name": p.get("name", ""),
                                  "by": (p.get("owner") or {}).get("display_name", ""),
                                  "image": _img(p.get("images", []))})
        elif type == "tracks":
            res = sp.current_user_saved_tracks(limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            for it in res.get("items", []):
                t = (it or {}).get("track") or {}
                items.append({"uri": t.get("uri", ""), "name": t.get("name", ""),
                              "by": ", ".join(a["name"] for a in t.get("artists", [])),
                              "image": _img((t.get("album") or {}).get("images", []))})
        elif type == "albums":
            res = sp.current_user_saved_albums(limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            for it in res.get("items", []):
                a = (it or {}).get("album") or {}
                items.append({"uri": a.get("uri", ""), "name": a.get("name", ""),
                              "by": ", ".join(ar["name"] for ar in a.get("artists", [])),
                              "image": _img(a.get("images", []))})
        elif type == "artists":
            res = sp.current_user_followed_artists(limit=limit)
            block = res.get("artists", {}) if isinstance(res, dict) else {}
            nxt = bool(block.get("next"))
            for ar in block.get("items", []):
                if ar:
                    items.append({"uri": ar.get("uri", ""), "name": ar.get("name", ""),
                                  "by": "", "image": _img(ar.get("images", []))})
        else:
            raise ValueError(f"Unbekannter type: {type}")
        return {"items": items, "next": nxt}

    try:
        return await asyncio.to_thread(_fetch)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        msg = str(e)
        if "403" in msg or "insufficient" in msg.lower() or "scope" in msg.lower():
            return JSONResponse({"items": [], "error": "reauth_required"})
        raise HTTPException(503, f"Spotify-Bibliothek nicht verfügbar: {e}")


@router.get("/spotify/playlist_tracks")
async def spotify_playlist_tracks(request: Request, uri: str,
                                   limit: int = 50, offset: int = 0) -> Any:
    """Tracks einer Spotify-Playlist/eines Albums, normalisiert wie /spotify/library:
    {items:[{uri,name,by,image}], next}. Für die Track-Ausschluss-UI in assign.html."""
    import spotipy

    sp_oauth = request.app.state.sp_oauth
    sp = spotipy.Spotify(auth_manager=sp_oauth)

    def _fetch():
        items, nxt = [], None
        if uri.startswith("spotify:playlist:"):
            playlist_id = uri.split(":")[-1]
            if not re.fullmatch(r"[A-Za-z0-9]{22}", playlist_id):
                raise ValueError("Ungültige Spotify-ID")
            res = sp.playlist_items(playlist_id, limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            for it in res.get("items", []):
                t = (it or {}).get("track") or {}
                if not t:
                    continue
                items.append({"uri": t.get("uri", ""), "name": t.get("name", ""),
                              "by": ", ".join(a["name"] for a in t.get("artists", [])),
                              "image": _img((t.get("album") or {}).get("images", []))})
        elif uri.startswith("spotify:album:"):
            album_id = uri.split(":")[-1]
            if not re.fullmatch(r"[A-Za-z0-9]{22}", album_id):
                raise ValueError("Ungültige Spotify-ID")
            res = sp.album_tracks(album_id, limit=limit, offset=offset)
            nxt = bool(res.get("next"))
            cover = _img(sp.album(album_id).get("images", []))
            for t in res.get("items", []):
                if not t:
                    continue
                items.append({"uri": t.get("uri", ""), "name": t.get("name", ""),
                              "by": ", ".join(a["name"] for a in t.get("artists", [])),
                              "image": cover})
        else:
            raise ValueError(f"Kein Playlist-/Album-URI: {uri}")
        return {"items": items, "next": nxt}

    try:
        return await asyncio.to_thread(_fetch)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        msg = str(e)
        if "403" in msg or "insufficient" in msg.lower() or "scope" in msg.lower():
            return JSONResponse({"items": [], "error": "reauth_required"})
        raise HTTPException(503, f"Spotify-Tracks nicht verfügbar: {e}")


@router.get("/spotify/me")
async def spotify_me(request: Request) -> Any:
    import spotipy

    sp_oauth = request.app.state.sp_oauth
    try:
        sp = spotipy.Spotify(auth_manager=sp_oauth)
        return await asyncio.to_thread(sp.me)
    except Exception as e:
        raise HTTPException(503, str(e))
