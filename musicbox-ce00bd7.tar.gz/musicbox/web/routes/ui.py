"""HTML-Seiten (Jinja2)."""

from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

router = APIRouter()


def _render(request: Request, template: str, **ctx):
    templates = request.app.state.templates
    # Starlette >=1.0: Signatur ist TemplateResponse(request, name, context)
    return templates.TemplateResponse(request, template, {"request": request, **ctx})


@router.get("/", response_class=HTMLResponse)
def index(request: Request, msg: str = ""):
    state = request.app.state.state_store.state
    return _render(request, "index.html", state=state, msg=msg)


@router.get("/assign", response_class=HTMLResponse)
def assign(request: Request, uid: str = "", lib: str = ""):
    edit_card = None
    uid = uid.upper()
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    if uid:
        edit_card = ms.get(uid)
    elif lib:
        edit_card = ms.library_get(lib)
    return _render(request, "assign.html", edit_uid=uid, edit_card=edit_card, edit_lib=lib)


@router.get("/mappings", response_class=HTMLResponse)
def mappings(request: Request):
    from musicbox.store.content import content_kind
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    cards = ms.all_cards()
    kinds = {uid: content_kind(c) for uid, c in cards.items()}
    library = ms.library_all()
    lib_kinds = {lib_id: content_kind(e) for lib_id, e in library.items()}
    return _render(request, "mappings.html", cards=cards, kinds=kinds,
                   library=library, lib_kinds=lib_kinds)


@router.get("/upload", response_class=HTMLResponse)
def upload_page(request: Request, success: int = 0, file: str = "", cat: str = ""):
    return _render(request, "upload.html", success=success, filename=file, cat=cat)


@router.get("/logs", response_class=HTMLResponse)
def logs(request: Request):
    return _render(request, "logs.html")


@router.get("/settings", response_class=HTMLResponse)
def settings_page(request: Request):
    st = request.app.state.settings_store
    st.reload_if_changed()
    s = request.app.state.settings
    return _render(
        request,
        "settings.html",
        cfg=st.data,
        gpio={"btn1": s.gpio_play_pause, "btn2": s.gpio_next, "btn3": s.gpio_prev,
              "btn4": s.gpio_enc_sw},
    )
