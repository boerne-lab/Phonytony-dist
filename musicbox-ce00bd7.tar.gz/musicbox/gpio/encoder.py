"""EncoderHandler: KY-040 Rotary Encoder → volume_delta Events."""

from __future__ import annotations

import asyncio
import logging

log = logging.getLogger(__name__)


class EncoderHandler:
    def __init__(
        self,
        queue: asyncio.Queue,
        loop: asyncio.AbstractEventLoop,
        pin_clk: int,
        pin_dt: int,
        pin_sw: int,
    ) -> None:
        self._queue = queue
        self._loop = loop
        self._pin_clk = pin_clk
        self._pin_dt = pin_dt
        self._pin_sw = pin_sw
        self._encoder = None
        self._sw_button = None
        self._sw_held = False
        self._hold_time = 5.0  # Sekunden bis "lang halten"

    def start(self) -> None:
        from gpiozero import Button, RotaryEncoder

        self._encoder = RotaryEncoder(self._pin_clk, self._pin_dt, max_steps=0)
        self._encoder.when_rotated_clockwise = lambda: self._emit_delta(+1)
        self._encoder.when_rotated_counter_clockwise = lambda: self._emit_delta(-1)

        # SW-Knopf = vierter konfigurierbarer Knopf "btn4" (kurz/lang), analog ButtonHandler.
        self._sw_button = Button(
            self._pin_sw, pull_up=True, bounce_time=0.05, hold_time=self._hold_time
        )
        self._sw_button.when_held = lambda: self._sw_press("long")
        self._sw_button.when_released = self._sw_release
        log.info("Encoder initialisiert (CLK=%d, DT=%d, SW=%d)", self._pin_clk, self._pin_dt, self._pin_sw)

    def _emit_delta(self, delta: int) -> None:
        self._loop.call_soon_threadsafe(
            self._queue.put_nowait, {"event": "volume_delta", "delta": delta}
        )

    def _sw_press(self, press: str) -> None:
        # "long" kommt von when_held; markiert, damit das folgende release kein "short" feuert
        self._sw_held = True
        self._emit_button("long")

    def _sw_release(self) -> None:
        if self._sw_held:
            self._sw_held = False  # war Lang-Druck → kein zusätzliches Kurz-Event
        else:
            self._emit_button("short")

    def _emit_button(self, press: str) -> None:
        self._loop.call_soon_threadsafe(
            self._queue.put_nowait,
            {"event": "button", "btn": "btn4", "press": press},
        )

    def stop(self) -> None:
        if self._encoder:
            self._encoder.close()
        if self._sw_button:
            self._sw_button.close()
