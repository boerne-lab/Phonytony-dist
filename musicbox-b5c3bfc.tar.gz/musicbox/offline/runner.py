"""Läufe des Offline-Abgleichs orchestrieren.

Ein Lauf teilt alle Karten und Bibliothekseinträge in zwei Klassen:

* **Offline** — schon auf eine lokale Playlist umgestellt. Für sie genügt eine
  Existenzprüfung der Dateien: kein Spotify-Abruf, kein Index, keine
  Metadaten. Fehlt etwas, fällt der Eintrag auf Spotify zurück.
* **Spotify** — Playlist, Album, Einzeltrack oder eigene Zusammenstellung.
  Für sie wird die Trackliste besorgt und gegen den Index gematcht.

Ist die Spotify-Klasse leer, wird der Index gar nicht erst aufgebaut. Je mehr
Karten offline sind, desto weniger Arbeit macht der Lauf.

Läuft im Web-Prozess: dort liegen Spotify-Zugang und Metadaten-Cache.
"""

from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import Optional

from musicbox.web import spotify_cache
from musicbox.web.spotify_items import track_of, tracks_by_ids

from . import index as ix
from . import intake
from . import librespot_api
from . import reconcile
from .matcher import match

log = logging.getLogger(__name__)

_CACHE_TTL_S = 24 * 3600
# Obergrenze für eine einzelne Trackliste. Ohne sie blockiert eine hängende
# Spotify-Abfrage den ganzen Lauf — und mit ihm die Sperre, sodass auch kein
# weiterer Abgleich mehr startet. Auf der Box hing ein Lauf über zehn Minuten,
# während das WLAN schwächelte.
_ABFRAGE_LIMIT_S = 45.0
# Spotify weist Album-Titellisten oberhalb von 50 pro Seite ab ("Invalid
# limit"); bei Playlists wären 100 erlaubt. Eine gemeinsame Grenze von 50 gilt
# für beide und erspart die Fallunterscheidung.
_PAGE = 50
_LOCK = asyncio.Lock()


async def run(app_state, *, trigger: str, recheck_offline: bool = False,
              category: Optional[str] = None, nur_key: Optional[str] = None) -> dict:
    """Einen Abgleich durchführen. Läuft schon einer, wird sofort abgewiesen —
    zwei gleichzeitige Läufe würden sich beim Schreiben in die Wege kommen.

    ``category`` gibt vor, wohin exportierte Dateien eingeräumt werden. Der
    Hol-Vorgang setzt sie auf das, was die Nutzerin gewählt hat; sonst folgt sie
    der Karte, zu der ein Titel gehört.

    ``nur_key`` beschränkt die Prüfung auf einen Eintrag. Nach dem Holen einer
    Karte ist das der ganze Bedarf — ein vollständiger Lauf holt die Titellisten
    aller Einträge und dauert Minuten, in denen die Sperre belegt bleibt und
    weitere Aufträge ins Leere laufen. Eingeräumt wird trotzdem alles, was im
    Download-Ordner liegt."""
    if _LOCK.locked():
        return _bericht(trigger, busy=True)

    async with _LOCK:
        return await _run(app_state, trigger=trigger, recheck_offline=recheck_offline,
                          category=category, nur_key=nur_key)


async def _run(app_state, *, trigger: str, recheck_offline: bool,
               category: Optional[str] = None, nur_key: Optional[str] = None) -> dict:
    beginn = time.monotonic()
    mapping = app_state.mapping_store
    mapping.reload_if_changed()

    stores = reconcile.Stores(mapping=mapping, playlists=app_state.playlist_store,
                              music_dir=Path(app_state.settings.music_dir))
    stores.playlists.load()

    offline, spotify = _klassen(mapping, recheck_offline=recheck_offline)
    if nur_key:
        offline = [e for e in offline if e[0] == nur_key]
        spotify = [e for e in spotify if e[0] == nur_key]
    bericht = _bericht(trigger)

    # 1) Offline-Einträge: nur nachsehen, ob die Dateien noch da sind.
    for key, entry, is_library in offline:
        if _dateien_vollstaendig(entry, stores):
            continue
        if reconcile.revert(key, entry, stores=stores, is_library=is_library) == "reverted":
            bericht["reverted"] += 1

    index_pfad = Path(app_state.settings.data_dir) / "offline_index.json"
    index = ix.load(index_pfad)

    if not spotify:
        # Auch ohne zu prüfenden Eintrag kann etwas einzuräumen sein — etwa,
        # wenn ein früherer Lauf an der Sperre abprallte.
        if category:
            bericht["taken"] = await _exporte_einraeumen(app_state, index, [], {},
                                                         vorgabe=category)
        bericht["duration_s"] = round(time.monotonic() - beginn, 2)
        _vermerken(index_pfad, index, bericht)
        return bericht

    # 2) Was own-librespot exportiert hat, in die Bibliothek einräumen — vor dem
    # Index-Aufbau, damit die Dateien im selben Lauf gefunden werden.
    #
    # Mit ausdrücklicher Kategorie braucht dieser Schritt keine Trackliste und
    # läuft deshalb zuerst: Auf der Box dauert das Holen aller Listen über ein
    # wackliges WLAN Minuten, in denen die Dateien sonst unnötig im
    # Download-Ordner lägen.
    tracklisten: dict = {}
    if category:
        bericht["taken"] = await _exporte_einraeumen(app_state, index, spotify, {},
                                                     vorgabe=category)

    # 3) Tracklisten holen — für das Matching, und ohne Vorgabe auch für die
    # Kategorie der einzuräumenden Dateien.
    for key, entry, _ in spotify:
        tracklisten[key] = await tracklist(app_state, entry)

    if not category:
        bericht["taken"] = await _exporte_einraeumen(app_state, index, spotify,
                                                     tracklisten, vorgabe=None)

    # 4) Erst jetzt lohnt der Index.
    neu_gelesen = await asyncio.to_thread(ix.rebuild, Path(app_state.settings.music_dir), index)
    if neu_gelesen:
        log.info("Offline-Index: %d Dateien neu eingelesen", neu_gelesen)

    for key, entry, is_library in spotify:
        bericht["checked"] += 1
        tracks = tracklisten.get(key)
        if tracks is None:
            # Weder Cache noch Netz: nichts wissen ist kein Grund, etwas zu ändern.
            bericht["skipped_no_data"] += 1
            continue
        ergebnis = match(tracks, index,
                         excluded_uris=set(entry.get("excluded_tracks") or []))
        offen = _offene_vorschlaege(ergebnis)
        bericht["suggestions"] += len(offen)
        # Vorschläge werden hier abgelegt statt bei jedem Abruf neu gerechnet:
        # ein Durchlauf über alle Karten kostet den Pi Zero mehrere Sekunden,
        # und die Weboberfläche fragt sie bei jedem Seitenaufruf ab.
        if offen:
            index.suggestions[key] = {"key": key, "label": entry.get("label") or key,
                                      "is_library": is_library, "tracks": offen}
        else:
            index.suggestions.pop(key, None)

        if ergebnis.complete:
            name = entry.get("label") or ""
            if reconcile.apply(key, entry, ergebnis, stores=stores,
                               is_library=is_library, spotify_name=name) == "converted":
                bericht["converted"] += 1
        elif entry.get("type") == "local" and entry.get("offline_of"):
            # Nur beim erneuten Prüfen: die Karte war offline, ist es aber nicht mehr.
            if reconcile.revert(key, entry, stores=stores,
                                is_library=is_library) == "reverted":
                bericht["reverted"] += 1

    bekannt = {key for key, _, _ in spotify}
    for key in [k for k in index.suggestions if k not in bekannt]:
        del index.suggestions[key]

    bericht["duration_s"] = round(time.monotonic() - beginn, 2)
    _vermerken(index_pfad, index, bericht)
    return bericht


async def _exporte_einraeumen(app_state, index, spotify_eintraege, tracklisten,
                              *, vorgabe: Optional[str] = None) -> int:
    """Exportierte Dateien aus dem Download-Ordner in die Bibliothek holen.

    Die Zuordnung Track → Datei kommt dabei aus dem Index des Forks und ist
    damit gesichert; für diese Dateien muss der Matcher nichts raten.

    Ist der Fork nicht erreichbar oder kennt die Route nicht, passiert nichts —
    der Lauf verhält sich dann wie zuvor.
    """
    auskunft = await librespot_api.downloads(getattr(app_state.settings, "librespot_url", "")
                                             or "http://127.0.0.1:3678")
    if not auskunft or not auskunft.get("tracks"):
        return 0

    export_dir = Path(auskunft["dir"] or "")
    music_dir = Path(app_state.settings.music_dir)
    # Eine ausdrücklich gewählte Kategorie schlägt die aus der Karte abgeleitete:
    # Beim Hol-Vorgang hat die Nutzerin gerade eben gesagt, wohin es soll.
    kategorien = ({} if vorgabe
                  else _kategorien_je_track(app_state, spotify_eintraege, tracklisten))
    eingeraeumt = 0

    for uri, eintrag in auskunft["tracks"].items():
        if index.confirmed.get(uri):
            continue                      # schon eingeräumt
        quelle = export_dir / eintrag["path"]
        if not quelle.is_file():
            # Der Index des Forks behält seinen Eintrag, auch wenn die Datei
            # längst hier liegt. Das ist der Normalfall, kein Fehler.
            continue
        rel = await asyncio.to_thread(
            intake.take, quelle, uri,
            music_dir=music_dir, category=kategorien.get(uri, "musik"),
            index=index, meta=intake.meta_aus_pfad(eintrag["path"]))
        if rel:
            eingeraeumt += 1

    if eingeraeumt:
        log.info("%d exportierte Datei(en) in die Bibliothek eingeräumt", eingeraeumt)
    return eingeraeumt


def _kategorien_je_track(app_state, spotify_eintraege, tracklisten) -> dict:
    """Welche Kategorie gilt für welchen Track? Sie folgt der Karte, zu der er
    gehört — eine Hörbuchkarte bringt ihre Titel nach hoerbuch/.

    Karten ohne bestehende Playlist liefern keine Kategorie; für ihre Titel
    bleibt es beim Standard musik/."""
    kategorien: dict[str, str] = {}
    for key, entry, _ in spotify_eintraege:
        playlist_id = entry.get("offline_playlist_id")
        if not playlist_id:
            continue
        playlist = app_state.playlist_store.get(playlist_id)
        if not playlist or playlist.get("category") not in ("musik", "hoerbuch"):
            continue
        for track in tracklisten.get(key) or []:
            uri = track.get("uri")
            if uri:
                kategorien[uri] = playlist["category"]
    return kategorien


def _klassen(mapping, *, recheck_offline: bool):
    """Alle Einträge in (offline, spotify) aufteilen. Künstler-Karten fallen
    heraus — 'alle Lieder eines Künstlers' hat keine abschließbare Liste."""
    offline: list = []
    spotify: list = []

    alle = [(k, e, False) for k, e in mapping.all_cards().items()]
    alle += [(k, e, True) for k, e in mapping.library_all().items()]

    for key, entry, is_library in alle:
        typ = entry.get("type")
        if typ == "local" and entry.get("offline_of"):
            (spotify if recheck_offline else offline).append((key, entry, is_library))
        elif typ == "spotify_queue":
            spotify.append((key, entry, is_library))
        elif typ == "spotify" and _abgleichbar(entry.get("ref", "")):
            spotify.append((key, entry, is_library))
    return offline, spotify


def _abgleichbar(ref: str) -> bool:
    return any(teil in ref for teil in (":playlist:", ":album:", ":track:"))


def _dateien_vollstaendig(entry: dict, stores) -> bool:
    """Existieren alle Dateien, auf die der Eintrag zeigt?"""
    for pfad in _dateien(entry, stores):
        if not pfad.exists():
            log.info("Offline-Karte vermisst %s", pfad)
            return False
    return True


def _dateien(entry: dict, stores) -> list:
    ref = entry.get("ref", "")
    if ref.endswith(".m3u8"):
        try:
            zeilen = Path(ref).read_text().splitlines()
        except OSError:
            return [Path(ref)]
        return [Path(z) for z in zeilen if z.strip()]
    if not ref:
        return []
    pfad = Path(ref)
    return [pfad if pfad.is_absolute() else stores.music_dir / ref]


async def tracklist(app_state, entry: dict, *, nocache: bool = False):
    """Die vollständige Trackliste eines Eintrags — aus dem Cache, sonst von
    Spotify, sonst None. Jeder Track: {uri, name, by, duration_ms}."""
    typ = entry.get("type")
    ref = entry.get("offline_of") or entry.get("ref", "")

    if typ == "spotify_queue" or ref.startswith("spotify_queue:"):
        uris = list(entry.get("offline_queue_tracks") or entry.get("tracks") or [])
        if not uris:
            return None
        return await _mit_limit(_cached(app_state, {"uris": uris}, nocache,
                                        lambda sp: _tracks_nach_uris(sp, uris)))

    if ":playlist:" in ref or ":album:" in ref or ":track:" in ref:
        return await _mit_limit(_cached(app_state, {"uri": ref}, nocache,
                                        lambda sp: _tracks_nach_ref(sp, ref)))
    return None


async def _mit_limit(aufgabe):
    """Bricht eine Trackliste ab, die zu lange braucht — ohne Daten weiterzugehen
    ist besser, als den Lauf und die Sperre zu blockieren."""
    try:
        return await asyncio.wait_for(aufgabe, timeout=_ABFRAGE_LIMIT_S)
    except asyncio.TimeoutError:
        log.warning("Trackliste kam nicht innerhalb von %.0f s — übersprungen",
                    _ABFRAGE_LIMIT_S)
        return None


async def _cached(app_state, params: dict, nocache: bool, fetch):
    cache_dir = Path(app_state.settings.data_dir) / "spotify_cache"
    key = spotify_cache.key_for("offline_tracklist", params)

    if not nocache:
        treffer = spotify_cache.read(cache_dir, key, max_age_s=_CACHE_TTL_S)
        if treffer is not None:
            return treffer

    try:
        sp = _spotify_client(app_state)
        daten = await asyncio.to_thread(fetch, sp)
    except Exception as e:
        veraltet = spotify_cache.read_stale(cache_dir, key)
        if veraltet is not None:
            log.info("Spotify nicht erreichbar (%s) — nutze veralteten Stand", e)
            return veraltet
        log.info("Keine Trackliste für %s verfügbar: %s", params, e)
        return None

    spotify_cache.write(cache_dir, key, daten)
    return daten


def _spotify_client(app_state):
    """Eigene Funktion, damit Tests den Client ersetzen können.

    Mit Zeitlimit: Die Standardeinstellung von spotipy wartet unbegrenzt, was
    auf einer Box mit wackligem WLAN den ganzen Lauf anhält.
    """
    import spotipy
    return spotipy.Spotify(auth_manager=app_state.sp_oauth,
                           requests_timeout=15, retries=2)


def _tracks_nach_ref(sp, ref: str) -> list:
    kennung = ref.split(":")[-1]
    if ":playlist:" in ref:
        return _blaettern(lambda offset: sp.playlist_items(kennung, limit=_PAGE, offset=offset),
                          entpacken=track_of)
    if ":album:" in ref:
        return _blaettern(lambda offset: sp.album_tracks(kennung, limit=_PAGE, offset=offset))
    return [_normalisieren(sp.track(kennung))]


def _tracks_nach_uris(sp, uris: list) -> list:
    """Spotify nimmt höchstens 50 Kennungen pro Abfrage entgegen.

    tracks_by_ids() weicht auf Einzelabrufe aus, wenn Spotify den Sammel-
    Endpunkt sperrt — siehe musicbox/web/spotify_items.py.
    """
    ergebnis = []
    for start in range(0, len(uris), 50):
        teil = [u.split(":")[-1] for u in uris[start:start + 50]]
        ergebnis += [_normalisieren(t) for t in tracks_by_ids(sp, teil)]
    return ergebnis


def _blaettern(seite_holen, entpacken=None) -> list:
    tracks: list = []
    offset = 0
    while True:
        antwort = seite_holen(offset) or {}
        eintraege = antwort.get("items") or []
        for eintrag in eintraege:
            roh = entpacken(eintrag) if entpacken else eintrag
            if roh:
                tracks.append(_normalisieren(roh))
        if not antwort.get("next") or not eintraege:
            return tracks
        offset += _PAGE


def _normalisieren(track: dict) -> dict:
    return {
        "uri": track.get("uri", ""),
        "name": track.get("name", ""),
        "by": ", ".join(a.get("name", "") for a in track.get("artists", [])),
        "duration_ms": track.get("duration_ms"),
    }


def _offene_vorschlaege(ergebnis) -> list:
    return [{"uri": t.uri, "name": t.name, "by": t.by,
             "candidates": list(t.candidates), "score": round(t.score, 2)}
            for t in ergebnis.tracks if t.status == "unsure"]


def _bericht(trigger: str, *, busy: bool = False) -> dict:
    return {"trigger": trigger, "busy": busy, "checked": 0, "converted": 0,
            "reverted": 0, "suggestions": 0, "skipped_no_data": 0, "taken": 0,
            "duration_s": 0.0}


def _vermerken(pfad: Path, index, bericht: dict) -> None:
    index.last_run = {"at": time.time(), **{k: v for k, v in bericht.items() if k != "busy"}}
    ix.save(pfad, index)
