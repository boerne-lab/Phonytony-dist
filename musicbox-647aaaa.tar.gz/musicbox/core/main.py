"""Haupt-Einstiegspunkt für musicbox-core."""

from __future__ import annotations

import asyncio
import logging
import signal

from musicbox.audio.feedback import FeedbackPlayer
from musicbox.audio.volume import AlsaVolume
from musicbox.backends.local import LocalBackend
from musicbox.backends.spotify import SpotifyBackend
from musicbox.core.controller import MusicBoxController
from musicbox.core.ipc_server import IPCServer
from musicbox.rfid.reader import RC522Reader
from musicbox.settings import load_settings
from musicbox.store.mapping import MappingStore
from musicbox.store.settings_store import SettingsStore
from musicbox.store.state import StateStore

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
)
log = logging.getLogger(__name__)


async def _periodic_reload(mapping_store, settings_store, interval: int = 5) -> None:
    while True:
        await asyncio.sleep(interval)
        mapping_store.reload_if_changed()
        settings_store.reload_if_changed()


async def _amain() -> None:
    settings = load_settings()

    mapping_store = MappingStore(settings.mapping_file)
    mapping_store.load()

    state_store = StateStore(settings.state_file)
    state_existed = settings.state_file.exists()
    state = state_store.load()
    if not state_existed:
        # Erstinbetriebnahme: konfigurierten Default-Volume statt Hardcoded-75 übernehmen
        state.volume = settings.volume_default

    settings_store = SettingsStore(settings.settings_file)
    settings_store.load()

    alsa_volume = AlsaVolume(settings.alsa_card, settings.alsa_controls)
    alsa_volume.initialize(state.volume)
    # Pro-Ausgang-Deckel + Ausgangsmodus aus den Einstellungen/State anwenden
    # (Startpegel respektiert die globale Mindestlautstärke)
    _min_vol = int(settings_store.data.get("min_volume", 0))
    _start_vol = max(state.volume, _min_vol)
    alsa_volume.apply(_start_vol, settings_store.data.get("max_volume", {}), state.output_mode)
    state_store.set_volume(_start_vol)

    feedback = FeedbackPlayer(settings.feedback_dir, settings.alsa_card)
    spotify_backend = SpotifyBackend(settings.librespot_url)
    local_backend = LocalBackend(
        socket_path=settings.mpv_socket,
        alsa_card=settings.alsa_card,
        music_dir=settings.music_dir,
        playlists_dir=settings.playlists_dir,
    )

    event_queue: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_running_loop()

    rfid_reader = RC522Reader()
    try:
        rfid_reader.start()
    except Exception:
        log.warning("RC522 nicht verfügbar — RFID deaktiviert")
        rfid_reader = None

    controller = MusicBoxController(
        mapping_store=mapping_store,
        state_store=state_store,
        spotify_backend=spotify_backend,
        local_backend=local_backend,
        alsa_volume=alsa_volume,
        feedback=feedback,
        settings_store=settings_store,
        enc_volume_step=settings.enc_volume_step,
    )

    # GPIO (nur wenn auf echtem Pi verfügbar)
    button_handler = None
    encoder_handler = None
    try:
        from musicbox.gpio.buttons import ButtonHandler
        from musicbox.gpio.encoder import EncoderHandler

        button_handler = ButtonHandler(
            queue=event_queue,
            loop=loop,
            pin_play_pause=settings.gpio_play_pause,
            pin_next=settings.gpio_next,
            pin_prev=settings.gpio_prev,
            bounce_ms=settings.btn_bounce_ms,
        )
        button_handler.start()

        encoder_handler = EncoderHandler(
            queue=event_queue,
            loop=loop,
            pin_clk=settings.gpio_enc_clk,
            pin_dt=settings.gpio_enc_dt,
            pin_sw=settings.gpio_enc_sw,
        )
        encoder_handler.start()
    except Exception:
        log.warning("GPIO nicht verfügbar — Buttons/Encoder deaktiviert")

    ipc_server = IPCServer(settings.control_socket, event_queue)

    # SSE-Listener für Spotify-Statusänderungen
    async def on_spotify_event(event: dict) -> None:
        kind = event.get("type")
        if kind == "stopped" and controller._current_backend is spotify_backend:
            controller._current_backend = None
            controller._current_uid = None
            # State persistieren, sonst bleibt stale active_uid/active_backend in state.json
            st = state_store.state
            st.active_uid = None
            st.active_backend = None
            state_store.save(st)

    spotify_backend.start_sse_listener(on_spotify_event)

    # Shutdown-Handler
    stop_event = asyncio.Event()

    def _on_signal():
        log.info("Signal empfangen, beende ...")
        stop_event.set()

    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _on_signal)

    await feedback.play("startup")
    log.info("MusicBox Core gestartet")

    tasks = [
        asyncio.create_task(controller.run(event_queue), name="controller"),
        asyncio.create_task(ipc_server.serve(), name="ipc-server"),
        asyncio.create_task(_periodic_reload(mapping_store, settings_store), name="reload"),
    ]
    if rfid_reader:
        tasks.append(asyncio.create_task(
            rfid_reader.poll_forever(event_queue), name="rfid-reader"
        ))

    await stop_event.wait()

    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)

    if button_handler:
        button_handler.stop()
    if encoder_handler:
        encoder_handler.stop()
    await spotify_backend.close()
    log.info("MusicBox Core beendet")


def run() -> None:
    asyncio.run(_amain())


if __name__ == "__main__":
    run()
