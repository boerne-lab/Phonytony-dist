"""IPCServer: asyncio Unix-Socket für Web-UI ↔ Core-Kommunikation."""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)

_ALLOWED_ACTIONS = {
    "play", "pause", "next", "prev",
    "set_volume", "load_uid", "reload_mapping", "reload_settings",
}


class IPCServer:
    def __init__(self, socket_path: str, queue: asyncio.Queue) -> None:
        self._path = socket_path
        self._queue = queue
        self._server = None

    async def serve(self) -> None:
        sock = Path(self._path)
        sock.parent.mkdir(parents=True, exist_ok=True)
        if sock.exists():
            sock.unlink()
        self._server = await asyncio.start_unix_server(
            self._handle_client, path=str(sock)
        )
        os.chmod(str(sock), 0o660)
        log.info("IPC-Socket: %s", self._path)
        async with self._server:
            await self._server.serve_forever()

    async def _handle_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        try:
            data = await asyncio.wait_for(reader.readline(), timeout=2.0)
            cmd = json.loads(data)
            action = cmd.get("action", "")
            if action not in _ALLOWED_ACTIONS:
                writer.write(json.dumps({"ok": False, "error": "unknown action"}).encode() + b"\n")
            else:
                await self._queue.put({"event": "ipc_cmd", "cmd": cmd})
                writer.write(json.dumps({"ok": True}).encode() + b"\n")
            await writer.drain()
        except Exception as e:
            log.debug("IPC-Client-Fehler: %s", e)
        finally:
            writer.close()
