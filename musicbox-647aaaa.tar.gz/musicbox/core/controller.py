"""MusicBoxController: zentrale State Machine."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional

from musicbox.audio.feedback import FeedbackPlayer
from musicbox.audio.volume import AlsaVolume
from musicbox.backends.base import AudioBackend
from musicbox.connectivity.network import is_online
from musicbox.store.mapping import MappingStore
from musicbox.store.settings_store import SettingsStore
from musicbox.store.state import State, StateStore

log = logging.getLogger(__name__)

_OUTPUT_CYCLE = ["both", "speaker", "headphone"]

# Equalizer-Presets als mpv-Audiofilter (ffmpeg-Biquads → günstig). Gilt für lokale
# Wiedergabe (mpv); Standard "off" = kein Filter.
EQ_PRESETS = {
    "off":      "",
    "bass":     "lavfi=[bass=g=6]",
    "speech":   "lavfi=[bass=g=-3,equalizer=f=2800:t=q:w=1.2:g=4]",
    "treble":   "lavfi=[treble=g=5]",
    "loudness": "lavfi=[bass=g=5,treble=g=4]",
}


class MusicBoxController:
    def __init__(
        self,
        mapping_store: MappingStore,
        state_store: StateStore,
        spotify_backend: AudioBackend,
        local_backend: AudioBackend,
        alsa_volume: AlsaVolume,
        feedback: FeedbackPlayer,
        settings_store: SettingsStore,
        enc_volume_step: int = 5,
    ) -> None:
        self._mapping = mapping_store
        self._state_store = state_store
        self._settings = settings_store
        self._spotify = spotify_backend
        self._local = local_backend
        self._volume = alsa_volume
        self._feedback = feedback
        self._vol_step = enc_volume_step

        self._current_uid: Optional[str] = None
        self._current_backend: Optional[AudioBackend] = None

    async def run(self, queue: asyncio.Queue) -> None:
        while True:
            event = await queue.get()
            try:
                await self._handle(event)
            except Exception:
                log.exception("Fehler bei Event %s", event)
            finally:
                queue.task_done()

    async def _handle(self, event: dict) -> None:
        match event.get("event"):
            case "tag_placed":
                await self._on_tag_placed(event["uid"])
            case "tag_removed":
                await self._on_tag_removed(event["uid"])
            case "button":
                await self._on_button(event.get("btn", ""), event.get("press", "short"))
            case "btn_play_pause":   # Alt-Events (Rückwärtskompatibilität)
                await self._on_play_pause()
            case "btn_next":
                await self._on_next()
            case "btn_prev":
                await self._on_prev()
            case "volume_delta":
                await self._on_volume_delta(event["delta"])
            case "encoder_press":
                await self._on_play_pause()
            case "ipc_cmd":
                await self._on_ipc(event["cmd"])
            case _:
                log.debug("Unbekanntes Event: %s", event.get("event"))

    # ── Knopf-Aktionen ──────────────────────────────────────────────────────
    async def _on_button(self, btn: str, press: str) -> None:
        cfg = self._settings.data.get("buttons", {}).get(btn, {})
        await self._do_action(cfg.get(press, "none"))

    async def _do_action(self, action: str) -> None:
        match action:
            case "play_pause":    await self._on_play_pause()
            case "next":          await self._on_next()
            case "prev":          await self._on_prev()
            case "vol_up":        await self._on_volume_delta(+1)
            case "vol_down":      await self._on_volume_delta(-1)
            case "toggle_output": await self._on_toggle_output()
            case _:               pass  # "none" / unbekannt → nichts tun

    # ── Lautstärke / Ausgänge ───────────────────────────────────────────────
    def _caps_mode(self) -> tuple[dict, str]:
        caps = self._settings.data.get("max_volume", {})
        mode = self._state_store.state.output_mode
        return caps, mode

    async def _apply_volume(self, level: int) -> int:
        """Setzt den Pegel mit Pro-Ausgang-Deckel + Ausgangsmodus (amixer im Thread)."""
        caps, mode = self._caps_mode()
        new = await asyncio.to_thread(self._volume.apply, level, caps, mode)
        self._state_store.set_volume(new)
        return new

    async def _apply_eq(self) -> None:
        """Equalizer-Preset auf das Local-Backend (mpv) anwenden (Default: aus)."""
        af = EQ_PRESETS.get(self._settings.data.get("eq_preset", "off"), "")
        try:
            await self._local.set_eq(af)
        except Exception:
            pass

    async def _on_toggle_output(self) -> None:
        cur = self._state_store.state.output_mode
        nxt = (_OUTPUT_CYCLE[(_OUTPUT_CYCLE.index(cur) + 1) % len(_OUTPUT_CYCLE)]
               if cur in _OUTPUT_CYCLE else "both")
        st = self._state_store.state
        st.output_mode = nxt
        self._state_store.save()
        caps, _ = self._caps_mode()
        await asyncio.to_thread(self._volume.apply, self._volume.get(), caps, nxt)
        log.info("Audio-Ausgang umgeschaltet: %s", nxt)
        await self._feedback.play("tag_ok")

    async def _on_tag_placed(self, uid: str) -> None:
        self._mapping.reload_if_changed()
        # Jeden Scan festhalten (auch unbekannte Tags), damit das Web neue Karten
        # zuordnen kann. last_scanned_at zählt bei JEDEM Auflegen hoch (auch gleiche
        # Karte) → das Web kann einen frischen Scan zuverlässig erkennen.
        st = self._state_store.state
        st.last_scanned_uid = uid
        st.last_scanned_at = time.time()
        st.present_uid = uid  # Karte liegt jetzt auf (fürs Web-Onboarding)
        self._state_store.save()
        card = self._mapping.get(uid)
        if not card:
            log.info("Unbekannter Tag: %s", uid)
            await self._feedback.play("tag_unknown")
            return

        await self._feedback.play("tag_ok")
        log.info("Karte erkannt: %s → %s", uid, card.get("label", card["ref"]))

        if card["type"] == "spotify":
            if not await is_online():
                log.warning("Kein Netz für Spotify-Karte %s", uid)
                await self._feedback.play("offline")
                return
            backend = self._spotify
        else:
            backend = self._local

        state = self._state_store.state
        resume_pos = self._state_store.get_resume(uid) if card.get("resume") else 0

        # Lautstärke ggf. auf das Karten-Maximum begrenzen (mit Pro-Ausgang-Deckel)
        max_vol = card.get("max_volume", 100)
        if self._volume.get() > max_vol:
            await self._apply_volume(max_vol)

        # Beim Backend-Wechsel die vorherige Wiedergabe stoppen — sonst spielen
        # Spotify (go-librespot) und Local (mpv) dank dmix gleichzeitig weiter.
        if self._current_backend is not None and self._current_backend is not backend:
            try:
                await self._current_backend.pause()
            except Exception:
                pass

        await backend.load(card["ref"], card)
        if backend is self._local:
            await self._apply_eq()

        if resume_pos > 0:
            await asyncio.sleep(1.5)
            await backend.seek(resume_pos)

        self._current_uid = uid
        self._current_backend = backend
        state.active_uid = uid
        state.active_backend = card["type"]
        self._state_store.save(state)

    async def _on_tag_removed(self, uid: str) -> None:
        # Verhalten konfigurierbar: standardmäßig weiterspielen, optional pausieren.
        action = self._settings.data.get("card_removed", "continue")
        state = self._state_store.state
        state.present_uid = None  # Karte ist nicht mehr auf dem Sensor

        if action == "pause" and self._current_backend and uid == self._current_uid:
            status = await self._current_backend.get_status()
            pos = status.get("position_ms", 0)
            if pos > 5000:  # nur speichern wenn > 5s gespielt
                card = self._mapping.get(uid)
                if card and card.get("resume"):
                    self._state_store.update_resume(uid, pos)
            await self._current_backend.pause()
            self._current_uid = None
            self._current_backend = None
            state.active_uid = None
            state.active_backend = None
        # action == "continue": Wiedergabe + active_* bleiben erhalten (nur Karte ist weg)

        self._state_store.save(state)

    async def _active_backend(self):
        """Aktives Backend: Karten-Wiedergabe, sonst eine laufende Spotify-Connect-Session.
        So wirken Play/Pause/Next/Prev auch, wenn die Wiedergabe übers Handy gestartet wurde."""
        if self._current_backend is not None:
            return self._current_backend
        try:
            s = await self._spotify.get_status()
            if s.get("track_name") or s.get("playing"):
                self._current_backend = self._spotify
                return self._spotify
        except Exception:
            pass
        return None

    async def _on_play_pause(self) -> None:
        backend = await self._active_backend()
        if backend is None:
            return
        status = await backend.get_status()
        if status.get("playing"):
            await backend.pause()
        else:
            await backend.play()

    async def _on_next(self) -> None:
        backend = await self._active_backend()
        if backend:
            await backend.next_track()

    async def _on_prev(self) -> None:
        backend = await self._active_backend()
        if backend:
            await backend.prev_track()

    async def _on_volume_delta(self, delta: int) -> None:
        min_vol = int(self._settings.data.get("min_volume", 0))
        level = max(min_vol, min(100, self._volume.get() + delta * self._vol_step))
        new_vol = await self._apply_volume(level)
        if new_vol >= 100:
            await self._feedback.play("volume_max")
        elif new_vol <= min_vol:
            await self._feedback.play("volume_min")

    async def _on_ipc(self, cmd: dict) -> None:
        action = cmd.get("action")
        match action:
            case "play":
                await self._on_play_pause()
            case "pause":
                backend = await self._active_backend()
                if backend:
                    await backend.pause()
            case "next":
                await self._on_next()
            case "prev":
                await self._on_prev()
            case "set_volume":
                await self._apply_volume(int(cmd.get("value", 75)))
            case "load_uid":
                uid = cmd.get("uid", "")
                if uid:
                    await self._on_tag_placed(uid)
            case "reload_mapping":
                self._mapping.load()
                log.info("Mapping neu geladen")
            case "reload_settings":
                self._settings.load()
                min_vol = int(self._settings.data.get("min_volume", 0))
                caps, mode = self._caps_mode()
                target = max(self._volume.get(), min_vol)
                await asyncio.to_thread(self._volume.apply, target, caps, mode)
                self._state_store.set_volume(target)
                if self._current_backend is self._local:
                    await self._apply_eq()
                log.info("Einstellungen neu geladen")
