"""EncoderHandler: KY-040 Rotary Encoder → volume_delta Events."""

from __future__ import annotations

import asyncio
import logging

log = logging.getLogger(__name__)


class EncoderHandler:
    def __init__(
        self,
        queue: asyncio.Queue,
        loop: asyncio.AbstractEventLoop,
        pin_clk: int,
        pin_dt: int,
        pin_sw: int,
    ) -> None:
        self._queue = queue
        self._loop = loop
        self._pin_clk = pin_clk
        self._pin_dt = pin_dt
        self._pin_sw = pin_sw
        self._encoder = None
        self._sw_button = None

    def start(self) -> None:
        from gpiozero import Button, RotaryEncoder

        self._encoder = RotaryEncoder(self._pin_clk, self._pin_dt, max_steps=0)
        self._encoder.when_rotated_clockwise = lambda: self._emit_delta(+1)
        self._encoder.when_rotated_counter_clockwise = lambda: self._emit_delta(-1)

        self._sw_button = Button(self._pin_sw, pull_up=True, bounce_time=0.05)
        self._sw_button.when_pressed = lambda: self._loop.call_soon_threadsafe(
            self._queue.put_nowait, {"event": "encoder_press"}
        )
        log.info("Encoder initialisiert (CLK=%d, DT=%d, SW=%d)", self._pin_clk, self._pin_dt, self._pin_sw)

    def _emit_delta(self, delta: int) -> None:
        self._loop.call_soon_threadsafe(
            self._queue.put_nowait, {"event": "volume_delta", "delta": delta}
        )

    def stop(self) -> None:
        if self._encoder:
            self._encoder.close()
        if self._sw_button:
            self._sw_button.close()
