"""ButtonHandler: gpiozero Buttons → asyncio.Queue Events.

Jeder der drei Knöpfe sendet ein generisches Event
  {"event": "button", "btn": "btn1|btn2|btn3", "press": "short|long"}
Der Controller bildet btn+press über die Einstellungen auf eine Aktion ab.
Kurz = Tippen, Lang = halten für >= hold_time (Standard 5 s).
"""

from __future__ import annotations

import asyncio
import logging

log = logging.getLogger(__name__)

_HOLD_TIME = 5.0  # Sekunden bis "lang halten" auslöst


class ButtonHandler:
    def __init__(
        self,
        queue: asyncio.Queue,
        loop: asyncio.AbstractEventLoop,
        pin_play_pause: int,
        pin_next: int,
        pin_prev: int,
        bounce_ms: int = 50,
        hold_time: float = _HOLD_TIME,
    ) -> None:
        self._queue = queue
        self._loop = loop
        # btn1/btn2/btn3 = die drei physischen Knöpfe (in dieser Reihenfolge konfigurierbar)
        self._pins = {
            "btn1": pin_play_pause,
            "btn2": pin_next,
            "btn3": pin_prev,
        }
        self._bounce = bounce_ms / 1000
        self._hold_time = hold_time
        self._buttons: list = []
        self._held: dict[str, bool] = {}

    def start(self) -> None:
        from gpiozero import Button

        for btn_id, pin in self._pins.items():
            btn = Button(
                pin, pull_up=True, bounce_time=self._bounce, hold_time=self._hold_time
            )
            self._held[btn_id] = False
            bid = btn_id  # closure capture
            btn.when_held = lambda b=bid: self._on_held(b)
            btn.when_released = lambda b=bid: self._on_released(b)
            self._buttons.append(btn)
        log.info(
            "Buttons initialisiert: %s (lang halten = %.0fs)",
            list(self._pins.keys()),
            self._hold_time,
        )

    def _on_held(self, btn_id: str) -> None:
        self._held[btn_id] = True
        self._emit(btn_id, "long")

    def _on_released(self, btn_id: str) -> None:
        if self._held.get(btn_id):
            self._held[btn_id] = False  # war ein Lang-Druck → kein zusätzliches Kurz-Event
        else:
            self._emit(btn_id, "short")

    def _emit(self, btn_id: str, press: str) -> None:
        self._loop.call_soon_threadsafe(
            self._queue.put_nowait, {"event": "button", "btn": btn_id, "press": press}
        )

    def stop(self) -> None:
        for btn in self._buttons:
            btn.close()
        self._buttons.clear()
