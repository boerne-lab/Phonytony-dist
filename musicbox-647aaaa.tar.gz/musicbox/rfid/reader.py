"""RC522Reader: liest RFID-UIDs über SPI via spidev (kein adafruit/RPi.GPIO nötig).

python3-spidev wird per apt installiert und ist über --system-site-packages
im venv verfügbar. RST-Pin kann dauerhaft auf 3,3V gelegt werden.

Verdrahtung (SPI0):
  RC522 VCC  → Pin 1  (3,3V) – NICHT 5V!
  RC522 GND  → Pin 9  (GND)
  RC522 RST  → 3,3V (dauerhaft HIGH) oder Pin 7 (GPIO 4)
  RC522 SDA  → Pin 24 (GPIO 8, SPI0_CE0)
  RC522 SCK  → Pin 23 (GPIO 11, SPI0_SCLK)
  RC522 MOSI → Pin 19 (GPIO 10, SPI0_MOSI)
  RC522 MISO → Pin 21 (GPIO 9, SPI0_MISO)
  RC522 IRQ  → nicht belegen
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional

log = logging.getLogger(__name__)

_POLL_INTERVAL = 0.2  # Sekunden

# PCD-Befehle
_PCD_IDLE       = 0x00
_PCD_CALC_CRC   = 0x03
_PCD_TRANSCEIVE = 0x0C
_PCD_RESET      = 0x0F

# PICC-Kommandos
_PICC_REQA  = 0x26
_PICC_WUPA  = 0x52  # Wake-Up: weckt Karten aus IDLE UND HALT (REQA weckt HALT nicht)
_PICC_HLTA  = 0x50  # Halt: versetzt Karte nach dem Lesen in HALT
_PICC_CT    = 0x88  # Cascade Tag (7-Byte-UID)

# SPI-Register des MFRC522
_R_COMMAND      = 0x01
_R_COMM_IRQ     = 0x04
_R_DIV_IRQ      = 0x05
_R_ERROR        = 0x06
_R_FIFO_DATA    = 0x09
_R_FIFO_LEVEL   = 0x0A
_R_BIT_FRAMING  = 0x0D
_R_MODE         = 0x11
_R_TX_CONTROL   = 0x14
_R_TX_ASK       = 0x15
_R_CRC_RESULT_H = 0x21
_R_CRC_RESULT_L = 0x22
_R_T_MODE       = 0x2A
_R_T_PRESCALER  = 0x2B
_R_T_RELOAD_H   = 0x2C
_R_T_RELOAD_L   = 0x2D


class _RC522:
    """Minimaler MFRC522-Treiber: Init, REQA, Antikollision Kaskade 1+2."""

    def __init__(self, bus: int = 0, device: int = 0) -> None:
        import spidev
        self._spi = spidev.SpiDev()
        self._spi.open(bus, device)
        self._spi.max_speed_hz = 1_000_000
        self._spi.mode = 0
        self._init()

    def close(self) -> None:
        self._spi.close()

    def _w(self, reg: int, val: int) -> None:
        self._spi.xfer2([(reg << 1) & 0x7E, val])

    def _r(self, reg: int) -> int:
        return self._spi.xfer2([((reg << 1) & 0x7E) | 0x80, 0])[1]

    def _set(self, reg: int, mask: int) -> None:
        self._w(reg, self._r(reg) | mask)

    def _clr(self, reg: int, mask: int) -> None:
        self._w(reg, self._r(reg) & (~mask & 0xFF))

    def _init(self) -> None:
        self._w(_R_COMMAND, _PCD_RESET)
        time.sleep(0.05)
        # Timer: automatisch nach Transceive, ~25 ms Timeout
        self._w(_R_T_MODE,      0x80)
        self._w(_R_T_PRESCALER, 0xA9)
        self._w(_R_T_RELOAD_H,  0x03)
        self._w(_R_T_RELOAD_L,  0xE8)
        self._w(_R_TX_ASK,      0x40)  # 100 % ASK-Modulation
        self._w(_R_MODE,        0x3D)  # CRC-Preset 6363h
        self._set(_R_TX_CONTROL, 0x03)  # Antenne einschalten

    def _transceive(self, data: list[int], framing: int = 0) -> tuple[bool, list[int]]:
        self._w(_R_COMMAND, _PCD_IDLE)
        self._w(_R_COMM_IRQ, 0x7F)        # alle IRQs quittieren
        self._set(_R_FIFO_LEVEL, 0x80)    # FIFO leeren
        for b in data:
            self._w(_R_FIFO_DATA, b)
        self._w(_R_BIT_FRAMING, framing)
        self._w(_R_COMMAND, _PCD_TRANSCEIVE)
        self._set(_R_BIT_FRAMING, 0x80)   # StartSend=1

        deadline = time.monotonic() + 0.035
        irq = 0
        while time.monotonic() < deadline:
            irq = self._r(_R_COMM_IRQ)
            if irq & 0x30:               # RxIRq oder IdleIRq
                break
            time.sleep(0.001)            # ~1% CPU statt busy-spin
        self._clr(_R_BIT_FRAMING, 0x80)  # StartSend=0

        if not (irq & 0x30):
            return False, []
        if self._r(_R_ERROR) & 0x1B:     # Buffer-/Kollisions-/Paritätsfehler
            return False, []

        n = self._r(_R_FIFO_LEVEL)
        return True, [self._r(_R_FIFO_DATA) for _ in range(n)]

    def _crc(self, data: list[int]) -> list[int]:
        """Berechnet CRC_A über data mittels MFRC522-Hardware-CRC."""
        self._w(_R_COMMAND, _PCD_IDLE)
        self._set(_R_FIFO_LEVEL, 0x80)
        for b in data:
            self._w(_R_FIFO_DATA, b)
        self._w(_R_COMMAND, _PCD_CALC_CRC)
        deadline = time.monotonic() + 0.05
        while time.monotonic() < deadline:
            if self._r(_R_DIV_IRQ) & 0x04:  # CrcIRq
                break
            time.sleep(0.001)
        self._w(_R_COMMAND, _PCD_IDLE)
        # CRC_A wird LSB zuerst übertragen → [Low, High] anhängen, nicht [High, Low].
        # Falsche Reihenfolge => Karte verwirft SELECT (CRC-Fehler) => read_uid scheitert.
        return [self._r(_R_CRC_RESULT_L), self._r(_R_CRC_RESULT_H)]

    def _select(self, sel_code: int, anticoll_resp: list[int]) -> bool:
        """Aktiviert PICC via SELECT (ISO 14443-3); gibt False bei Fehler zurück."""
        payload = [sel_code, 0x70] + anticoll_resp[:4] + [anticoll_resp[4]]
        crc = self._crc(payload)
        ok, resp = self._transceive(payload + crc)
        return ok and len(resp) >= 1

    def _halt(self) -> None:
        """HLTA: versetzt die Karte in HALT, damit der nächste WUPA sie sauber neu
        erkennt. Eine selektierte (ACTIVE) Karte würde sonst nicht mehr antworten."""
        payload = [_PICC_HLTA, 0x00]
        self._transceive(payload + self._crc(payload))  # PICC antwortet nicht → ignorieren

    def read_uid(self) -> Optional[str]:
        """Gibt UID als Hex-String zurück (4 oder 7 Bytes), None wenn keine Karte."""
        # Schritt 1: WUPA – Karte im Feld? WUPA (statt REQA) weckt auch Karten aus
        # dem HALT-Zustand; nach erfolgreichem SELECT halten wir die Karte (s. _halt),
        # sonst antwortet sie auf den nächsten Poll nicht mehr → Flapping.
        ok, _ = self._transceive([_PICC_WUPA], framing=0x07)
        if not ok:
            return None

        # Schritt 2: Antikollision Kaskade 1
        ok, raw = self._transceive([0x93, 0x20])
        if not ok or len(raw) < 5:
            return None
        if (raw[0] ^ raw[1] ^ raw[2] ^ raw[3]) != raw[4]:
            return None  # BCC-Fehler
        if not self._select(0x93, raw):
            return None

        if raw[0] != _PICC_CT:
            # 4-Byte-UID (Mifare Classic, Mifare Ultralight …)
            self._halt()
            return bytes(raw[:4]).hex().upper()

        # Schritt 3: Antikollision Kaskade 2 → 7-Byte-UID (NTAG21x …)
        prefix = raw[1:4]
        ok, raw2 = self._transceive([0x95, 0x20])
        if not ok or len(raw2) < 5:
            return None
        if (raw2[0] ^ raw2[1] ^ raw2[2] ^ raw2[3]) != raw2[4]:
            return None
        if not self._select(0x95, raw2):
            return None
        self._halt()
        return bytes(prefix + raw2[:4]).hex().upper()


class RC522Reader:
    """Async-Wrapper: poll_forever legt tag_placed/tag_removed in eine asyncio.Queue."""

    def __init__(self, spi_bus: int = 0, spi_device: int = 0) -> None:
        self._bus = spi_bus
        self._device = spi_device
        self._rc522: Optional[_RC522] = None

    def start(self) -> None:
        self._rc522 = _RC522(self._bus, self._device)
        log.info("RC522 bereit (SPI%d.%d)", self._bus, self._device)

    def _read_uid_sync(self) -> Optional[str]:
        return self._rc522.read_uid() if self._rc522 else None

    async def poll_forever(self, queue: asyncio.Queue) -> None:
        loop = asyncio.get_running_loop()
        last_uid: Optional[str] = None
        removed_uid: Optional[str] = None
        removed_at: float = 0.0
        _DEBOUNCE = 1.0  # Sekunden: gleiche Karte nach Entfernen kurz ignorieren

        while True:
            try:
                uid = await loop.run_in_executor(None, self._read_uid_sync)
            except Exception:
                log.exception("RC522 Lesefehler")
                await asyncio.sleep(1.0)
                continue

            if uid and uid != last_uid:
                if uid == removed_uid and (time.monotonic() - removed_at) < _DEBOUNCE:
                    pass  # Karte kurz abgehoben und wieder aufgelegt → ignorieren
                else:
                    log.info("Tag erkannt: %s", uid)
                    await queue.put({"event": "tag_placed", "uid": uid})
            elif not uid and last_uid:
                log.info("Tag entfernt: %s", last_uid)
                removed_uid = last_uid
                removed_at = time.monotonic()
                await queue.put({"event": "tag_removed", "uid": last_uid})

            last_uid = uid
            await asyncio.sleep(_POLL_INTERVAL)
