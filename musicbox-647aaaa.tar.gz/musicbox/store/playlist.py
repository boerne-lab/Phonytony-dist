"""PlaylistStore: CRUD für playlists.json + m3u8-Generierung."""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from typing import Optional

CATEGORIES = ("musik", "hoerbuch")
_AUDIO_EXTS = ("*.mp3", "*.flac", "*.ogg", "*.m4a")
_AUDIO_SUFFIXES = {".mp3", ".flac", ".ogg", ".m4a"}


class PlaylistStore:
    def __init__(self, path: Path, music_dir: Path, playlists_dir: Path) -> None:
        self._path = path
        self._music_dir = music_dir
        self._playlists_dir = playlists_dir
        self._data: dict = {"version": 1, "playlists": {}}

    def load(self) -> None:
        if not self._path.exists():
            self._save()
            return
        with open(self._path) as f:
            self._data = json.load(f)

    def all(self) -> dict:
        result = {}
        for pid, pl in self._data.get("playlists", {}).items():
            result[pid] = {**pl, "m3u8_path": str(self.m3u8_path(pid))}
        return result

    def get(self, playlist_id: str) -> Optional[dict]:
        pl = self._data.get("playlists", {}).get(playlist_id)
        if pl is None:
            return None
        return {**pl, "m3u8_path": str(self.m3u8_path(playlist_id))}

    def create(self, name: str, category: str, tracks: list[str],
                shuffle: bool = False, repeat: str = "off") -> dict:
        if category not in CATEGORIES:
            raise ValueError(f"Ungültige Kategorie: {category!r}")
        playlist_id = uuid.uuid4().hex[:10]
        entry = {
            "id": playlist_id,
            "name": name,
            "category": category,
            "tracks": tracks,
            "shuffle": shuffle,
            "repeat": repeat,
        }
        self._data.setdefault("playlists", {})[playlist_id] = entry
        self._save()
        self._write_m3u8(entry)
        return {**entry, "m3u8_path": str(self.m3u8_path(playlist_id))}

    def update(self, playlist_id: str, **kwargs) -> Optional[dict]:
        playlists = self._data.get("playlists", {})
        if playlist_id not in playlists:
            return None
        if "category" in kwargs and kwargs["category"] not in CATEGORIES:
            raise ValueError(f"Ungültige Kategorie: {kwargs['category']!r}")
        entry = playlists[playlist_id]
        for k, v in kwargs.items():
            if k in ("name", "category", "tracks", "shuffle", "repeat"):
                entry[k] = v
        self._save()
        self._write_m3u8(entry)
        return {**entry, "m3u8_path": str(self.m3u8_path(playlist_id))}

    def delete(self, playlist_id: str) -> bool:
        playlists = self._data.get("playlists", {})
        if playlist_id not in playlists:
            return False
        del playlists[playlist_id]
        self._save()
        self.m3u8_path(playlist_id).unlink(missing_ok=True)
        return True

    def m3u8_path(self, playlist_id: str) -> Path:
        return self._playlists_dir / f"{playlist_id}.m3u8"

    def list_files(self) -> dict[str, list[str]]:
        """Alle Audiodateien gruppiert nach Kategorie; Pfade relativ zu music_dir."""
        result: dict[str, list[str]] = {cat: [] for cat in CATEGORIES}
        for cat in CATEGORIES:
            cat_dir = self._music_dir / cat
            if not cat_dir.exists():
                continue
            # Endungen case-insensitive (sonst fehlen z.B. .MP3/.FLAC im Editor)
            for f in sorted(cat_dir.iterdir()):
                if f.is_file() and f.suffix.lower() in _AUDIO_SUFFIXES:
                    result[cat].append(f"{cat}/{f.name}")
        return result

    def _write_m3u8(self, entry: dict) -> None:
        self._playlists_dir.mkdir(parents=True, exist_ok=True)
        lines = [str(self._music_dir / t) for t in entry["tracks"]]
        dest = self.m3u8_path(entry["id"])
        tmp = dest.with_suffix(".m3u8.tmp")
        tmp.write_text("\n".join(lines))
        os.replace(tmp, dest)

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_name(self._path.name + f".{os.getpid()}.tmp")
        tmp.write_text(json.dumps(self._data, indent=2, ensure_ascii=False))
        os.replace(tmp, self._path)
