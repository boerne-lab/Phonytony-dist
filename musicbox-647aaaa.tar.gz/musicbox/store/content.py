"""Inhaltsart einer Karte aus type+ref ableiten (kein gespeichertes Feld)."""

from __future__ import annotations

_AUDIO_SUFFIXES = (".mp3", ".flac", ".ogg", ".m4a")


def content_kind(card: dict) -> str:
    """'song' | 'playlist' | 'album' | 'artist' | 'unknown'."""
    typ = (card or {}).get("type")
    ref = ((card or {}).get("ref") or "").strip()
    if not ref:
        return "unknown"
    low = ref.lower()
    if typ == "local":
        if low.endswith(".m3u8"):
            return "playlist"
        if low.endswith(_AUDIO_SUFFIXES):
            return "song"
        return "unknown"
    if typ == "spotify":
        if ":track:" in low:
            return "song"
        if ":album:" in low:
            return "album"
        if ":playlist:" in low:
            return "playlist"
        if ":artist:" in low:
            return "artist"
    return "unknown"
