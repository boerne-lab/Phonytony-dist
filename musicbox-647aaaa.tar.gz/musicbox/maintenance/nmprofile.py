"""Erzeugt validen NetworkManager-.nmconnection-Inhalt für WPA2-PSK-WLANs (testbar)."""

from __future__ import annotations


def render_wifi_profile(ssid: str, password: str, *, uuid: str,
                        autoconnect: bool = True, priority: int = 0) -> str:
    ac = "true" if autoconnect else "false"
    return (
        "[connection]\n"
        f"id={ssid}\n"
        f"uuid={uuid}\n"
        "type=wifi\n"
        f"autoconnect={ac}\n"
        f"autoconnect-priority={priority}\n\n"
        "[wifi]\n"
        "mode=infrastructure\n"
        f"ssid={ssid}\n\n"
        "[wifi-security]\n"
        "key-mgmt=wpa-psk\n"
        f"psk={password}\n\n"
        "[ipv4]\nmethod=auto\n\n"
        "[ipv6]\nmethod=auto\n"
    )
