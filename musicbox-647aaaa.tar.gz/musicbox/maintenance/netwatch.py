"""AP-Fallback-Supervisor: spannt ein Setup-WLAN auf, wenn kein Station-WLAN verbindet."""

from __future__ import annotations

import logging
import subprocess
import time
from pathlib import Path
from typing import Callable

log = logging.getLogger(__name__)

AP_CONN = "musicbox-ap"
FLAG = Path("/run/musicbox/ap_active")


def decide(*, station_connected: bool, ap_active: bool) -> str:
    """'ap_on' | 'ap_off' | 'noop' — wann der AP umgeschaltet wird."""
    if station_connected:
        return "ap_off" if ap_active else "noop"
    return "noop" if ap_active else "ap_on"


def _nmcli(args, runner: Callable = subprocess.run):
    return runner(["nmcli", *args], capture_output=True, text=True)


def station_connected(runner: Callable = subprocess.run) -> bool:
    """True, wenn eine aktive WLAN-Verbindung existiert, die NICHT der AP ist."""
    r = _nmcli(["-t", "-f", "NAME,TYPE,DEVICE", "connection", "show", "--active"], runner)
    for line in (getattr(r, "stdout", "") or "").splitlines():
        parts = line.split(":")
        if len(parts) >= 2 and parts[1] in ("802-11-wireless", "wifi") and parts[0] != AP_CONN:
            return True
    return False


def ap_active(runner: Callable = subprocess.run) -> bool:
    r = _nmcli(["-t", "-f", "NAME", "connection", "show", "--active"], runner)
    return AP_CONN in (getattr(r, "stdout", "") or "").splitlines()


def set_ap(on: bool, runner: Callable = subprocess.run) -> None:
    _nmcli(["connection", "up" if on else "down", AP_CONN], runner)
    try:
        FLAG.parent.mkdir(parents=True, exist_ok=True)
        if on:
            FLAG.write_text("1")
        else:
            FLAG.unlink(missing_ok=True)
    except OSError:
        pass


def run(*, boot_grace: float = 45.0, interval: float = 10.0,
        runner: Callable = subprocess.run, sleep: Callable = time.sleep) -> None:
    # Beim Boot kurz auf bekanntes WLAN warten
    deadline = time.monotonic() + boot_grace
    while time.monotonic() < deadline:
        if station_connected(runner):
            break
        sleep(2.0)
    while True:
        action = decide(station_connected=station_connected(runner), ap_active=ap_active(runner))
        if action == "ap_on":
            log.info("Kein WLAN – schalte Setup-AP ein")
            set_ap(True, runner)
        elif action == "ap_off":
            log.info("WLAN verbunden – schalte Setup-AP aus")
            set_ap(False, runner)
        sleep(interval)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run()
