"""WLAN-Verwaltung über nmcli (testbar) + CLI für den root-Helfer.

Sicherheit: Argumente werden NIE in eine Shell interpoliert, sondern als eigene
nmcli-Argumente übergeben; SSID/Passwort werden validiert.
"""

from __future__ import annotations

import argparse
import json
import subprocess
from typing import Callable

AP_CONN = "musicbox-ap"
_MAX = 63


def validate_ssid(ssid: str) -> str:
    if not ssid or len(ssid) > 32:
        raise ValueError("SSID muss 1–32 Zeichen lang sein")
    if any(ord(c) < 32 for c in ssid):
        raise ValueError("SSID enthält Steuerzeichen")
    return ssid


def validate_password(pw: str) -> str:
    if not (8 <= len(pw) <= _MAX):
        raise ValueError("WLAN-Passwort muss 8–63 Zeichen lang sein")
    if any(ord(c) < 32 for c in pw):
        raise ValueError("Passwort enthält Steuerzeichen")
    return pw


def _run(cmd, runner: Callable):
    return runner(cmd, capture_output=True, text=True)


def list_saved(*, runner: Callable = subprocess.run) -> dict:
    r = _run(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"], runner)
    saved = []
    for line in (getattr(r, "stdout", "") or "").splitlines():
        parts = line.split(":")
        if len(parts) >= 2 and parts[1] in ("802-11-wireless", "wifi") and parts[0] != AP_CONN:
            saved.append({"ssid": parts[0]})
    return {"ok": True, "saved": saved}


def scan(*, runner: Callable = subprocess.run) -> dict:
    r = _run(["nmcli", "-t", "-f", "SSID,SIGNAL", "device", "wifi", "list"], runner)
    seen, out = set(), []
    for line in (getattr(r, "stdout", "") or "").splitlines():
        parts = line.split(":")
        ssid = parts[0].strip()
        if ssid and ssid not in seen:
            seen.add(ssid)
            out.append({"ssid": ssid, "signal": parts[1] if len(parts) > 1 else ""})
    return {"ok": True, "scan": out}


def add(ssid: str, password: str, *, runner: Callable = subprocess.run) -> dict:
    validate_ssid(ssid)
    validate_password(password)
    # Sicherheit explizit setzen statt NetworkManager raten zu lassen — sonst:
    # "802-11-wireless-security.key-mgmt: Eigenschaft fehlt" (z.B. wenn die SSID nicht
    # im aktuellen Scan ist). Evtl. kaputtes Profil gleichen Namens vorher entfernen.
    _run(["nmcli", "connection", "delete", ssid], runner)  # Fehler ignorieren
    r = _run(["nmcli", "connection", "add", "type", "wifi", "con-name", ssid,
              "ssid", ssid, "wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", password], runner)
    if getattr(r, "returncode", 1) != 0:
        return {"ok": False,
                "error": (getattr(r, "stderr", "") or "Anlegen fehlgeschlagen").strip()}
    r2 = _run(["nmcli", "connection", "up", ssid], runner)
    ok = getattr(r2, "returncode", 1) == 0
    return {"ok": ok,
            "error": "" if ok else (getattr(r2, "stderr", "") or "Verbindung fehlgeschlagen").strip()}


def remove(ssid: str, *, runner: Callable = subprocess.run) -> dict:
    validate_ssid(ssid)
    _run(["nmcli", "connection", "down", ssid], runner)
    r = _run(["nmcli", "connection", "delete", ssid], runner)
    return {"ok": getattr(r, "returncode", 1) == 0}


def set_ap(ssid: str, password: str, *, runner: Callable = subprocess.run) -> dict:
    validate_ssid(ssid)
    validate_password(password)
    _run(["nmcli", "connection", "modify", AP_CONN, "wifi.ssid", ssid], runner)
    r = _run(["nmcli", "connection", "modify", AP_CONN, "wifi-sec.psk", password], runner)
    return {"ok": getattr(r, "returncode", 1) == 0}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    sub.add_parser("scan")
    a = sub.add_parser("add"); a.add_argument("--ssid", required=True); a.add_argument("--password", required=True)
    rm = sub.add_parser("remove"); rm.add_argument("--ssid", required=True)
    sa = sub.add_parser("set-ap"); sa.add_argument("--ssid", required=True); sa.add_argument("--password", required=True)
    args = ap.parse_args(argv)
    try:
        if args.cmd == "list":
            res = list_saved()
        elif args.cmd == "scan":
            res = scan()
        elif args.cmd == "add":
            res = add(args.ssid, args.password)
        elif args.cmd == "remove":
            res = remove(args.ssid)
        elif args.cmd == "set-ap":
            res = set_ap(args.ssid, args.password)
        else:
            res = {"ok": False, "error": "unbekannt"}
    except ValueError as e:
        res = {"ok": False, "error": str(e)}
    print(json.dumps(res))
    return 0 if res.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
