"""Lädt config.toml + .env und liefert ein Settings-Objekt."""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

_DEFAULT_CONFIG = Path(__file__).parent.parent / "config" / "config.toml"


@dataclass(frozen=True)
class Settings:
    # GPIO
    gpio_play_pause: int
    gpio_next: int
    gpio_prev: int
    gpio_enc_clk: int
    gpio_enc_dt: int
    gpio_enc_sw: int
    btn_bounce_ms: int
    enc_volume_step: int
    rfid_rst_pin: int

    # Audio
    alsa_card: str
    alsa_controls: list  # z.B. ["Headphone", "Speaker"]
    feedback_dir: Path
    volume_default: int

    # Paths
    mapping_file: Path
    state_file: Path
    settings_file: Path
    tokens_file: Path
    music_dir: Path
    playlists_dir: Path
    playlists_file: Path

    # Spotify
    spotify_client_id: str
    spotify_redirect_uri: str
    librespot_url: str

    # Server
    host: str
    port: int

    # Sockets
    control_socket: str
    mpv_socket: str

    # Daten-/Self-Update
    data_dir: Path
    version_file: Path
    update_url: str

    # WLAN-Onboarding (AP)
    ap_ssid: str
    ap_password: str
    ap_active_flag: Path


def load_settings(config_path: Path | None = None) -> Settings:
    path = config_path or Path(os.environ.get("MUSICBOX_CONFIG", _DEFAULT_CONFIG))
    with open(path, "rb") as f:
        c = tomllib.load(f)

    # Produktions-Default: config liegt in /etc/musicbox/ → data in /var/lib/musicbox/
    # Entwicklungs-Default: config liegt in repo/config/ → data ist repo-Root
    if os.environ.get("MUSICBOX_DATA_DIR"):
        base = Path(os.environ["MUSICBOX_DATA_DIR"])
    elif str(path).startswith("/etc/"):
        base = Path("/var/lib/musicbox")
    else:
        base = path.parent.parent

    def p(rel: str) -> Path:
        return (base / rel).resolve()

    return Settings(
        # GPIO
        gpio_play_pause=c["gpio"]["btn_play_pause"],
        gpio_next=c["gpio"]["btn_next"],
        gpio_prev=c["gpio"]["btn_prev"],
        gpio_enc_clk=c["gpio"]["enc_clk"],
        gpio_enc_dt=c["gpio"]["enc_dt"],
        gpio_enc_sw=c["gpio"]["enc_sw"],
        btn_bounce_ms=c["gpio"]["btn_bounce_ms"],
        enc_volume_step=c["gpio"]["enc_volume_step"],
        rfid_rst_pin=c["gpio"]["rfid_rst"],
        # Audio
        alsa_card=c["audio"]["alsa_card"],
        alsa_controls=c["audio"]["alsa_controls"],
        feedback_dir=p(c["audio"]["feedback_dir"]),
        volume_default=c["audio"]["volume_default"],
        # Paths
        mapping_file=p(c["paths"]["mapping_file"]),
        state_file=p(c["paths"]["state_file"]),
        # .get mit Default: ältere config.toml ohne settings_file bleibt lauffähig
        settings_file=p(c["paths"].get("settings_file", "settings.json")),
        tokens_file=p(c["paths"]["tokens_file"]),
        music_dir=p(c["paths"]["music_dir"]),
        playlists_dir=p(c["paths"]["playlists_dir"]),
        playlists_file=p(c["paths"]["playlists_file"]),
        # Spotify
        spotify_client_id=os.environ.get("SPOTIFY_CLIENT_ID", ""),
        spotify_redirect_uri=os.environ.get(
            "SPOTIFY_REDIRECT_URI",
            f"http://musicbox.local:{c['server']['port']}/auth/spotify/callback",
        ),
        librespot_url=c["spotify"]["librespot_url"],
        # Server
        host=c["server"]["host"],
        port=c["server"]["port"],
        # Sockets
        control_socket=c["sockets"]["control_socket"],
        mpv_socket=c["sockets"]["mpv_socket"],
        # Daten-/Self-Update
        data_dir=base.resolve(),
        # App-Wurzel (Paket-Elternverzeichnis): repo-Root im Dev, /opt/musicbox in Prod
        version_file=(Path(__file__).resolve().parent.parent / "VERSION"),
        update_url=c.get(
            "update_url",
            "https://raw.githubusercontent.com/boerne-lab/Phonytony-dist/main/latest.json",
        ),
        # WLAN-Onboarding (AP)
        ap_ssid=c.get("wifi", {}).get("ap_ssid", "MusicBox-Setup"),
        ap_password=c.get("wifi", {}).get("ap_password", "musicbox-setup"),
        ap_active_flag=Path(c.get("wifi", {}).get("ap_active_flag", "/run/musicbox/ap_active")),
    )
