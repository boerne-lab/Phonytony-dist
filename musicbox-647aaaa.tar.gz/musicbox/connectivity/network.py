"""Netzwerk-Verfügbarkeit prüfen (TCP-Probe, gecacht)."""

from __future__ import annotations

import asyncio
import time


_CACHE_TTL = 5.0
_HOST = "1.1.1.1"
_PORT = 53
_TIMEOUT = 1.0

_last_check: float = 0.0
_last_result: bool = False


async def is_online(
    host: str = _HOST,
    port: int = _PORT,
    timeout: float = _TIMEOUT,
) -> bool:
    global _last_check, _last_result

    now = time.monotonic()
    if now - _last_check < _CACHE_TTL:
        return _last_result

    try:
        _, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=timeout
        )
        writer.close()
        await writer.wait_closed()
        _last_result = True
    except Exception:
        _last_result = False

    _last_check = now
    return _last_result
