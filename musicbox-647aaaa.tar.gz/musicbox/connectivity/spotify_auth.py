"""Spotify-Authentifizierung via spotipy (PKCE) + atomischer CacheHandler."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Optional

from spotipy.cache_handler import CacheHandler

log = logging.getLogger(__name__)


class AtomicCacheHandler(CacheHandler):
    """Schreibt Token-Cache atomisch via .tmp → rename."""

    def __init__(self, path: Path) -> None:
        self._path = path

    def get_cached_token(self) -> Optional[dict]:
        if not self._path.exists():
            return None
        try:
            return json.loads(self._path.read_text())
        except (json.JSONDecodeError, OSError):
            return None

    def save_token_to_cache(self, token_info: dict) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(token_info))
        os.replace(tmp, self._path)


def make_sp_oauth(client_id: str, redirect_uri: str, tokens_path: Path):
    """Erstellt SpotifyPKCE-Instanz mit atomischem Cache-Handler."""
    from spotipy.oauth2 import SpotifyPKCE

    return SpotifyPKCE(
        client_id=client_id,
        redirect_uri=redirect_uri,
        scope=(
            "user-read-playback-state user-modify-playback-state streaming "
            "playlist-read-private playlist-read-collaborative "
            "user-library-read user-follow-read"
        ),
        cache_handler=AtomicCacheHandler(tokens_path),
        open_browser=False,
    )


def is_authorized(client_id: str, redirect_uri: str, tokens_path: Path) -> bool:
    sp_oauth = make_sp_oauth(client_id, redirect_uri, tokens_path)
    try:
        token = sp_oauth.get_cached_token()
        return token is not None
    except Exception:
        return False
