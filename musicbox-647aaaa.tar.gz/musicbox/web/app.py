"""FastAPI App Factory."""

from __future__ import annotations

from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from musicbox.settings import Settings, load_settings
from musicbox.store.mapping import MappingStore
from musicbox.store.playlist import PlaylistStore
from musicbox.store.settings_store import SettingsStore
from musicbox.store.state import StateStore
from musicbox.connectivity.spotify_auth import make_sp_oauth

# Pfade relativ zum installierten Package — unabhängig vom data-dir
_WEB_DIR = Path(__file__).parent


def create_app(settings: Settings | None = None) -> FastAPI:
    if settings is None:
        settings = load_settings()

    mapping_store = MappingStore(settings.mapping_file)
    mapping_store.load()
    state_store = StateStore(settings.state_file)
    state_store.load()
    settings_store = SettingsStore(settings.settings_file)
    settings_store.load()
    playlist_store = PlaylistStore(settings.playlists_file, settings.music_dir, settings.playlists_dir)
    playlist_store.load()
    sp_oauth = make_sp_oauth(
        settings.spotify_client_id,
        settings.spotify_redirect_uri,
        settings.tokens_file,
    )

    templates = Jinja2Templates(directory=str(_WEB_DIR / "templates"))

    app = FastAPI(title="MusicBox", docs_url=None, redoc_url=None)

    static_dir = _WEB_DIR / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Abhängigkeiten als App-State bereitstellen
    app.state.settings = settings
    app.state.mapping_store = mapping_store
    app.state.state_store = state_store
    app.state.settings_store = settings_store
    app.state.playlist_store = playlist_store
    app.state.sp_oauth = sp_oauth
    app.state.templates = templates

    from musicbox.web.routes import (
        api, captive, library, playlists, setup, spotify_oauth, ui, update, upload, wifi,
    )

    app.include_router(ui.router)
    app.include_router(playlists.router)
    app.include_router(api.router, prefix="/api")
    app.include_router(update.router, prefix="/api")
    app.include_router(library.router, prefix="/api")
    app.include_router(wifi.router)
    app.include_router(captive.router)
    app.include_router(spotify_oauth.router, prefix="/auth")
    app.include_router(upload.router)
    app.include_router(setup.router)

    return app


def run() -> None:
    settings = load_settings()
    uvicorn.run(
        "musicbox.web.app:create_app",
        factory=True,
        host=settings.host,
        port=settings.port,
        log_level="info",
    )


if __name__ == "__main__":
    run()
