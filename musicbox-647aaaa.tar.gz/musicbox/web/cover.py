"""Quadratisches Cover-Thumbnail (JPEG) + Datei-Cache für das Karten-Grid."""

from __future__ import annotations

import io
import logging
from pathlib import Path

from PIL import Image, ImageDraw

from musicbox.web import sticker

log = logging.getLogger(__name__)

_SIZE = 300


def cache_path(cache_dir: Path, uid: str) -> Path:
    return cache_dir / f"{uid}.jpg"


def invalidate(cache_dir: Path, uid: str) -> None:
    try:
        cache_path(cache_dir, uid).unlink(missing_ok=True)
    except OSError:
        pass


def _placeholder() -> Image.Image:
    img = Image.new("RGB", (_SIZE, _SIZE), (40, 42, 54))
    d = ImageDraw.Draw(img)
    d.text((_SIZE // 2, _SIZE // 2), "♪", fill=(120, 124, 150), anchor="mm")
    return img


def _square(img: Image.Image) -> Image.Image:
    c = img.convert("RGB")
    s = min(c.size)
    c = c.crop(((c.width - s) // 2, (c.height - s) // 2,
                (c.width + s) // 2, (c.height + s) // 2))
    return c.resize((_SIZE, _SIZE))


def thumbnail_jpeg(card: dict, uid: str, *, sp_oauth, music_dir: Path,
                   covers_dir: Path, cache_dir: Path) -> bytes:
    """Liefert JPEG-Bytes; nutzt Cache, sonst rendert+cached. Nie Exception nach außen."""
    cp = cache_path(cache_dir, uid)
    if cp.exists():
        try:
            return cp.read_bytes()
        except OSError:
            pass
    try:
        _title, cover = sticker.cover_title_for_card(
            card, uid, sp_oauth=sp_oauth, music_dir=music_dir, covers_dir=covers_dir,
        )
    except Exception as e:
        log.debug("Cover-Ermittlung fehlgeschlagen: %s", e)
        cover = None
    img = _square(cover) if cover is not None else _placeholder()
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=85)
    data = buf.getvalue()
    # Nur echte Cover cachen — Platzhalter NICHT, damit ein später ergänztes Cover
    # (Sidecar-Bild, Spotify-Auth, hochgeladenes Cover) beim nächsten Aufruf gefunden wird.
    if cover is not None:
        try:
            cache_dir.mkdir(parents=True, exist_ok=True)
            tmp = cp.with_suffix(".jpg.tmp")
            tmp.write_bytes(data)
            tmp.replace(cp)
        except OSError as e:
            log.debug("Cover-Cache schreiben fehlgeschlagen: %s", e)
    return data
