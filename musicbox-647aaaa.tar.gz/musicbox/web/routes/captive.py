"""Captive-Portal-Probe-Routen: leiten im AP-Modus auf die WLAN-Seite, sonst neutral."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import PlainTextResponse, RedirectResponse, Response

router = APIRouter()


def _ap_active(request: Request) -> bool:
    try:
        return Path(request.app.state.settings.ap_active_flag).exists()
    except Exception:
        return False


def _maybe_redirect(request: Request, neutral: Response) -> Response:
    if _ap_active(request):
        return RedirectResponse("/wifi", status_code=307)
    return neutral


@router.get("/generate_204")
@router.get("/gen_204")
def android(request: Request):
    return _maybe_redirect(request, Response(status_code=204))


@router.get("/hotspot-detect.html")
@router.get("/library/test/success.html")
def apple(request: Request):
    return _maybe_redirect(request, PlainTextResponse("Success"))


@router.get("/connecttest.txt")
@router.get("/ncsi.txt")
def windows(request: Request):
    return _maybe_redirect(request, PlainTextResponse("Microsoft Connect Test"))
