"""Setup & Diagnose: /setup/*"""

from __future__ import annotations

import asyncio
import json
import subprocess
import time
from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse

router = APIRouter()


# ─── HTML-Seite ────────────────────────────────────────────────────────────────

@router.get("/setup", response_class=HTMLResponse)
def setup_page(request: Request):
    return request.app.state.templates.TemplateResponse(
        request, "setup.html", {"request": request}
    )


# ─── ALSA ──────────────────────────────────────────────────────────────────────

@router.get("/api/setup/alsa/controls")
def alsa_controls(request: Request):
    """Gibt alle vorhandenen ALSA-Controls der konfigurierten Karte zurück."""
    card = request.app.state.settings.alsa_card
    try:
        out = subprocess.check_output(
            ["amixer", "-c", card, "scontrols"],
            stderr=subprocess.DEVNULL, text=True
        )
        controls = []
        for line in out.splitlines():
            if "'" in line:
                name = line.split("'")[1]
                controls.append(name)
        return {"ok": True, "card": card, "controls": controls}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@router.get("/api/setup/alsa/volume")
def alsa_get_volume(request: Request):
    """Liest aktuelle Lautstärke aller konfigurierten Controls."""
    settings = request.app.state.settings
    result = {}
    for ctrl in settings.alsa_controls:
        try:
            out = subprocess.check_output(
                ["amixer", "-c", settings.alsa_card, "sget", ctrl],
                stderr=subprocess.DEVNULL, text=True
            )
            for part in out.split():
                if part.startswith("[") and part.endswith("%]"):
                    result[ctrl] = int(part[1:-2])
                    break
        except Exception:
            result[ctrl] = None
    return {"ok": True, "volumes": result}


@router.post("/api/setup/alsa/volume")
async def alsa_set_volume(request: Request):
    """Setzt Lautstärke für einen oder alle Controls."""
    body = await request.json()
    settings = request.app.state.settings
    control = body.get("control")  # None = alle
    pct = int(body.get("value", 70))
    pct = max(0, min(100, pct))

    targets = [control] if control else settings.alsa_controls
    errors = []
    for ctrl in targets:
        try:
            subprocess.run(
                ["amixer", "-c", settings.alsa_card, "sset", ctrl, f"{pct}%", "on"],
                check=True, capture_output=True
            )
        except subprocess.CalledProcessError as e:
            errors.append(f"{ctrl}: {e}")

    return {"ok": not errors, "errors": errors}


@router.post("/api/setup/alsa/test-tone")
async def alsa_test_tone(request: Request):
    """Spielt 1-Sekunden-Testton auf dem konfigurierten ALSA-Gerät."""
    body = await request.json()
    settings = request.app.state.settings
    # Optionaler Control-Override für gezielten Test (z.B. nur Headphone)
    device = body.get("device", f"plughw:{settings.alsa_card},0")
    try:
        proc = await asyncio.create_subprocess_exec(
            "speaker-test", "-D", device, "-t", "sine", "-f", "1000", "-l", "1", "-c", "2",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=5.0)
        if proc.returncode == 0:
            return {"ok": True}
        return {"ok": False, "error": stderr.decode()[:200]}
    except asyncio.TimeoutError:
        proc.kill()
        return {"ok": False, "error": "Timeout"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ─── Spotify ───────────────────────────────────────────────────────────────────

@router.get("/api/setup/spotify/status")
def spotify_status(request: Request):
    """Prüft ob gültige Spotify-Tokens vorhanden sind."""
    sp_oauth = request.app.state.sp_oauth
    try:
        token = sp_oauth.get_cached_token()
        if not token:
            return {"ok": True, "connected": False}
        expires_at = token.get("expires_at", 0)
        expires_in_s = int(expires_at - time.time())
        return {
            "ok": True,
            "connected": True,
            "expires_in_h": round(expires_in_s / 3600, 1) if expires_in_s > 0 else 0,
        }
    except Exception as e:
        return {"ok": False, "connected": False, "error": str(e)}


# ─── RFID ──────────────────────────────────────────────────────────────────────

# Letzter gescannter Tag (aus state.json, wird vom Core beschrieben)
@router.get("/api/setup/rfid/last-scan")
def rfid_last_scan(request: Request):
    """Gibt den zuletzt vom Core erkannten Tag zurück."""
    state = request.app.state.state_store
    state.load()
    return {
        "ok": True,
        "uid": state.state.last_scanned_uid,
        "at": state.state.last_scanned_at,
        "present_uid": state.state.present_uid,
    }


@router.get("/api/setup/rfid/check")
def rfid_check():
    """Prüft ob /dev/spidev0.0 vorhanden ist (SPI aktiv?)."""
    spi_dev = Path("/dev/spidev0.0")
    return {
        "ok": spi_dev.exists(),
        "spi_device": str(spi_dev),
        "hint": "dtparam=spi=on in /boot/firmware/config.txt fehlt" if not spi_dev.exists() else "",
    }


# ─── System-Info ───────────────────────────────────────────────────────────────

@router.get("/api/setup/env")
def env_read():
    """.env-Datei lesen."""
    env_path = Path("/etc/musicbox/.env")
    if not env_path.exists():
        # Fallback: lokale .env
        env_path = Path(".env")
    try:
        return {"ok": True, "content": env_path.read_text(), "path": str(env_path)}
    except Exception as e:
        return {"ok": False, "error": str(e), "content": ""}


@router.post("/api/setup/env")
async def env_write(request: Request):
    """.env-Datei schreiben und musicbox-core neu starten."""
    body = await request.json()
    content = body.get("content", "")
    env_path = Path("/etc/musicbox/.env")
    if not env_path.parent.exists():
        env_path = Path(".env")
    try:
        import os, tempfile
        tmp = env_path.with_suffix(".tmp")
        tmp.write_text(content)
        os.replace(tmp, env_path)
        # Core neu starten (nur wenn systemd verfügbar)
        subprocess.run(
            ["systemctl", "restart", "musicbox-core"],
            capture_output=True, timeout=5
        )
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@router.get("/api/setup/system")
def system_info(request: Request):
    """Grundlegende System-Infos und Service-Status."""
    services = ["go-librespot", "musicbox-core", "musicbox-web"]
    status = {}
    for svc in services:
        try:
            r = subprocess.run(
                ["systemctl", "is-active", svc],
                capture_output=True, text=True
            )
            status[svc] = r.stdout.strip()
        except Exception:
            status[svc] = "unknown"

    # I2C-Geräte (WM8960-Codec-Check)
    i2c_devices = []
    try:
        out = subprocess.check_output(
            ["i2cdetect", "-y", "1"], stderr=subprocess.DEVNULL, text=True
        )
        for line in out.splitlines()[1:]:
            for token in line.split()[1:]:
                if token not in ("--", "UU"):
                    i2c_devices.append(f"0x{token}")
    except Exception:
        pass

    # SPI
    spi_ok = Path("/dev/spidev0.0").exists()

    settings = request.app.state.settings
    return {
        "ok": True,
        "services": status,
        "i2c_devices": i2c_devices,
        "spi_available": spi_ok,
        "alsa_card": settings.alsa_card,
        "alsa_controls": settings.alsa_controls,
    }
