"""Self-Update-Routen: /api/update/{status,check,start}."""

from __future__ import annotations

import asyncio
import json
import subprocess
from pathlib import Path

from fastapi import APIRouter, Request

router = APIRouter()


def _status_file(request: Request) -> Path:
    s = request.app.state.settings
    return s.data_dir / "update_status.json"


def _version(request: Request) -> str:
    try:
        return Path(request.app.state.settings.version_file).read_text().strip()
    except OSError:
        return "unbekannt"


def _trigger_update_service() -> bool:
    try:
        subprocess.run(["sudo", "-n", "systemctl", "start", "musicbox-update.service"],
                       check=True, timeout=10)
        return True
    except Exception:
        return False


@router.get("/update/status")
def update_status(request: Request) -> dict:
    try:
        st = json.loads(_status_file(request).read_text())
    except (OSError, json.JSONDecodeError):
        st = {"state": "idle", "message": "", "version": "", "ts": 0}
    st["installed"] = _version(request)
    return st


@router.post("/update/start")
async def update_start(request: Request) -> dict:
    ok = await asyncio.to_thread(_trigger_update_service)
    return {"ok": ok}


@router.post("/update/check")
async def update_check(request: Request) -> dict:
    """Manifest direkt lesen und mit installierter Version vergleichen (ohne Anwenden)."""
    s = request.app.state.settings
    installed = _version(request)

    def _check():
        import httpx
        m = httpx.get(s.update_url, timeout=10.0, follow_redirects=True).json()
        return {"available": str(m.get("version", "")) != installed,
                "latest": m.get("version", ""), "installed": installed}

    try:
        return await asyncio.to_thread(_check)
    except Exception as e:
        return {"available": False, "error": str(e)}
