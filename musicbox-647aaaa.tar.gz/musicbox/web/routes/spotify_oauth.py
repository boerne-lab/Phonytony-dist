"""Spotify OAuth2 PKCE Flow: /auth/spotify/start + /callback + /exchange"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

log = logging.getLogger(__name__)

router = APIRouter()


@router.get("/spotify/start", response_class=HTMLResponse)
def spotify_start(request: Request) -> HTMLResponse:
    sp_oauth = request.app.state.sp_oauth
    auth_url = sp_oauth.get_authorize_url()
    return request.app.state.templates.TemplateResponse(
        request, "spotify_auth.html", {"request": request, "auth_url": auth_url}
    )


@router.get("/spotify/callback")
def spotify_callback(code: str, request: Request) -> RedirectResponse:
    """Direkter Callback — funktioniert nur per SSH-Tunnel (127.0.0.1 lokal)."""
    sp_oauth = request.app.state.sp_oauth
    try:
        # SpotifyPKCE.get_access_token(code, check_cache) — kein as_dict (nur SpotifyOAuth);
        # die Methode speichert den Token selbst via cache_handler.
        sp_oauth.get_access_token(code, check_cache=False)
    except Exception as e:
        log.warning("Spotify-Callback fehlgeschlagen: %s", e)
        return RedirectResponse("/?msg=spotify_error")
    # Banner wird nur von index.html (/) gerendert.
    return RedirectResponse("/?msg=spotify_connected")


@router.post("/spotify/exchange")
async def spotify_exchange(request: Request) -> JSONResponse:
    """Tauscht einen manuell eingefügten Authorization Code gegen Tokens."""
    body = await request.json()
    code = body.get("code", "").strip()
    if not code:
        return JSONResponse({"ok": False, "error": "Kein Code angegeben"})
    sp_oauth = request.app.state.sp_oauth
    try:
        sp_oauth.get_access_token(code, check_cache=False)
        return JSONResponse({"ok": True})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)})
