"""MP3-Upload: POST /upload — mehrere Dateien, optional direkt als Playlist."""

from __future__ import annotations

import re
from pathlib import Path

import aiofiles
from fastapi import APIRouter, BackgroundTasks, File, Form, HTTPException, Request, UploadFile

from musicbox.audio import reprocess
from musicbox.store.playlist import CATEGORIES

router = APIRouter()

_MAX_SIZE = 200 * 1024 * 1024  # 200 MB pro Datei
_ALLOWED_EXTS = {".mp3", ".flac", ".ogg", ".m4a"}


def _sanitize(name: str) -> str:
    name = Path(name).name
    name = re.sub(r"[^\w\s\-\.]", "", name)
    return name or "upload"


def _natkey(name: str) -> list:
    """Natürliche Sortierung: '01' < '02' < '10', auch ohne führende Nullen."""
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name)]


async def _save_one(file: UploadFile, dest_dir: Path) -> str:
    """Speichert eine Datei, gibt den relativen Track-Ref (kategorie/dateiname) zurück."""
    ext = Path(file.filename or "").suffix.lower()
    if ext not in _ALLOWED_EXTS:
        raise HTTPException(400, f"Dateityp nicht unterstützt: {ext or '?'} ({file.filename})")
    safe_name = _sanitize(file.filename or "upload")
    if not safe_name.lower().endswith(ext):
        safe_name += ext
    dest = dest_dir / safe_name
    size = 0
    async with aiofiles.open(dest, "wb") as f:
        while chunk := await file.read(65536):
            size += len(chunk)
            if size > _MAX_SIZE:
                await f.close()
                dest.unlink(missing_ok=True)
                raise HTTPException(413, f"Datei zu groß (max 200 MB): {safe_name}")
            await f.write(chunk)
    return f"{dest_dir.name}/{safe_name}"


@router.post("/upload")
async def upload_file(
    request: Request,
    background: BackgroundTasks,
    files: list[UploadFile] = File(...),
    playlist_name: str = Form(""),
    label: str = Form(""),
    uid: str = Form(""),
    category: str = Form("musik"),
    cover: UploadFile | None = File(None),
) -> dict:
    settings = request.app.state.settings
    if category not in CATEGORIES:
        category = "musik"

    dest_dir: Path = settings.music_dir / category
    dest_dir.mkdir(parents=True, exist_ok=True)

    # Nur unterstützte Audiodateien übernehmen; Cover-Bilder, .txt, .nfo etc. werden
    # übersprungen (sonst würde ein einziges Nicht-Audio den ganzen Ordner-Upload
    # scheitern lassen). Standard-Reihenfolge: natürlich nach Dateiname (01, 02, … 10).
    named = [f for f in files if (f.filename or "").strip()]
    valid = [f for f in named if Path(f.filename or "").suffix.lower() in _ALLOWED_EXTS]
    skipped = len(named) - len(valid)
    valid.sort(key=lambda f: _natkey(Path(f.filename or "").name))
    tracks: list[str] = []
    for file in valid:
        tracks.append(await _save_one(file, dest_dir))

    if not tracks:
        raise HTTPException(400, "Keine unterstützten Audiodateien im Upload gefunden")

    # Nachbearbeitung im Hintergrund (dekodiert die Dateien → blockiert den
    # Upload-Response nicht): erst Anfangsstille trimmen (wenn aktiviert), dann
    # ReplayGain berechnen. mpv normalisiert beim Abspielen anhand der Tags.
    settings_store = request.app.state.settings_store
    settings_store.reload_if_changed()
    trim = bool(settings_store.data.get("trim_silence", True))
    background.add_task(
        reprocess.process_files, [dest_dir / Path(t).name for t in tracks], trim=trim
    )

    # Playlist anlegen, wenn ein Name gesetzt ist ODER mehrere Dateien hochgeladen wurden
    playlist = None
    if playlist_name.strip() or len(tracks) > 1:
        ps = request.app.state.playlist_store
        ps.load()
        name = playlist_name.strip() or Path(tracks[0]).stem
        playlist = ps.create(name, category, tracks)

    # Optional: Karte direkt zuordnen (auf die Playlist bzw. die Einzeldatei)
    if uid:
        uid_norm = uid.upper().replace(":", "").replace(" ", "")
        ref = playlist["m3u8_path"] if playlist else tracks[0]
        entry = {
            "label": (playlist_name.strip() or label or Path(tracks[0]).stem),
            "type": "local",
            "ref": ref,
        }
        try:
            request.app.state.mapping_store.set(uid_norm, entry)
        except ValueError:
            pass
        # Optionales Cover-Bild für den Sticker speichern (covers/<uid>.<ext>)
        if cover is not None and (cover.filename or "").strip():
            cext = Path(cover.filename or "").suffix.lower()
            if cext in {".jpg", ".jpeg", ".png", ".webp"}:
                covers_dir = settings.music_dir.parent / "covers"
                covers_dir.mkdir(parents=True, exist_ok=True)
                async with aiofiles.open(covers_dir / f"{uid_norm}{cext}", "wb") as cf:
                    while chunk := await cover.read(65536):
                        await cf.write(chunk)

    n = len(tracks)
    target = playlist["name"] if playlist else tracks[0].split("/")[-1]
    return {
        "ok": True,
        "count": n,
        "skipped": skipped,
        "playlist": playlist["name"] if playlist else None,
        "target": target,
        "category": category,
    }
