"""AudioBackend: Abstrakte Basisklasse für Spotify- und Local-Backend."""

from __future__ import annotations

from abc import ABC, abstractmethod


class AudioBackend(ABC):
    @abstractmethod
    async def load(self, ref: str, options: dict) -> None:
        """Lädt Inhalt und startet Wiedergabe."""

    @abstractmethod
    async def play(self) -> None: ...

    @abstractmethod
    async def pause(self) -> None: ...

    @abstractmethod
    async def next_track(self) -> None: ...

    @abstractmethod
    async def prev_track(self) -> None: ...

    @abstractmethod
    async def seek(self, position_ms: int) -> None: ...

    @abstractmethod
    async def set_volume(self, pct: int) -> None:
        """Setzt Lautstärke 0–100."""

    @abstractmethod
    async def get_status(self) -> dict:
        """Gibt {playing, position_ms, track_name} zurück."""

    @abstractmethod
    async def is_available(self) -> bool:
        """Health-Check: Backend erreichbar?"""
