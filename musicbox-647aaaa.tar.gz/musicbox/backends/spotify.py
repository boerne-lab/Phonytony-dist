"""SpotifyBackend: steuert go-librespot via HTTP-API + lauscht WebSocket-Events.

Verifiziert gegen go-librespot v0.7.3 (api-spec.yml):
  - /player/play   {uri, skip_to_uri?, paused}   (NICHT /player/load)
  - /player/resume                                (Wiedergabe fortsetzen)
  - /player/pause | /player/next {uri?} | /player/prev
  - /player/seek   {position}   (Millisekunden; NICHT position_ms)
  - /player/volume {volume}     (0..volume_steps; aus /status gelesen)
  - /player/shuffle_context {shuffle_context}; /player/repeat_context {repeat_context}
  - /status: top-level paused/stopped/volume/volume_steps, track{uri,name,duration}
  - /events: WebSocket (KEIN SSE!)
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Optional

import httpx

from .base import AudioBackend

log = logging.getLogger(__name__)


class SpotifyBackend(AudioBackend):
    def __init__(self, base_url: str) -> None:
        self._base = base_url.rstrip("/")
        self._client = httpx.AsyncClient(base_url=self._base, timeout=5.0)
        self._status: dict = {}
        self._volume_steps: int = 100  # wird aus /status aktualisiert
        self._events_task: Optional[asyncio.Task] = None

    async def load(self, ref: str, options: dict) -> None:
        # go-librespot v0.7: /player/play startet einen Kontext über die URI.
        await self._post("/player/play", {"uri": ref, "paused": False})
        # Shuffle/Repeat sind eigene Endpoints (nicht Teil von /player/play).
        await self._post(
            "/player/shuffle_context", {"shuffle_context": bool(options.get("shuffle", False))}
        )
        repeat = options.get("repeat", "off")
        await self._post("/player/repeat_track", {"repeat_track": repeat == "track"})
        await self._post(
            "/player/repeat_context",
            {"repeat_context": repeat in ("context", "all", "on", True)},
        )

    async def play(self) -> None:
        await self._post("/player/resume")

    async def pause(self) -> None:
        await self._post("/player/pause")

    async def next_track(self) -> None:
        await self._post("/player/next")

    async def prev_track(self) -> None:
        await self._post("/player/prev")

    async def seek(self, position_ms: int) -> None:
        await self._post("/player/seek", {"position": position_ms})

    async def set_volume(self, pct: int) -> None:
        pct = max(0, min(100, pct))
        steps = self._volume_steps or 100
        await self._post("/player/volume", {"volume": round(pct / 100 * steps)})

    async def get_status(self) -> dict:
        try:
            r = await self._client.get("/status")
            if r.status_code == 204:  # keine aktive Session
                return {"playing": False, "position_ms": 0, "track_name": ""}
            r.raise_for_status()
            data = r.json()
            self._status = data
            steps = data.get("volume_steps") or self._volume_steps or 100
            self._volume_steps = steps
            track = data.get("track") or {}
            return {
                "playing": not data.get("paused", True) and not data.get("stopped", True),
                # /status liefert keine laufende Position → 0 (Resume-Position ist für
                # Spotify über die go-librespot-API nicht verfügbar, nur fürs Local-Backend).
                "position_ms": track.get("position", 0),
                "track_name": track.get("name", ""),
                "track_uri": track.get("uri", ""),
                "volume_pct": round(data.get("volume", 0) / steps * 100) if steps else 0,
            }
        except Exception:
            return {"playing": False, "position_ms": 0, "track_name": ""}

    async def is_available(self) -> bool:
        try:
            r = await self._client.get("/status")
            return r.status_code < 500
        except Exception:
            return False

    def start_sse_listener(self, on_event=None) -> None:
        # Name aus Kompatibilitätsgründen beibehalten; nutzt jetzt WebSocket statt SSE.
        self._events_task = asyncio.create_task(
            self._events_loop(on_event), name="spotify-events"
        )

    async def _events_loop(self, on_event=None) -> None:
        """Lauscht go-librespot /events (WebSocket) und reicht JSON-Events weiter."""
        # Lazy-Import: fehlt websockets, bleibt nur der Event-Listener aus statt den
        # ganzen Core zu crashen.
        try:
            import websockets
        except ImportError:
            log.warning("websockets fehlt — Spotify-Event-Listener deaktiviert")
            return

        ws_url = (
            self._base.replace("https://", "wss://").replace("http://", "ws://") + "/events"
        )
        while True:
            try:
                async with websockets.connect(ws_url, ping_interval=20) as ws:
                    log.info("go-librespot WebSocket verbunden: %s", ws_url)
                    async for message in ws:
                        try:
                            event = json.loads(message)
                        except (json.JSONDecodeError, TypeError):
                            continue
                        if on_event:
                            await on_event(event)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.debug("go-librespot WebSocket getrennt (%s), reconnect in 5s", e)
                await asyncio.sleep(5.0)

    async def _post(self, path: str, body: dict | None = None) -> None:
        try:
            r = await self._client.post(path, json=body or {})
            if r.status_code not in (200, 204):
                log.warning("go-librespot %s → %d", path, r.status_code)
        except httpx.RequestError as e:
            log.warning("go-librespot nicht erreichbar: %s", e)

    async def close(self) -> None:
        if self._events_task:
            self._events_task.cancel()
        await self._client.aclose()
