"""Anfangsstille aus lokalen Audiodateien entfernen (verlustfrei wo möglich).

Misst die Stille am Anfang per ffmpeg `silencedetect` und schneidet sie heraus —
für MP3/OGG/M4A per Stream-Copy (kein Qualitätsverlust), für FLAC verlustfrei
re-encodet. Cover (attached_pic) und Tags bleiben erhalten (`-map 0 -map_metadata 0`).
"""

from __future__ import annotations

import logging
import os
import re
import subprocess
from pathlib import Path
from typing import Callable

log = logging.getLogger(__name__)

_THRESHOLD_DB = -50
_DETECT_MIN = 0.3        # Mindestdauer für silencedetect (s)
_MIN_TRIM = 0.5          # erst ab so viel Anfangsstille wird geschnitten (s)

_START_RE = re.compile(r"silence_start:\s*([0-9.]+)")
_END_RE = re.compile(r"silence_end:\s*([0-9.]+)")


def leading_silence_seconds(path, *, threshold_db: int = _THRESHOLD_DB,
                            runner: Callable = subprocess.run) -> float:
    """Dauer der Stille am Dateianfang in Sekunden (0.0, wenn keine/ermittelbar)."""
    try:
        p = runner(
            ["ffmpeg", "-hide_banner", "-nostats", "-i", str(path),
             "-af", f"silencedetect=noise={threshold_db}dB:d={_DETECT_MIN}",
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=300,
        )
    except Exception as e:
        log.debug("silencedetect fehlgeschlagen (%s): %s", path, e)
        return 0.0
    err = getattr(p, "stderr", "") or ""
    starts = [float(m) for m in _START_RE.findall(err)]
    ends = [float(m) for m in _END_RE.findall(err)]
    if not starts or not ends:
        return 0.0
    # Erste erkannte Stille muss am Anfang liegen (≈ 0), sonst keine Anfangsstille.
    if starts[0] > 0.1:
        return 0.0
    return ends[0]


def trim_leading_silence(path, *, min_trim: float = _MIN_TRIM,
                         threshold_db: int = _THRESHOLD_DB,
                         runner: Callable = subprocess.run) -> bool:
    """Schneidet Anfangsstille ≥ min_trim heraus (atomar). True, wenn geschnitten."""
    path = Path(path)
    lead = leading_silence_seconds(path, threshold_db=threshold_db, runner=runner)
    if lead < min_trim:
        return False

    ext = path.suffix.lower()
    tmp = path.with_name(path.stem + ".trim" + ext)
    if ext == ".flac":
        # verlustfrei, sample-genau (accurate seek nach -i) re-encoden
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(path),
               "-ss", f"{lead:.3f}", "-map", "0", "-map_metadata", "0",
               "-c:a", "flac", "-c:v", "copy", str(tmp)]
    else:
        # verlustfreier Stream-Copy (frame-genau), Cover/Tags bleiben erhalten
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{lead:.3f}",
               "-i", str(path), "-map", "0", "-map_metadata", "0", "-c", "copy", str(tmp)]
    try:
        p = runner(cmd, capture_output=True, text=True, timeout=600)
        if getattr(p, "returncode", 1) != 0 or not tmp.exists() or tmp.stat().st_size < 256:
            tmp.unlink(missing_ok=True)
            log.warning("Trim fehlgeschlagen für %s (Original bleibt)", path)
            return False
        os.replace(tmp, path)
        log.info("Anfangsstille getrimmt: %s (−%.2fs)", path.name, lead)
        return True
    except Exception as e:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        log.debug("Trim-Fehler (%s): %s", path, e)
        return False
