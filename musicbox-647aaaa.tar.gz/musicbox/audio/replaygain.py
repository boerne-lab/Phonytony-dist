"""ReplayGain beim Upload (günstig bei der Wiedergabe).

Misst die Lautheit jeder Datei per ffmpeg (EBU R128) und schreibt ein
REPLAYGAIN_TRACK_GAIN-Tag. mpv wendet das Tag beim Abspielen mit minimalem
CPU-Aufwand an (--replaygain=track) → alle lokalen Titel klingen gleich laut.
Läuft im Hintergrund (nach dem Upload-Response), da das Messen die Datei dekodiert.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from pathlib import Path

log = logging.getLogger(__name__)

_TARGET_LUFS = -18.0  # ReplayGain-2.0-Referenzpegel


def measure_gain(path: Path) -> float | None:
    """Integrierte Lautheit per ffmpeg messen, Gain in dB zum Zielpegel zurückgeben."""
    try:
        p = subprocess.run(
            ["ffmpeg", "-hide_banner", "-nostats", "-i", str(path),
             "-af", "loudnorm=print_format=json", "-f", "null", "-"],
            capture_output=True, text=True, timeout=300,
        )
        m = re.search(r'\{[^{}]*"input_i"[^{}]*\}', p.stderr, re.S)
        if not m:
            return None
        i = float(json.loads(m.group(0)).get("input_i"))
        if i <= -70:  # quasi Stille → kein sinnvoller Gain
            return None
        return max(-20.0, min(20.0, _TARGET_LUFS - i))
    except Exception as e:
        log.debug("ReplayGain-Messung fehlgeschlagen (%s): %s", path, e)
        return None


def write_tag(path: Path, gain_db: float) -> bool:
    """REPLAYGAIN_TRACK_GAIN-Tag schreiben (MP3/ID3, FLAC/OGG-Vorbis, best effort sonst)."""
    val = f"{gain_db:.2f} dB"
    try:
        if path.suffix.lower() == ".mp3":
            from mutagen.id3 import ID3, ID3NoHeaderError, TXXX
            try:
                tags = ID3(str(path))
            except ID3NoHeaderError:
                tags = ID3()
            tags.delall("TXXX:REPLAYGAIN_TRACK_GAIN")
            tags.add(TXXX(encoding=3, desc="REPLAYGAIN_TRACK_GAIN", text=[val]))
            tags.save(str(path))
            return True
        from mutagen import File as MFile
        f = MFile(str(path))
        if f is None:
            return False
        f["REPLAYGAIN_TRACK_GAIN"] = val   # Vorbis-Comments (FLAC/OGG)
        f.save()
        return True
    except Exception as e:
        log.debug("ReplayGain-Tag schreiben fehlgeschlagen (%s): %s", path, e)
        return False


def has_gain_tag(path: Path) -> bool:
    """True, wenn die Datei bereits ein REPLAYGAIN_TRACK_GAIN-Tag trägt."""
    try:
        from mutagen import File as MFile
        f = MFile(str(path))
        if f is None or f.tags is None:
            return False
        if Path(path).suffix.lower() == ".mp3":
            return any(str(k).upper().startswith("TXXX:REPLAYGAIN_TRACK_GAIN")
                       for k in f.tags.keys())
        return "replaygain_track_gain" in [str(k).lower() for k in f.tags.keys()]
    except Exception:
        return False


def analyze_files(paths: list) -> None:
    """Für jede Datei Gain messen + Tag schreiben (überspringt fehlende Dateien)."""
    for p in paths:
        p = Path(p)
        if not p.exists():
            continue
        g = measure_gain(p)
        if g is not None and write_tag(p, g):
            log.info("ReplayGain %s: %.2f dB", p.name, g)
