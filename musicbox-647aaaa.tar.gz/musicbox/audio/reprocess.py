"""Audio-Nachbearbeitung: Anfangsstille trimmen + ReplayGain — für Upload und Bibliothek.

Gemeinsamer Kern für (a) den Upload-Hintergrundtask und (b) die nachträgliche Verarbeitung
aller bereits gespeicherten Dateien. Idempotent: Trim greift nur bei Anfangsstille, Gain wird
nur geschrieben, wenn noch kein Tag vorhanden ist.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Callable, Optional

from musicbox.audio import replaygain, silence

log = logging.getLogger(__name__)

_AUDIO_SUFFIXES = {".mp3", ".flac", ".ogg", ".m4a"}
_CATEGORIES = ("musik", "hoerbuch")


def iter_library_files(music_dir) -> list[Path]:
    """Alle Audiodateien in musik/ + hoerbuch/ (sortiert)."""
    files: list[Path] = []
    for cat in _CATEGORIES:
        d = Path(music_dir) / cat
        if d.exists():
            files += sorted(p for p in d.iterdir()
                            if p.is_file() and p.suffix.lower() in _AUDIO_SUFFIXES)
    return files


def process_one(path, *, trim: bool = True, runner: Callable = subprocess.run) -> dict:
    """Eine Datei: (optional) trimmen + ReplayGain, wenn noch nicht getaggt."""
    path = Path(path)
    trimmed = False
    gained = False
    if trim:
        trimmed = silence.trim_leading_silence(path, runner=runner)
    if not replaygain.has_gain_tag(path):
        g = replaygain.measure_gain(path)
        if g is not None and replaygain.write_tag(path, g):
            gained = True
    return {"trimmed": trimmed, "gained": gained}


def process_files(paths, *, trim: bool = True) -> None:
    """Upload-Hintergrundtask: erst trimmen, dann ReplayGain je Datei."""
    for p in paths:
        p = Path(p)
        if p.exists():
            process_one(p, trim=trim)


def reprocess_library(music_dir, *, trim: bool = True,
                      status_cb: Optional[Callable[[dict], None]] = None) -> dict:
    """Über alle Bibliotheksdateien; meldet Fortschritt via status_cb."""
    files = iter_library_files(music_dir)
    total = len(files)
    processed = trimmed = gained = 0
    for i, f in enumerate(files):
        if status_cb:
            status_cb({"done": i, "total": total, "current": f.name})
        r = process_one(f, trim=trim)
        processed += 1
        trimmed += int(r["trimmed"])
        gained += int(r["gained"])
    if status_cb:
        status_cb({"done": total, "total": total, "current": ""})
    return {"processed": processed, "trimmed": trimmed, "gained": gained}
