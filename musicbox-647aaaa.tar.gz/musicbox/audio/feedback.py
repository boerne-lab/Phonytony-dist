"""Audio-Feedback: kurze WAV-Töne via aplay, nicht-blockierend."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

log = logging.getLogger(__name__)

SOUNDS = {
    "startup":      "startup.wav",
    "tag_ok":       "tag_ok.wav",
    "tag_unknown":  "tag_unknown.wav",
    "tag_removed":  "tag_removed.wav",
    "offline":      "offline.wav",
    "error":        "error.wav",
    "volume_max":   "volume_max.wav",
    "volume_min":   "volume_min.wav",
}


class FeedbackPlayer:
    def __init__(self, sounds_dir: Path, alsa_card: str) -> None:
        self._dir = sounds_dir
        self._card = alsa_card
        self._playing = False

    async def play(self, name: str) -> None:
        """Spielt einen Ton, ohne auf das Ende der Wiedergabe zu warten.

        Läuft bereits ein Ton, wird der Aufruf übersprungen (kein Aufstauen) —
        so bleiben z.B. Anschlag-Töne synchron zum schnellen Drehen des Encoders,
        statt die Event-Schleife zu blockieren.
        """
        filename = SOUNDS.get(name)
        if not filename:
            log.warning("Unbekannter Sound: %r", name)
            return
        path = self._dir / filename
        if not path.exists():
            log.debug("Sound-Datei nicht vorhanden: %s", path)
            return
        if self._playing:
            return
        self._playing = True
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            # Kein laufender Loop (z.B. synchroner Kontext) → direkt abspielen
            await self._play_file(path)
        else:
            asyncio.create_task(self._play_file(path))

    async def _play_file(self, path: Path) -> None:
        try:
            proc = await asyncio.create_subprocess_exec(
                "aplay", "-D", "default", str(path),
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
        except Exception:
            log.debug("aplay fehlgeschlagen für %s", path)
        finally:
            self._playing = False
