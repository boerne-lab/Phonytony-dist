#!/usr/bin/env bash
# Erst-Installation der MusicBox auf Raspberry Pi OS Bookworm.
# Aufruf: sudo bash scripts/setup.sh
set -euo pipefail

INSTALL_DIR="/opt/musicbox"
CONFIG_DIR="/etc/musicbox"
DATA_DIR="/var/lib/musicbox"
SERVICE_USER="musicbox"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "=== MusicBox Setup ==="
echo "Repo: $REPO_DIR"
echo "Install: $INSTALL_DIR"

# --- Pakete ---
apt-get update -qq
apt-get install -y \
    python3-pip python3-venv python3-dev python3-lgpio python3-spidev \
    i2c-tools \
    mpv \
    alsa-utils sox libasound2-plugins \
    avahi-daemon libnss-mdns \
    git curl wget

# --- Hardware-Overlays ---
CONFIG_TXT="/boot/firmware/config.txt"
[ -f "$CONFIG_TXT" ] || CONFIG_TXT="/boot/config.txt"

add_config() {
    grep -qF "$1" "$CONFIG_TXT" || echo "$1" >> "$CONFIG_TXT"
}
add_config "dtparam=i2c_arm=on"
add_config "dtparam=i2s=on"
# SPI für RC522 RFID-Reader
add_config "dtparam=spi=on"
# Waveshare WM8960 Audio HAT (WM8960-Codec, I2S + I2C)
add_config "dtoverlay=wm8960-soundcard"
echo "✓ /boot/firmware/config.txt aktualisiert"

# --- Service-User ---
id -u "$SERVICE_USER" &>/dev/null || useradd -r -s /usr/sbin/nologin -m -d "$DATA_DIR" "$SERVICE_USER"
usermod -aG audio,gpio,i2c,spi "$SERVICE_USER" 2>/dev/null || true
echo "✓ User $SERVICE_USER"

# --- go-librespot ---
GOLIBRESPOT_VERSION="0.7.3"
ARCH=$(uname -m)
case "$ARCH" in
    aarch64) GOLIBRESPOT_ARCH="arm64" ;;
    armv7l)  GOLIBRESPOT_ARCH="armv6_rpi" ;;
    *)       GOLIBRESPOT_ARCH="arm64" ;;
esac
# Release wird als .tar.gz ausgeliefert (kein nacktes Binary)
GOLIBRESPOT_URL="https://github.com/devgianlu/go-librespot/releases/download/v${GOLIBRESPOT_VERSION}/go-librespot_linux_${GOLIBRESPOT_ARCH}.tar.gz"
if [ ! -f /usr/local/bin/go-librespot ]; then
    tmpd="$(mktemp -d)"
    wget -qO "$tmpd/go-librespot.tar.gz" "$GOLIBRESPOT_URL"
    tar -xzf "$tmpd/go-librespot.tar.gz" -C "$tmpd"
    install -m 0755 "$tmpd/go-librespot" /usr/local/bin/go-librespot
    rm -rf "$tmpd"
    echo "✓ go-librespot installiert"
else
    echo "✓ go-librespot bereits vorhanden"
fi

# --- Python-Paket ---
rsync -a --delete "$REPO_DIR/" "$INSTALL_DIR/" --exclude='.git' --exclude='venv' --exclude='__pycache__'
# --system-site-packages: lgpio + spidev kommen von apt (python3-lgpio/python3-spidev)
python3 -m venv --system-site-packages "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip -q
"$INSTALL_DIR/venv/bin/pip" install -e "$INSTALL_DIR" -q
echo "✓ Python-Paket installiert"

# --- Verzeichnisse & Konfig ---
mkdir -p "$CONFIG_DIR" "$DATA_DIR/sounds" "$DATA_DIR/music" "$DATA_DIR/tokens" "$DATA_DIR/playlists" "$DATA_DIR/librespot-cache"
cp -n "$REPO_DIR/config/config.toml"        "$CONFIG_DIR/config.toml" 2>/dev/null || true
# go-librespot liest config.yml aus --config_dir (/etc/musicbox)
cp -n "$REPO_DIR/config/go-librespot.yml"   "$CONFIG_DIR/config.yml" 2>/dev/null || true
[ -f "$DATA_DIR/mapping.json" ] || cp "$REPO_DIR/data/mapping.json" "$DATA_DIR/mapping.json"
# .env mit AKTIVEN Pfad-Variablen erzeugen (.env.example hat sie auskommentiert →
# sonst landen Daten unter /opt/musicbox statt /var/lib/musicbox).
if [ ! -f "$CONFIG_DIR/.env" ]; then
    cat > "$CONFIG_DIR/.env" << ENVEOF
MUSICBOX_CONFIG=$CONFIG_DIR/config.toml
MUSICBOX_DATA_DIR=$DATA_DIR
SPOTIFY_CLIENT_ID=
SPOTIFY_REDIRECT_URI=http://127.0.0.1:8080/auth/spotify/callback
ENVEOF
fi
chown -R "$SERVICE_USER:$SERVICE_USER" "$CONFIG_DIR" "$DATA_DIR" "$INSTALL_DIR"
echo "✓ Verzeichnisse erstellt"

# --- Sounds generieren ---
bash "$REPO_DIR/scripts/generate_sounds.sh" "$DATA_DIR/sounds"

# --- ALSA-Standardkarte ---
cat > /etc/asound.conf << 'EOF'
# dmix: Software-Mixing, damit go-librespot, mpv und Feedback-Töne das WM8960
# gleichzeitig nutzen können (sonst "Device or resource busy").
pcm.!default {
    type plug
    slave.pcm "dmixer"
}
pcm.dmixer {
    type dmix
    ipc_key 1024
    slave {
        pcm "hw:wm8960soundcard"
        rate 44100
        channels 2
        format S16_LE
        period_size 1024
        buffer_size 8192
    }
}
ctl.!default {
    type hw
    card wm8960soundcard
}
EOF
echo "✓ /etc/asound.conf gesetzt"

# --- Systemd ---
cp "$REPO_DIR/systemd/"*.service /etc/systemd/system/
# Pfade in Services auf DATA_DIR anpassen
sed -i "s|/var/lib/musicbox|$DATA_DIR|g" /etc/systemd/system/musicbox-*.service || true
systemctl daemon-reload
systemctl enable systemd-timesyncd go-librespot musicbox-alsa-init musicbox-core musicbox-web
echo "✓ Services registriert"

# --- Avahi (musicbox.local) ---
hostnamectl set-hostname musicbox 2>/dev/null || true
systemctl enable avahi-daemon 2>/dev/null || true

echo ""
echo "======================================"
echo "  Setup abgeschlossen!"
echo "  NEUSTART erforderlich:"
echo "    sudo reboot"
echo ""
echo "  Danach:"
echo "  1. http://musicbox.local:8080/auth/spotify/start"
echo "     → Spotify OAuth durchführen"
echo "  2. Tag auflegen → Web-UI zum Zuweisen öffnen"
echo "======================================"
