#!/usr/bin/env bash
# Generiert WAV-Feedback-Töne via sox.
# Aufruf: bash scripts/generate_sounds.sh [OUTPUT_DIR]
set -euo pipefail

DIR="${1:-data/sounds}"
mkdir -p "$DIR"

# Prüfe ob sox installiert ist
if ! command -v sox &>/dev/null; then
  echo "sox nicht gefunden. Installation: sudo apt install sox"
  exit 1
fi

# Angenehmere Töne: pluck-Timbre (string-artig), sanfte Fades, leichter Hall,
# auf gleichmäßigen Pegel normalisiert. Dateinamen unverändert (siehe feedback.py).
sox -n -r 44100 -c 2 "$DIR/startup.wav"      synth 0.18 pluck C5 : synth 0.18 pluck E5 : synth 0.30 pluck G5 \
    fade t 0 0 0.12 reverb 30 gain -n -3
sox -n -r 44100 -c 2 "$DIR/tag_ok.wav"       synth 0.16 pluck C5 : synth 0.26 pluck G5 \
    fade t 0 0 0.10 reverb 25 gain -n -3
sox -n -r 44100 -c 2 "$DIR/tag_unknown.wav"  synth 0.20 pluck E5 : synth 0.28 pluck C5 \
    fade t 0 0 0.10 reverb 20 gain -n -4
sox -n -r 44100 -c 2 "$DIR/tag_removed.wav"  synth 0.22 pluck G4 \
    fade t 0 0 0.12 reverb 18 gain -n -5
sox -n -r 44100 -c 2 "$DIR/offline.wav"      synth 0.20 pluck G4 : synth 0.20 pluck E4 : synth 0.32 pluck C4 \
    fade t 0 0 0.14 reverb 22 gain -n -4
sox -n -r 44100 -c 2 "$DIR/error.wav"        synth 0.40 pluck A3 \
    tremolo 9 40 fade t 0 0 0.15 reverb 15 gain -n -4
sox -n -r 44100 -c 2 "$DIR/volume_max.wav"   synth 0.12 pluck E6 fade t 0 0 0.06 gain -n -5
sox -n -r 44100 -c 2 "$DIR/volume_min.wav"   synth 0.12 pluck C4 fade t 0 0 0.06 gain -n -5

echo "Sounds generiert in: $DIR"
ls -lh "$DIR"
