#!/usr/bin/env bash
# Veröffentlicht den aktuellen Stand als Update-Artefakt im öffentlichen Dist-Repo.
# Voraussetzung: gh ist authentifiziert (boerne-lab).
# Aufruf: bash scripts/release.sh [--dry-run]
set -euo pipefail

# Immer aus dem Repo-Root arbeiten (relative tar-/git-Pfade), egal von wo aufgerufen.
cd "$(cd "$(dirname "$0")/.." && pwd)"

DIST_REPO="boerne-lab/Phonytony-dist"
DRY="${1:-}"
SHA="$(git rev-parse --short HEAD)"
BRANCH="$(git rev-parse --abbrev-ref HEAD)"
BUILT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
WORK="$(mktemp -d)"
TARBALL="musicbox-${SHA}.tar.gz"

echo ">> Packe ${TARBALL}"
tar -czf "$WORK/$TARBALL" \
  --exclude='.git' --exclude='venv' --exclude='data' --exclude='config' \
  --exclude='docs' --exclude='tests' --exclude='__pycache__' --exclude='*.pyc' \
  musicbox scripts systemd pyproject.toml

SHA256="$(sha256sum "$WORK/$TARBALL" | cut -d' ' -f1)"
cat > "$WORK/latest.json" <<JSON
{"version":"${SHA}","built_at":"${BUILT}","sha256":"${SHA256}","tarball":"${TARBALL}","branch":"${BRANCH}"}
JSON

echo ">> latest.json:"; cat "$WORK/latest.json"

if [ "$DRY" = "--dry-run" ]; then
  echo ">> Dry-Run: $WORK"; ls -l "$WORK"; exit 0
fi

# Dist-Repo bereitstellen
CLONE="$(mktemp -d)"
if ! gh repo view "$DIST_REPO" >/dev/null 2>&1; then
  gh repo create "$DIST_REPO" --public
fi
gh repo clone "$DIST_REPO" "$CLONE" >/dev/null 2>&1
cp "$WORK/$TARBALL" "$WORK/latest.json" "$CLONE/"
(
  cd "$CLONE"
  git checkout -B main >/dev/null 2>&1        # Branch muss main heißen (raw-URL)
  # Nur die letzten 5 Tarballs behalten
  ls -1t musicbox-*.tar.gz 2>/dev/null | tail -n +6 | xargs -r git rm -q -- 2>/dev/null || true
  git add -A
  git -c user.name="boerne-lab" -c user.email="thomasjohnpostfach@gmail.com" \
      commit -q -m "Release ${SHA} (${BRANCH})"
  git push -u origin main -q
)
echo ">> Veröffentlicht: https://raw.githubusercontent.com/${DIST_REPO}/main/latest.json"
