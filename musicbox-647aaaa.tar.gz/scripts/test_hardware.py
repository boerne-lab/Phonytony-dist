#!/usr/bin/env python3
"""Interaktiver Hardware-Test für PN532, GPIO, ALSA."""

import sys
import time


def test_rfid():
    print("=== RFID-Test (RC522 via SPI) ===")
    print("Drücke Ctrl+C zum Beenden.\n")
    try:
        import board
        import busio
        from digitalio import DigitalInOut
        from adafruit_mfrc522 import MFRC522

        spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
        cs  = DigitalInOut(board.CE0)
        rst = DigitalInOut(board.D4)
        reader = MFRC522(spi, cs, rst)
        reader.set_antenna_gain(0x07 << 4)
        print("RC522 bereit. Jetzt Tag auflegen …")
        last = None
        while True:
            (status, _) = reader.request(reader.REQIDL)
            if status == reader.OK:
                (status, uid) = reader.anticoll()
                if status == reader.OK:
                    uid_str = bytes(uid[:4]).hex().upper()
                    if uid_str != last:
                        print(f"  UID: {uid_str}")
                        last = uid_str
            else:
                last = None
    except KeyboardInterrupt:
        print("\nTest beendet.")
    except Exception as e:
        print(f"Fehler: {e}")
        print("Prüfe: ls /dev/spi* → sollte /dev/spidev0.0 anzeigen")
        print("       dtparam=spi=on in /boot/firmware/config.txt gesetzt?")


def test_gpio():
    print("=== GPIO-Test (Buttons + Encoder) ===")
    print("Drücke Ctrl+C zum Beenden.\n")
    try:
        from gpiozero import Button, RotaryEncoder

        from musicbox.settings import load_settings
        s = load_settings()

        btns = {
            "Play/Pause": Button(s.gpio_play_pause, pull_up=True, bounce_time=0.05),
            "Next":       Button(s.gpio_next,       pull_up=True, bounce_time=0.05),
            "Prev":       Button(s.gpio_prev,       pull_up=True, bounce_time=0.05),
        }
        for name, btn in btns.items():
            btn.when_pressed = lambda n=name: print(f"  Button gedrückt: {n}")

        enc = RotaryEncoder(s.gpio_enc_clk, s.gpio_enc_dt, max_steps=0)
        enc.when_rotated_clockwise = lambda: print("  Encoder: +1")
        enc.when_rotated_counter_clockwise = lambda: print("  Encoder: -1")

        print("Buttons und Encoder bereit. Jetzt drücken/drehen …")
        from signal import pause
        pause()
    except KeyboardInterrupt:
        print("\nTest beendet.")
    except Exception as e:
        print(f"Fehler: {e}")


def test_audio():
    print("=== Audio-Test (ALSA) ===")
    import subprocess

    from musicbox.settings import load_settings
    s = load_settings()
    print(f"Karte: {s.alsa_card}")
    result = subprocess.run(["aplay", "-l"], capture_output=True, text=True)
    if s.alsa_card.replace("soundcard", "-soundcard") in result.stdout or s.alsa_card in result.stdout:
        print("✓ DAC-Karte gefunden in aplay -l")
    else:
        print("✗ Karte nicht in aplay -l gefunden!")
        print(result.stdout)
        return

    print("Spiele 440 Hz Ton …")
    subprocess.run([
        "speaker-test", "-c", "2", "-D", f"hw:{s.alsa_card},0",
        "-t", "sine", "-f", "440", "-l", "1"
    ])
    print("✓ Audio-Test abgeschlossen")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    if cmd in ("rfid", "all"):
        test_rfid()
    if cmd in ("gpio", "all"):
        test_gpio()
    if cmd in ("audio", "all"):
        test_audio()
