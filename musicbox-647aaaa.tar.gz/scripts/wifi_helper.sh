#!/usr/bin/env bash
# Root-Helfer für die WLAN-Verwaltung. Reicht nur an das geprüfte Python-Modul durch.
# Aufruf (vom Web via sudo): wifi_helper.sh <list|scan|add|remove|set-ap> [args…]
set -euo pipefail
exec /opt/musicbox/venv/bin/python -m musicbox.maintenance.wifi "$@"
