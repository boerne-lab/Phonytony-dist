"""Lokaler Spiegel der Spotify-Cover-Bilder für die Weboberfläche.

Die Spotify-API liefert zu Playlists/Alben nur Bild-URLs auf Spotifys CDN. Ohne
diesen Spiegel lädt der Browser jedes Cover einzeln über die WLAN-Strecke des
Pi Zero — und ohne Netz zeigt das Karten-Grid gar keine Bilder mehr. Hier wird
jedes Cover einmal geholt und danach lokal ausgeliefert.

Nur Cover-Thumbnails, kein Audio. Abgerufen wird ausschließlich von Spotifys
eigenen CDN-Hosts — die URL kommt aus einem Query-Parameter, ein offener Proxy
wäre sonst ein Einfallstor ins lokale Netz.
"""

from __future__ import annotations

import hashlib
import logging
from pathlib import Path
from typing import Optional
from urllib.parse import quote, urlparse

log = logging.getLogger(__name__)

# Spotify verteilt Cover über mehrere CDN-Domains (i./mosaic./thisis-images.scdn.co,
# image-cdn-*.spotifycdn.com …) — Subdomains variieren, die Basis-Domains nicht.
_ALLOWED_SUFFIXES = (".scdn.co", ".spotifycdn.com")

_MAX_BYTES = 5 * 1024 * 1024
_TIMEOUT_S = 10.0


def is_allowed(url: str) -> bool:
    """Nur https-URLs auf Spotifys Bild-CDNs."""
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    if parsed.scheme != "https" or not parsed.hostname:
        return False
    host = parsed.hostname.lower()
    return any(host.endswith(suffix) for suffix in _ALLOWED_SUFFIXES)


def proxy_url(url: str) -> str:
    """URL, unter der die Weboberfläche das Cover abruft.

    Spotify-CDN-URLs laufen über den lokalen Spiegel. Alles andere wird
    unverändert durchgereicht — der Browser lädt es dann direkt, wie vor dem
    Spiegel auch. Ein fehlender Spiegel darf nie zu einem fehlenden Cover führen.
    """
    if not url:
        return ""
    if not is_allowed(url):
        return url
    return "/api/spotify/image?url=" + quote(url, safe="")


def cached_path(cache_dir: Path, url: str) -> Path:
    return Path(cache_dir) / f"{hashlib.sha256(url.encode()).hexdigest()[:32]}.img"


def fetch_bytes(url: str) -> bytes:
    """Bild von Spotifys CDN laden. Einzige Netzwerkgrenze des Moduls."""
    import httpx

    with httpx.Client(timeout=_TIMEOUT_S, follow_redirects=True) as client:
        r = client.get(url)
        r.raise_for_status()
        return r.content[:_MAX_BYTES]


def get(cache_dir: Path, url: str) -> Optional[bytes]:
    """Bild-Bytes aus dem lokalen Spiegel, sonst einmalig von Spotify.

    Cover ändern sich praktisch nie — ein einmal gespiegeltes Bild bleibt gültig
    und wird auch dann geliefert, wenn Spotify gerade nicht erreichbar ist.
    """
    if not is_allowed(url):
        return None

    path = cached_path(cache_dir, url)
    try:
        data = path.read_bytes()
        if data:
            return data
    except OSError:
        pass

    try:
        data = fetch_bytes(url)
    except Exception as e:
        log.debug("Spotify-Cover nicht ladbar (%s): %s", url, e)
        return None
    if not data:
        return None

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".img.tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
    except OSError as e:
        log.debug("Spotify-Cover-Cache schreiben fehlgeschlagen: %s", e)
    return data


def clear(cache_dir: Path) -> int:
    """Alle gespiegelten Bilder löschen; gibt die Anzahl zurück."""
    cleared = 0
    try:
        entries = list(Path(cache_dir).glob("*.img"))
    except OSError:
        return 0
    for p in entries:
        try:
            p.unlink()
            cleared += 1
        except OSError:
            pass
    return cleared
