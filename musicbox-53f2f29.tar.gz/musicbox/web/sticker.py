"""Sticker-Generator: kreditkartengroßer Aufkleber (Cover + Titel) als PNG/PDF.

Format ISO/IEC 7810 ID-1 (Kreditkarte) hochkant: 54 × 85,6 mm bei 300 DPI.
Cover quadratisch oben, Titel darunter (zentriert, auto-umgebrochen).
Metadaten möglichst automatisch: Spotify-API für Spotify-Karten, ID3/eingebettetes
Cover für lokale MP3s, optional ein hochgeladenes Cover (covers/<uid>.*).
"""

from __future__ import annotations

import io
import logging
from pathlib import Path
from typing import Optional

from PIL import Image, ImageDraw, ImageFont

log = logging.getLogger(__name__)

_DPI = 300
_MM = _DPI / 25.4
_W = round(54 * _MM)        # ~638 px (54 mm breit)
_H = round(85.6 * _MM)      # ~1011 px (85,6 mm hoch)
_MARGIN = round(3 * _MM)
_FONTS = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]


def _font(size: int):
    for p in _FONTS:
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def _wrap(draw, text, font, max_w):
    lines, cur = [], ""
    for word in text.split():
        t = (cur + " " + word).strip()
        if not cur or draw.textlength(t, font=font) <= max_w:
            cur = t
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines


def render(title: str, cover: Optional[Image.Image], fmt: str = "png",
           online: bool = False) -> bytes:
    img = Image.new("RGB", (_W, _H), "white")
    draw = ImageDraw.Draw(img)
    inner = _W - 2 * _MARGIN
    y = _MARGIN

    # Cover quadratisch oben (mittig zugeschnitten)
    if cover is not None:
        c = cover.convert("RGB")
        s = min(c.size)
        c = c.crop((
            (c.width - s) // 2, (c.height - s) // 2,
            (c.width + s) // 2, (c.height + s) // 2,
        )).resize((inner, inner))
        img.paste(c, (_MARGIN, y))
    else:
        draw.rectangle([_MARGIN, y, _MARGIN + inner, y + inner], fill=(225, 225, 225))
        draw.text((_W // 2, y + inner // 2), "♪", fill=(150, 150, 150),
                  font=_font(56), anchor="mm")
    y += inner + _MARGIN + round(2 * _MM)

    # Titel darunter — Schriftgröße automatisch verkleinern, bis es passt
    avail_h = _H - y - _MARGIN
    font = _font(16)
    lines = _wrap(draw, title, font, inner)
    lh = 20
    for size in range(46, 15, -3):
        font = _font(size)
        lines = _wrap(draw, title, font, inner)
        lh = size + round(size * 0.25)
        if len(lines) * lh <= avail_h:
            break
    ty = y + max(0, (avail_h - len(lines) * lh) // 2)
    for line in lines:
        draw.text((_W // 2, ty), line, fill=(0, 0, 0), font=font, anchor="ma")
        ty += lh

    # Online-Badge unten rechts (Spotify-Karten funktionieren nur mit Internet)
    if online:
        bf = _font(20)
        label = "online"
        tw = draw.textlength(label, font=bf)
        dot = 12
        padx = round(2.5 * _MM)
        bh = 30
        bw = round(padx + dot + 6 + tw + padx)
        bx = _W - _MARGIN - bw
        by = _H - _MARGIN - bh
        draw.rounded_rectangle([bx, by, bx + bw, by + bh], radius=bh // 2,
                               fill=(29, 185, 84))  # Spotify-Grün
        cy = by + bh // 2
        draw.ellipse([bx + padx, cy - dot // 2, bx + padx + dot, cy + dot // 2], fill="white")
        draw.text((bx + padx + dot + 6, cy), label, fill="white", font=bf, anchor="lm")

    buf = io.BytesIO()
    if fmt == "pdf":
        img.save(buf, "PDF", resolution=_DPI)
    else:
        img.save(buf, "PNG", dpi=(_DPI, _DPI))
    return buf.getvalue()


def _http_image(url: str) -> Optional[Image.Image]:
    try:
        import httpx
        r = httpx.get(url, timeout=10.0, follow_redirects=True)
        r.raise_for_status()
        return Image.open(io.BytesIO(r.content))
    except Exception as e:
        log.debug("Cover-Download fehlgeschlagen: %s", e)
        return None


def _id3_cover_title(path: Path):
    """Album/Titel + eingebettetes Cover aus einer Audiodatei (ID3/MP4/FLAC)."""
    title, cover = None, None
    try:
        from mutagen import File as MFile
        mf = MFile(str(path))
        if mf is None:
            return None, None
        tags = mf.tags or {}
        for key in ("album", "TALB", "\xa9alb", "title", "TIT2", "\xa9nam"):
            v = tags.get(key)
            if v:
                title = str(v[0] if isinstance(v, list) else v)
                break
        data = None
        try:
            if hasattr(mf.tags, "getall"):
                apics = mf.tags.getall("APIC")
                if apics:
                    data = apics[0].data
        except Exception:
            pass
        if data is None and "covr" in tags:                 # MP4/M4A
            data = bytes(tags["covr"][0])
        if data is None and getattr(mf, "pictures", None):  # FLAC
            data = mf.pictures[0].data
        if data:
            cover = Image.open(io.BytesIO(data))
    except Exception as e:
        log.debug("ID3-Lesen fehlgeschlagen: %s", e)
    return title, cover


_COVER_BASENAMES = ("cover", "folder", "front", "album", "albumart", "albumartlarge")
_IMG_EXTS = (".jpg", ".jpeg", ".png", ".webp")


def _sidecar_cover(directory: Path) -> Optional[Image.Image]:
    """Sucht ein Cover-Bild (cover.jpg/folder.jpg/…) im Ordner der Audiodatei."""
    try:
        if not directory.is_dir():
            return None
        imgs = {p.name.lower(): p for p in directory.iterdir()
                if p.is_file() and p.suffix.lower() in _IMG_EXTS}
        if not imgs:
            return None
        for base in _COVER_BASENAMES:                # bevorzugte Namen zuerst
            for ext in _IMG_EXTS:
                if base + ext in imgs:
                    return Image.open(imgs[base + ext])
        return Image.open(sorted(imgs.values())[0])  # sonst irgendein Bild
    except Exception as e:
        log.debug("Sidecar-Cover-Suche fehlgeschlagen (%s): %s", directory, e)
        return None


def cover_title_for_card(card: dict, uid: str, *, sp_oauth=None,
                         music_dir: Optional[Path] = None,
                         covers_dir: Optional[Path] = None):
    """Ermittelt (Titel, Cover) für eine Karte: hochgeladenes Bild > Spotify/ID3 > Label."""
    title = card.get("label") or uid
    cover = None

    # 1) Explizit hochgeladenes Cover hat Vorrang
    if covers_dir:
        for ext in (".jpg", ".jpeg", ".png", ".webp"):
            p = covers_dir / f"{uid}{ext}"
            if p.exists():
                try:
                    cover = Image.open(p)
                except Exception:
                    pass
                break

    if card.get("type") == "spotify" and sp_oauth is not None:
        try:
            import spotipy
            sp = spotipy.Spotify(auth_manager=sp_oauth)
            ref = card.get("ref", "")
            imgs = []
            if ":album:" in ref:
                a = sp.album(ref); title = a.get("name", title); imgs = a.get("images", [])
            elif ":playlist:" in ref:
                pl = sp.playlist(ref); title = pl.get("name", title); imgs = pl.get("images", [])
            elif ":track:" in ref:
                tr = sp.track(ref); title = tr.get("name", title)
                imgs = tr.get("album", {}).get("images", [])
            if cover is None and imgs:
                cover = _http_image(imgs[0]["url"])
        except Exception as e:
            log.debug("Spotify-Metadaten fehlgeschlagen: %s", e)

    elif card.get("type") == "spotify_queue" and sp_oauth is not None and card.get("tracks"):
        try:
            import spotipy
            sp = spotipy.Spotify(auth_manager=sp_oauth)
            tr = sp.track(card["tracks"][0])
            imgs = tr.get("album", {}).get("images", [])
            if cover is None and imgs:
                cover = _http_image(imgs[0]["url"])
        except Exception as e:
            log.debug("Cover-Ermittlung für spotify_queue fehlgeschlagen: %s", e)

    elif card.get("type") == "local":
        ref = card.get("ref", "")
        path = Path(ref)
        if not path.is_absolute() and music_dir:
            path = music_dir / ref
        try:
            if path.suffix.lower() == ".m3u8" and path.exists():
                for line in path.read_text().splitlines():
                    line = line.strip()
                    if line and not line.startswith("#"):
                        cand = Path(line)
                        path = cand if cand.is_absolute() else (music_dir / line if music_dir else cand)
                        break
        except Exception:
            pass
        t, c = _id3_cover_title(path)
        if t:
            title = t
        if cover is None and c is not None:
            cover = c
        # Kein eingebettetes Cover? Nach cover.jpg/folder.jpg im Albumordner suchen
        # (viele Rips/Hörbücher legen das Bild separat ab statt es einzubetten).
        if cover is None:
            cover = _sidecar_cover(path.parent)

    return title, cover
