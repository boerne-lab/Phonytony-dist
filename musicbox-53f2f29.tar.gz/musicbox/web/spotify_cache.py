"""Persistenter Datei-Cache für Spotify-Metadaten (Listen, Tracklisten, Cover-URLs).

Die Weboberfläche fragt bei jedem Aufruf der Bibliothek frisch bei Spotify an —
auf dem Pi Zero über WLAN sind das spürbare Wartezeiten, und ohne Netz bleibt die
Kartenverwaltung ganz leer. Dieser Cache legt die normalisierten Antworten als
JSON ab und liefert sie bei einem API-Fehler notfalls auch veraltet aus
(``read_stale``), damit die Karten weiter verwaltbar bleiben.

Nur Metadaten — kein Audio.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger(__name__)


def key_for(kind: str, params: dict) -> str:
    """Stabiler, dateinamentauglicher Key aus Art der Abfrage + Parametern."""
    canonical = json.dumps({"kind": kind, "params": params}, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode()).hexdigest()[:32]


def entry_path(cache_dir: Path, key: str) -> Path:
    return Path(cache_dir) / f"{key}.json"


def read(cache_dir: Path, key: str, *, max_age_s: float) -> Optional[Any]:
    """Payload, wenn vorhanden und jünger als max_age_s — sonst None."""
    path = entry_path(cache_dir, key)
    try:
        age = time.time() - path.stat().st_mtime
    except OSError:
        return None
    if age > max_age_s:
        return None
    return _load(path)


def read_stale(cache_dir: Path, key: str) -> Optional[Any]:
    """Payload unabhängig vom Alter — Fallback, wenn Spotify nicht erreichbar ist."""
    return _load(entry_path(cache_dir, key))


def write(cache_dir: Path, key: str, payload: Any) -> None:
    """Payload atomar ablegen. Schlägt das fehl, ist das kein Fehler nach außen."""
    path = entry_path(cache_dir, key)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload))
        tmp.replace(path)
    except (OSError, TypeError, ValueError) as e:
        log.debug("Spotify-Cache schreiben fehlgeschlagen: %s", e)


def clear(cache_dir: Path) -> int:
    """Alle Einträge löschen; gibt die Anzahl der gelöschten Dateien zurück."""
    cleared = 0
    try:
        entries = list(Path(cache_dir).glob("*.json"))
    except OSError:
        return 0
    for p in entries:
        try:
            p.unlink()
            cleared += 1
        except OSError:
            pass
    return cleared


def _load(path: Path) -> Optional[Any]:
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None
