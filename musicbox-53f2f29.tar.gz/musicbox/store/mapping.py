"""MappingStore: CRUD für mapping.json, atomisches Schreiben."""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from typing import Optional


_REQUIRED_CARD_KEYS = {"type", "ref"}
_VALID_TYPES = {"spotify", "local", "spotify_queue"}


class MappingStore:
    def __init__(self, path: Path) -> None:
        self._path = path
        self._data: dict = {"version": 1, "defaults": {}, "cards": {}, "library": {}}
        self._mtime: float = 0.0

    def load(self) -> None:
        if not self._path.exists():
            self._save()
            return
        with open(self._path) as f:
            self._data = json.load(f)
        self._mtime = self._path.stat().st_mtime

    def reload_if_changed(self) -> bool:
        try:
            mtime = self._path.stat().st_mtime
        except FileNotFoundError:
            return False
        if mtime > self._mtime:
            self.load()
            return True
        return False

    def get(self, uid: str) -> Optional[dict]:
        card = self._data.get("cards", {}).get(uid)
        if card is None:
            return None
        return {**self._data.get("defaults", {}), **card}

    def all_cards(self) -> dict:
        return dict(self._data.get("cards", {}))

    def defaults(self) -> dict:
        return dict(self._data.get("defaults", {}))

    def set(self, uid: str, entry: dict) -> None:
        entry = self._with_synthesized_ref(uid, entry)
        self._validate_entry(entry)
        self._data.setdefault("cards", {})[uid] = entry
        self._save()

    def delete(self, uid: str) -> bool:
        cards = self._data.get("cards", {})
        if uid not in cards:
            return False
        del cards[uid]
        self._save()
        return True

    @staticmethod
    def _with_synthesized_ref(key: str, entry: dict) -> dict:
        """spotify_queue-Einträge brauchen intern ein `ref`-Feld (für die
        bestehende (type, ref)-Gruppierungs-/Zuweisungslogik), liefern aber
        selbst keins — wird hier deterministisch aus dem Schlüssel (UID
        oder lib_id) synthetisiert, falls nicht schon vorhanden (z.B. beim
        Kopieren via assign_to_card, wo der Ref schon aus der Bibliothek
        mitkommt)."""
        if entry.get("type") == "spotify_queue" and not entry.get("ref"):
            entry = {**entry, "ref": f"spotify_queue:{key}"}
        return entry

    @staticmethod
    def _validate_entry(entry: dict) -> None:
        missing = _REQUIRED_CARD_KEYS - entry.keys()
        if missing:
            raise ValueError(f"Pflichtfelder fehlen: {missing}")
        if entry["type"] not in _VALID_TYPES:
            raise ValueError(f"Ungültiger type: {entry['type']!r}")
        if entry["type"] == "spotify_queue" and not entry.get("tracks"):
            raise ValueError("spotify_queue benötigt eine nicht-leere 'tracks'-Liste")

    # ── Bibliothek: Inhalte ohne Karte, später auf eine UID verknüpfbar ─────

    def library_all(self) -> dict:
        return dict(self._data.get("library", {}))

    def library_get(self, lib_id: str) -> Optional[dict]:
        entry = self._data.get("library", {}).get(lib_id)
        if entry is None:
            return None
        return {**self._data.get("defaults", {}), **entry}

    def library_set(self, lib_id: str, entry: dict) -> None:
        entry = self._with_synthesized_ref(lib_id, entry)
        self._validate_entry(entry)
        self._data.setdefault("library", {})[lib_id] = entry
        self._save()

    def library_find_by_ref(self, entry_type: str, ref: str) -> Optional[str]:
        """Liefert die lib_id eines bestehenden Bibliothekseintrags mit
        identischem type+ref, falls vorhanden — verhindert Dubletten
        beim erneuten Hinzufügen desselben Inhalts (z.B. per erneuter
        Spotify-Suche nach bereits vorhandenem Inhalt)."""
        for lib_id, entry in self._data.get("library", {}).items():
            if entry.get("type") == entry_type and entry.get("ref") == ref:
                return lib_id
        return None

    def library_create(self, entry: dict) -> str:
        lib_id = uuid.uuid4().hex[:12]
        self.library_set(lib_id, entry)
        return lib_id

    def library_delete(self, lib_id: str) -> bool:
        library = self._data.get("library", {})
        if lib_id not in library:
            return False
        del library[lib_id]
        self._save()
        return True

    def assign_to_card(self, uid: str, lib_id: str) -> None:
        """Kopiert einen Bibliothekseintrag auf eine Karten-UID. Der Bibliothekseintrag
        bleibt erhalten und kann auch weiteren Karten zugewiesen werden."""
        entry = self._data.get("library", {}).get(lib_id)
        if entry is None:
            raise ValueError(f"Bibliothekseintrag nicht gefunden: {lib_id!r}")
        self.set(uid, dict(entry))

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._data, indent=2, ensure_ascii=False))
        os.replace(tmp, self._path)
        self._mtime = self._path.stat().st_mtime
