#!/usr/bin/env bash
# Deployt einen gestageten Stand nach /opt/musicbox, installiert/aktiviert die
# System-Teile (Self-Update + WLAN-Onboarding), generiert Sounds und startet neu.
# Auf der Box als root ausführen:
#
#   sudo bash /home/pi/musicbox-deploy/scripts/box_deploy.sh
#
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "FEHLER: bitte mit sudo ausführen:  sudo bash $0" >&2
  exit 1
fi

SRC="${1:-/home/pi/musicbox-deploy}"
DEST="/opt/musicbox"
DATA="${MUSICBOX_DATA_DIR:-/var/lib/musicbox}"
OWNER="musicbox:musicbox"

echo ">> Sync $SRC/ -> $DEST/"
# Eigentümer/Gruppe der Quelle (pi) NICHT übernehmen, sondern direkt musicbox setzen.
rsync -rlptD --delete --chown="$OWNER" \
  --exclude '.git' --exclude 'venv' --exclude 'data' --exclude 'config' \
  --exclude '__pycache__' --exclude '*.pyc' --exclude '.pytest_cache' \
  "$SRC"/ "$DEST"/
chown -R "$OWNER" "$DEST"

# Installierte Version (für Self-Update-Vergleich)
if [ -f "$SRC/VERSION" ]; then
  cp "$SRC/VERSION" "$DEST/VERSION"
else
  echo "deploy" > "$DEST/VERSION"
fi
chown "$OWNER" "$DEST/VERSION"

echo ">> systemd-Units installieren"
cp "$DEST/systemd/"*.service /etc/systemd/system/
cp "$DEST/systemd/"*.timer  /etc/systemd/system/ 2>/dev/null || true
systemctl daemon-reload

echo ">> sudoers-Drop-ins (Update + WLAN + Shutdown)"
install -m0440 "$DEST/systemd/musicbox-update.sudoers" /etc/sudoers.d/musicbox-update
install -m0440 "$DEST/systemd/musicbox-wifi.sudoers"   /etc/sudoers.d/musicbox-wifi
install -m0440 "$DEST/systemd/musicbox-shutdown.sudoers" /etc/sudoers.d/musicbox-shutdown
visudo -cf /etc/sudoers.d/musicbox-update >/dev/null
visudo -cf /etc/sudoers.d/musicbox-wifi   >/dev/null
visudo -cf /etc/sudoers.d/musicbox-shutdown >/dev/null

echo ">> WLAN-Onboarding: AP-Profil, Captive-DNS, tmpfiles"
install -m600 -o root -g root "$DEST/systemd/musicbox-ap.nmconnection" \
  /etc/NetworkManager/system-connections/musicbox-ap.nmconnection
mkdir -p /etc/NetworkManager/dnsmasq-shared.d
cp "$DEST/systemd/captive-dnsmasq.conf" /etc/NetworkManager/dnsmasq-shared.d/captive.conf
cp "$DEST/systemd/musicbox-tmpfiles.conf" /etc/tmpfiles.d/musicbox.conf
systemd-tmpfiles --create /etc/tmpfiles.d/musicbox.conf || true
nmcli connection reload || true

echo ">> Bestätigungstöne neu generieren -> $DATA/sounds"
bash "$DEST/scripts/generate_sounds.sh" "$DATA/sounds"
chown -R "$OWNER" "$DATA/sounds"

echo ">> Dienste aktivieren/neu starten"
systemctl enable musicbox-update.timer musicbox-netwatch >/dev/null 2>&1 || true
systemctl restart musicbox-core musicbox-web
systemctl start  musicbox-update.timer musicbox-netwatch || true
sleep 2
for u in musicbox-core musicbox-web musicbox-netwatch; do
  printf "  %-18s " "$u:"; systemctl is-active "$u" || true
done
printf "  %-18s " "musicbox-update.timer:"; systemctl is-active musicbox-update.timer || true

echo ">> Rauchtest"
# Auf den Web-Start warten (uvicorn braucht auf dem Pi Zero ein paar Sekunden)
for _ in $(seq 1 20); do
  curl -s -o /dev/null "http://localhost:8080/settings" && break
  sleep 1
done
for p in /mappings /assign /settings /playlists /wifi; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:8080$p" || echo "ERR")
  echo "  $p -> $code"
done

echo ">> Fertig. Für die Spotify-Bibliothek im Web-UI einmal 'Spotify neu verbinden'."
