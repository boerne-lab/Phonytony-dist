"""Bibliotheks-Wartung: nachträgliches Trim/Normalisieren + Cover-Regenerierung."""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path

from fastapi import APIRouter, Request

from musicbox.audio import reprocess

router = APIRouter()


def _status_file(request: Request) -> Path:
    return request.app.state.settings.data_dir / "reprocess_status.json"


def _laeuft_gerade(request: Request) -> bool:
    """Ob in *diesem* Prozess gerade ein Lauf arbeitet.

    Der Lauf ist eine asyncio-Task des Web-Dienstes und stirbt mit ihm. Die
    Statusdatei überlebt ihn — ein bei Absturz oder Neustart liegengebliebenes
    "running" ist deshalb nie ein laufender Lauf.
    """
    task = getattr(request.app.state, "reprocess_task", None)
    return task is not None and not task.done()


def _read_status(request: Request) -> dict:
    try:
        st = json.loads(_status_file(request).read_text())
    except (OSError, json.JSONDecodeError):
        return {"state": "idle", "done": 0, "total": 0, "current": ""}
    # Auf der Box stand hier ab dem 15.06.2026 ein "running" ohne jeden Prozess
    # dahinter und ließ die Nachbearbeitung knapp drei Monate lang abprallen.
    if st.get("state") == "running" and not _laeuft_gerade(request):
        return {**st, "state": "stale"}
    return st


def _write_status(request: Request, st: dict) -> None:
    p = _status_file(request)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(st))
        tmp.replace(p)
    except OSError:
        pass


@router.get("/library/reprocess/status")
def reprocess_status(request: Request) -> dict:
    return _read_status(request)


@router.post("/library/reprocess")
async def reprocess_start(request: Request) -> dict:
    if _laeuft_gerade(request):
        return {"ok": False, "running": True}
    s = request.app.state.settings
    request.app.state.settings_store.reload_if_changed()
    trim = bool(request.app.state.settings_store.data.get("trim_silence", True))
    music_dir = s.music_dir
    _write_status(request, {"state": "running", "done": 0, "total": 0,
                            "current": "", "ts": int(time.time())})

    async def _run():
        def cb(p):
            _write_status(request, {"state": "running", **p, "ts": int(time.time())})
        try:
            res = await asyncio.to_thread(reprocess.reprocess_library, music_dir,
                                          trim=trim, status_cb=cb)
            _write_status(request, {"state": "done", **res, "ts": int(time.time())})
        except Exception as e:  # pragma: no cover - Defensive
            _write_status(request, {"state": "error", "message": str(e), "ts": int(time.time())})

    request.app.state.reprocess_task = asyncio.create_task(_run())
    return {"ok": True}


@router.post("/library/covers/regenerate")
def covers_regenerate(request: Request) -> dict:
    """Cover-Cache leeren — beim nächsten Laden werden die Cover neu ermittelt."""
    cache = request.app.state.settings.music_dir.parent / "cover_cache"
    cleared = 0
    if cache.exists():
        for p in cache.glob("*.jpg"):
            try:
                p.unlink()
                cleared += 1
            except OSError:
                pass
    return {"ok": True, "cleared": cleared}
