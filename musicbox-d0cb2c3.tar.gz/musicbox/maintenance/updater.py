"""Self-Update der Box: Tarball aus dem Dist-Repo holen, prüfen, tauschen, ggf. zurückrollen."""

from __future__ import annotations

import hashlib
import io
import json
import logging
import shutil
import subprocess
import tarfile
import time
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger(__name__)

_APP_PARTS = ("musicbox", "scripts", "systemd", "pyproject.toml", "VERSION")


def _http_get(url: str) -> bytes:
    import httpx
    r = httpx.get(url, timeout=30.0, follow_redirects=True)
    r.raise_for_status()
    return r.content


class Updater:
    def __init__(self, *, app_dir: Path, data_dir: Path, venv_python: str,
                 update_url: str, web_port: int,
                 http_get: Callable[[str], bytes] = _http_get,
                 runner: Callable = subprocess.run,
                 healthcheck: Optional[Callable[[], bool]] = None,
                 settings_path: Optional[Path] = None,
                 health_timeout: float = 30.0, health_poll: float = 2.0) -> None:
        self._app = Path(app_dir)
        self._data = Path(data_dir)
        self._py = venv_python
        self._url = update_url
        self._port = web_port
        self._http_get = http_get
        self._runner = runner
        self._healthcheck = healthcheck or self._default_healthcheck
        self._settings_path = Path(settings_path) if settings_path else (self._data / "settings.json")
        self._health_timeout = health_timeout
        self._health_poll = health_poll

    # ── Status ──────────────────────────────────────────────
    def _status_path(self) -> Path:
        return self._data / "update_status.json"

    def _set_status(self, state: str, message: str = "", version: str = "") -> dict:
        st = {"state": state, "message": message, "version": version, "ts": int(time.time())}
        try:
            self._data.mkdir(parents=True, exist_ok=True)
            tmp = self._status_path().with_suffix(".tmp")
            tmp.write_text(json.dumps(st))
            tmp.replace(self._status_path())
        except OSError:
            pass
        return st

    # ── Version / Manifest ──────────────────────────────────
    def installed_version(self) -> str:
        try:
            return (self._app / "VERSION").read_text().strip()
        except OSError:
            return ""

    def fetch_manifest(self) -> dict:
        return json.loads(self._http_get(self._url).decode())

    def _auto_enabled(self) -> bool:
        try:
            return bool(json.loads(self._settings_path.read_text()).get("auto_update", True))
        except (OSError, json.JSONDecodeError):
            return True

    # ── Orchestrierung ──────────────────────────────────────
    def run(self, *, check: bool = False, auto: bool = False) -> dict:
        if auto and not self._auto_enabled():
            return self._set_status("idle", "Auto-Update deaktiviert")
        self._set_status("checking")
        try:
            manifest = self.fetch_manifest()
        except Exception as e:
            return self._set_status("failed", f"Manifest nicht erreichbar: {e}")
        new_ver = str(manifest.get("version", ""))
        if not new_ver:
            return self._set_status("failed", "Manifest ohne Version")
        if new_ver == self.installed_version():
            return self._set_status("up_to_date", version=new_ver)
        if check:
            return self._set_status("available", "Update verfügbar", new_ver)
        return self._apply(manifest, new_ver)

    def _apply(self, manifest: dict, new_ver: str) -> dict:
        self._set_status("downloading", version=new_ver)
        try:
            blob = self._http_get(manifest["tarball"])
        except Exception as e:
            return self._set_status("failed", f"Download fehlgeschlagen: {e}", new_ver)
        want = str(manifest.get("sha256", ""))
        if hashlib.sha256(blob).hexdigest() != want:
            return self._set_status("failed", "Prüfsumme stimmt nicht", new_ver)

        self._set_status("applying", version=new_ver)
        old_ver = self.installed_version()
        backup = self._app / ".backup" / (old_ver or "prev")
        try:
            self._backup(backup)
            self._extract(blob)
        except Exception as e:
            return self._set_status("failed", f"Entpacken fehlgeschlagen: {e}", new_ver)

        # Entry-Points auffrischen (best effort; nötig nur bei pyproject-Änderung)
        try:
            self._runner([self._py, "-m", "pip", "install", "-e", ".", "--no-deps"],
                         cwd=str(self._app))
        except Exception:
            pass
        # Feedback-Töne kommen fertig gerendert mit der App (musicbox/audio/sounds/) —
        # nur in den persistenten Datenordner kopieren, nicht mehr auf dem Gerät
        # generieren (best effort).
        try:
            self._sync_sounds()
        except Exception:
            pass
        (self._app / "VERSION").write_text(new_ver + "\n")

        self._set_status("healthcheck", version=new_ver)
        try:
            self._runner(["systemctl", "restart", "musicbox-core", "musicbox-web"])
        except Exception:
            pass
        if self._wait_healthy():
            shutil.rmtree(backup, ignore_errors=True)
            return self._set_status("done", "Aktualisiert", new_ver)
        # Rollback
        self._restore(backup)
        try:
            self._runner(["systemctl", "restart", "musicbox-core", "musicbox-web"])
        except Exception:
            pass
        return self._set_status("rolledback", "Healthcheck fehlgeschlagen – zurückgerollt", old_ver)

    # ── Datei-Operationen ───────────────────────────────────
    def _sync_sounds(self) -> None:
        """Kopiert die mit der App ausgelieferten Feedback-Töne in den Datenordner."""
        src = self._app / "musicbox" / "audio" / "sounds"
        if not src.is_dir():
            return
        dst = self._data / "sounds"
        dst.mkdir(parents=True, exist_ok=True)
        for wav in src.glob("*.wav"):
            shutil.copy2(wav, dst / wav.name)

    def _backup(self, backup: Path) -> None:
        if backup.exists():
            shutil.rmtree(backup)
        backup.mkdir(parents=True)
        for part in _APP_PARTS:
            src = self._app / part
            if src.is_dir():
                shutil.copytree(src, backup / part)
            elif src.exists():
                shutil.copy2(src, backup / part)

    def _restore(self, backup: Path) -> None:
        for part in _APP_PARTS:
            src = backup / part
            dst = self._app / part
            if src.is_dir():
                shutil.rmtree(dst, ignore_errors=True)
                shutil.copytree(src, dst)
            elif src.exists():
                shutil.copy2(src, dst)

    def _extract(self, blob: bytes) -> None:
        with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as tar:
            for m in tar.getmembers():
                p = Path(m.name)
                if p.is_absolute() or ".." in p.parts:
                    raise ValueError(f"Unsicherer Pfad im Tarball: {m.name}")
            tar.extractall(self._app)

    # ── Healthcheck ─────────────────────────────────────────
    def _wait_healthy(self) -> bool:
        deadline = time.time() + self._health_timeout
        while time.time() < deadline:
            if self._healthcheck():
                return True
            time.sleep(self._health_poll)
        return self._healthcheck()

    def _default_healthcheck(self) -> bool:
        try:
            import httpx
            core = self._runner(["systemctl", "is-active", "musicbox-core"],
                                capture_output=True, text=True)
            core_ok = getattr(core, "stdout", "").strip() == "active"
            r = httpx.get(f"http://localhost:{self._port}/", timeout=3.0)
            return core_ok and r.status_code == 200
        except Exception:
            return False

    @property
    def _app_dir(self) -> Path:  # Test-Komfort
        return self._app


def main(argv=None) -> int:
    import argparse
    from musicbox.settings import load_settings
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--auto", action="store_true")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO)
    s = load_settings()
    app_dir = Path(__file__).resolve().parent.parent.parent
    u = Updater(app_dir=app_dir, data_dir=s.data_dir,
                venv_python=str(app_dir / "venv/bin/python"),
                update_url=s.update_url, web_port=s.port)
    res = u.run(check=args.check, auto=args.auto)
    log.info("Update-Ergebnis: %s", res)
    print(json.dumps(res))
    return 0 if res["state"] in ("done", "up_to_date", "idle", "available") else 1


if __name__ == "__main__":
    raise SystemExit(main())
