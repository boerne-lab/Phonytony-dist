#!/usr/bin/env python3
"""Rendert die Feedback-Töne als echtes Instrument (Celesta, GM-Soundfont) statt
Oszillator-Synthese. Dev-Tool — läuft NICHT auf der Box, sondern einmalig hier;
die Ergebnisse werden nach musicbox/audio/sounds/ committet und von dort mit der
App ausgeliefert (siehe musicbox/maintenance/updater.py::_sync_sounds).

Voraussetzungen (nur zum Generieren, keine Laufzeit-Abhängigkeit der Box):
    sudo apt install fluidsynth fluid-soundfont-gm sox

Aufruf:
    python3 scripts/generate_sounds.py [OUTPUT_DIR]
"""

from __future__ import annotations

import re
import shutil
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

SOUNDFONT = Path("/usr/share/sounds/sf2/FluidR3_GM.sf2")
TICKS_PER_BEAT = 480
TEMPO_US = 500_000  # 120 BPM -> 960 Ticks/Sekunde bei 480 Ticks/Beat
TICKS_PER_SEC = TICKS_PER_BEAT * 1_000_000 // TEMPO_US
CELESTA = 8  # GM-Programm 9 (0-indiziert: 8) — warmer, "charmanter" Glockenklang

_NOTE_RE = re.compile(r"^([A-G]#?)(-?\d+)$")
_LETTERS = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5,
            "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}


def note_num(name: str) -> int:
    m = _NOTE_RE.match(name)
    if not m:
        raise ValueError(f"Ungültiger Notenname: {name!r}")
    letter, octave = m.group(1), int(m.group(2))
    return _LETTERS[letter] + (octave + 1) * 12


def _vlq(n: int) -> bytes:
    out = [n & 0x7F]
    n >>= 7
    while n:
        out.append((n & 0x7F) | 0x80)
        n >>= 7
    return bytes(reversed(out))


def write_midi(path: Path, notes: list[tuple[str, float, float]], overlap: float = 0.04) -> None:
    """notes: Liste (Notenname, Dauer_s, Velocity-Anteil 0-1), sequentiell mit leichtem
    Überlapp (klingt weniger robotisch als exakt aneinandergereihte Noten)."""
    track = bytearray()
    track += _vlq(0) + bytes([0xC0, CELESTA])  # Programmwechsel: Celesta

    pending_off: list[tuple[int, int]] = []  # (ticks_from_now, note)
    for name, dur_s, vel in notes:
        note = note_num(name)
        velocity = max(1, min(127, round(vel * 127)))
        on_delay = pending_off[0][0] if pending_off else 0
        if pending_off:
            track += _vlq(on_delay) + bytes([0x80, pending_off[0][1], 0])
            pending_off.pop(0)
        else:
            track += _vlq(0)
        track += bytes([0x90, note, velocity])
        note_ticks = round(dur_s * TICKS_PER_SEC)
        overlap_ticks = round(overlap * TICKS_PER_SEC)
        pending_off.append((max(1, note_ticks - overlap_ticks), note))
    for delay, note in pending_off:
        track += _vlq(delay) + bytes([0x80, note, 0])
    track += _vlq(0) + bytes([0xFF, 0x2F, 0x00])  # End of Track

    header = b"MThd" + struct.pack(">IHHH", 6, 0, 1, TICKS_PER_BEAT)
    trk = b"MTrk" + struct.pack(">I", len(track)) + bytes(track)
    path.write_bytes(header + trk)


# Tondefinitionen: (Name, Dauer in Sekunden, Velocity-Anteil). Melodische Kontur wie
# zuvor (aufsteigend = positiv, absteigend = Achtung, Einzelton = neutral).
TONES: dict[str, list[tuple[str, float, float]]] = {
    "startup":     [("C5", 0.26, 0.7), ("E5", 0.26, 0.75), ("G5", 0.55, 0.8)],
    "tag_ok":      [("C5", 0.24, 0.7), ("G5", 0.42, 0.75)],
    "tag_unknown": [("E5", 0.26, 0.65), ("C5", 0.42, 0.6)],
    "tag_removed": [("G4", 0.36, 0.6)],
    "offline":     [("G4", 0.26, 0.65), ("E4", 0.26, 0.6), ("C4", 0.48, 0.6)],
    "error":       [("A3", 0.36, 0.6), ("F3", 0.48, 0.55)],
    "volume_max":  [("E6", 0.18, 0.55)],
    "volume_min":  [("C4", 0.18, 0.5)],
}


def render(name: str, notes: list[tuple[str, float, float]], out_dir: Path, work: Path) -> None:
    midi_path = work / f"{name}.mid"
    raw_wav = work / f"{name}_raw.wav"
    write_midi(midi_path, notes)
    subprocess.run(
        ["fluidsynth", "-ni", "-F", str(raw_wav), "-r", "44100", "-g", "1.0",
         str(SOUNDFONT), str(midi_path)],
        check=True, capture_output=True,
    )
    # Nachbearbeitung in zwei Schritten: erst Stille am Anfang/Ende abschneiden (macht
    # die Datei kürzer, sox muss die Gesamtlänge dafür nicht vorab kennen), dann erst
    # danach den Fade-Out anwenden — der braucht die fertige Länge, die eine einzelne
    # sox-Pipeline mit "silence" davor nicht zuverlässig vorab kennt.
    trimmed = raw_wav.with_name(raw_wav.stem + "_trim.wav")
    subprocess.run(
        ["sox", str(raw_wav), str(trimmed),
         "silence", "1", "0.05", "0.5%", "reverse",
         "silence", "1", "0.05", "0.5%", "reverse"],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["sox", str(trimmed), str(out_dir / f"{name}.wav"),
         "fade", "h", "0", "0", "0.15",
         "reverb", "25", "gain", "-n", "-3"],
        check=True, capture_output=True,
    )


def main() -> None:
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("musicbox/audio/sounds")
    if not SOUNDFONT.exists():
        sys.exit(f"Soundfont nicht gefunden: {SOUNDFONT}\n"
                  f"Installation: sudo apt install fluidsynth fluid-soundfont-gm sox")
    for tool in ("fluidsynth", "sox"):
        if not shutil.which(tool):
            sys.exit(f"{tool} nicht gefunden. Installation: sudo apt install fluidsynth fluid-soundfont-gm sox")

    out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        for name, notes in TONES.items():
            render(name, notes, out_dir, work)

    print(f"Sounds generiert in: {out_dir}")
    for f in sorted(out_dir.glob("*.wav")):
        print(f"  {f.name}  ({f.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
