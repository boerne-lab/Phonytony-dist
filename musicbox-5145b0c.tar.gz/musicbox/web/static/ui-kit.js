// Gemeinsame, DOM-nahe Hilfsbausteine ohne Abhängigkeiten — ersetzt die bisher an
// vier Stellen unabhängig implementierten Lade-/Fehler-/Leerzustände.
window.UIKit = (function () {
  function debounce(fn, ms) {
    let timer = null;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), ms);
    };
  }

  function showSkeleton(container, count) {
    count = count || 3;
    const items = [];
    for (let i = 0; i < count; i++) {
      items.push(
        '<div class="skeleton-item">' +
        '<div class="skeleton-thumb"></div>' +
        '<div class="skeleton-lines">' +
        '<div class="skeleton-line w60"></div>' +
        '<div class="skeleton-line w40"></div>' +
        '</div></div>'
      );
    }
    container.innerHTML = items.join('');
  }

  function showError(container, message, actionLabel, onAction) {
    container.innerHTML = '';
    const banner = document.createElement('div');
    banner.className = 'error-banner';
    const p = document.createElement('p');
    p.textContent = message;
    banner.appendChild(p);
    if (actionLabel && onAction) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = actionLabel;
      btn.addEventListener('click', onAction);
      banner.appendChild(btn);
    }
    container.appendChild(banner);
  }

  function showEmpty(container, message, actionLabel, actionHref) {
    container.innerHTML = '';
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    const p = document.createElement('p');
    p.textContent = message;
    empty.appendChild(p);
    if (actionLabel && actionHref) {
      const a = document.createElement('a');
      a.className = 'btn';
      a.href = actionHref;
      a.textContent = actionLabel;
      empty.appendChild(a);
    }
    container.appendChild(empty);
  }

  return { debounce, showSkeleton, showError, showEmpty };
})();
