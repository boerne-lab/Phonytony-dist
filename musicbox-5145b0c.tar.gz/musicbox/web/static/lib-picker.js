// Der Bibliotheks-Picker: EIN Bottom-Sheet zum Auswählen eines BESTEHENDEN
// Bibliothekseintrags (im Unterschied zu AddSheet, das neue Inhalte anlegt).
// Wird sowohl beim Karte-zuerst-Einlernen ("Aus Bibliothek wählen") als
// auch beim Wechseln des Inhalts einer bestehenden Karte verwendet. Führt
// selbst KEINE Kartenzuweisung aus — ruft nur onPicked(libId) auf. Bleibt
// auch beim leeren Zustand aktionsfrei: onEmpty()/emptyActionLabel werden
// vom Aufrufer bereitgestellt, der Baustein führt sie selbst nicht aus.
window.LibraryPicker = (function () {
  let onPickedCb = null;
  let onEmptyCb = null;
  let emptyActionLabel = 'Neuen Inhalt anlegen';

  function els() {
    return {
      backdrop: document.getElementById('lib-picker-sheet'),
      body: document.getElementById('lib-picker-body'),
    };
  }

  function open(opts) {
    opts = opts || {};
    onPickedCb = opts.onPicked || null;
    onEmptyCb = opts.onEmpty || null;
    emptyActionLabel = opts.emptyActionLabel || 'Neuen Inhalt anlegen';
    const { backdrop, body } = els();
    backdrop.hidden = false;
    document.addEventListener('keydown', onKeydown);
    backdrop.addEventListener('click', onBackdropClick);
    load(body);
  }

  function close() {
    const { backdrop } = els();
    backdrop.hidden = true;
    document.removeEventListener('keydown', onKeydown);
    backdrop.removeEventListener('click', onBackdropClick);
    onPickedCb = null;
    onEmptyCb = null;
  }

  function onKeydown(e) {
    if (e.key === 'Escape') close();
  }

  function onBackdropClick(e) {
    if (e.target === e.currentTarget) close();
  }

  function load(body) {
    window.UIKit.showSkeleton(body, 4);
    fetch('/api/library')
      .then(function (r) { return r.json(); })
      .then(function (data) {
        const entries = data.entries || {};
        const ids = Object.keys(entries).sort(function (a, b) {
          const la = (entries[a].label || a).toLowerCase();
          const lb = (entries[b].label || b).toLowerCase();
          return la < lb ? -1 : la > lb ? 1 : 0;
        });
        body.innerHTML = '';
        if (!ids.length) {
          const empty = document.createElement('div');
          empty.className = 'empty-state';
          const p = document.createElement('p');
          p.textContent = 'Noch keine Bibliothekseinträge vorhanden.';
          empty.appendChild(p);
          if (onEmptyCb) {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn-secondary';
            btn.textContent = emptyActionLabel;
            btn.addEventListener('click', function () {
              const cb = onEmptyCb;
              close();
              if (typeof cb === 'function') cb();
            });
            empty.appendChild(btn);
          }
          body.appendChild(empty);
          return;
        }
        const list = document.createElement('div');
        list.className = 'pick-list';
        ids.forEach(function (libId) {
          const entry = entries[libId];
          if (!entry) return;
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'pick-item';
          const img = document.createElement('img');
          img.src = '/api/cover/lib/' + libId + '.jpg';
          img.alt = '';
          btn.appendChild(img);
          const meta = document.createElement('span');
          meta.className = 'meta';
          const n = document.createElement('span');
          n.className = 'n'; n.textContent = entry.label || libId;
          const s = document.createElement('span');
          s.className = 's'; s.textContent = entry.type === 'spotify' ? 'Spotify' : 'Lokal';
          meta.appendChild(n); meta.appendChild(s);
          btn.appendChild(meta);
          btn.addEventListener('click', function () {
            if (btn.disabled) return;
            list.querySelectorAll('.pick-item').forEach(function (b) { b.disabled = true; });
            const cb = onPickedCb;
            close();
            if (typeof cb === 'function') cb(libId);
          });
          list.appendChild(btn);
        });
        body.appendChild(list);
      })
      .catch(function () {
        window.UIKit.showError(body, 'Bibliothek konnte nicht geladen werden.', null, null);
      });
  }

  return { open: open, close: close };
})();
