// Der "Inhalt hinzufügen"-Baustein: EIN Bottom-Sheet mit den Quellen Spotify
// suchen, Spotify-Bibliothek, Datei hochladen, Playlist bauen. Speichert
// erfolgreich ausgewählten/hochgeladenen Inhalt über POST /api/library und
// ruft danach onAdded(libId) auf. Führt selbst KEINE Kartenzuweisung aus.
window.AddSheet = (function () {
  let onAddedCb = null;

  function els() {
    return {
      backdrop: document.getElementById('add-sheet'),
      title: document.getElementById('add-sheet-title'),
      body: document.getElementById('add-sheet-body'),
    };
  }

  function open(opts) {
    opts = opts || {};
    onAddedCb = opts.onAdded || null;
    const { backdrop } = els();
    renderMenu();
    backdrop.hidden = false;
    document.addEventListener('keydown', onKeydown);
    backdrop.addEventListener('click', onBackdropClick);
  }

  function close() {
    const { backdrop } = els();
    backdrop.hidden = true;
    document.removeEventListener('keydown', onKeydown);
    backdrop.removeEventListener('click', onBackdropClick);
    onAddedCb = null;
  }

  function onKeydown(e) {
    if (e.key === 'Escape') close();
  }

  function onBackdropClick(e) {
    if (e.target === e.currentTarget) close();
  }

  function renderMenu() {
    const { title, body } = els();
    title.textContent = 'Inhalt hinzufügen';
    body.innerHTML =
      '<div class="source-menu">' +
      '<button type="button" class="btn-secondary" data-source="sp_search">Spotify suchen</button>' +
      '<button type="button" class="btn-secondary" data-source="sp_lib">Meine Spotify-Bibliothek</button>' +
      '<button type="button" class="btn-secondary" data-source="upload">Lokale Datei hochladen</button>' +
      '<button type="button" class="btn-secondary" data-source="playlist">Lokale Playlist bauen</button>' +
      '</div>';
    body.querySelectorAll('[data-source]').forEach(function (btn) {
      btn.addEventListener('click', function () { selectSource(btn.dataset.source); });
    });
  }

  function selectSource(source) {
    if (source === 'sp_search') { renderSpotifySearch(); return; }
    if (source === 'sp_lib') { renderSpotifyLibrary(); return; }
    if (source === 'upload') { renderUpload(); return; }
    if (source === 'playlist') { renderPlaylistBuilder(); return; }
  }

  function renderSpotifySearch() {
    const { title, body } = els();
    title.textContent = 'Spotify suchen';
    body.innerHTML =
      '<button type="button" class="btn-secondary" id="add-sheet-back">← Zurück</button>' +
      '<div id="sp-search-status"></div>' +
      '<input type="text" id="sp-search-q" placeholder="Suchen …" autocomplete="off">' +
      '<div id="sp-search-results"></div>';
    document.getElementById('add-sheet-back').addEventListener('click', renderMenu);
    const input = document.getElementById('sp-search-q');
    const results = document.getElementById('sp-search-results');
    input.addEventListener('input', window.UIKit.debounce(function () {
      doSpotifySearch(input.value.trim(), results);
    }, 300));
    input.focus();
  }

  async function doSpotifySearch(q, container) {
    if (!q) { container.innerHTML = ''; return; }
    window.UIKit.showSkeleton(container, 4);
    try {
      const r = await fetch('/api/search?q=' + encodeURIComponent(q) + '&type=album,playlist,track,artist');
      if (!r.ok) {
        window.UIKit.showError(container, 'Suche fehlgeschlagen.',
          'Erneut verbinden', function () { location.href = '/auth/spotify/start'; });
        return;
      }
      const data = await r.json();
      const items = [];
      ['albums', 'playlists', 'tracks', 'artists'].forEach(function (key) {
        ((data[key] || {}).items || []).forEach(function (it) {
          if (!it) return;
          const by = (it.artists || []).map(function (a) { return a.name; }).join(', ')
            || (it.owner || {}).display_name || '';
          const images = it.images || (it.album || {}).images || [];
          items.push({ uri: it.uri, name: it.name, by: by, image: (images[0] || {}).url || '' });
        });
      });
      renderPickList(container, items, function (item) {
        addFromSpotifyItem(item, document.getElementById('sp-search-status'));
      });
    } catch (e) {
      window.UIKit.showError(container, 'Suche fehlgeschlagen.',
        'Erneut verbinden', function () { location.href = '/auth/spotify/start'; });
    }
  }

  function ensurePickList(container) {
    let list = container.querySelector('.pick-list');
    if (!list) {
      list = document.createElement('div');
      list.className = 'pick-list';
      container.appendChild(list);
    }
    return list;
  }

  function appendPickItems(list, items, onPick) {
    items.forEach(function (item) {
      if (!item.uri) return;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'pick-item';
      const img = document.createElement('img');
      if (item.image) { img.src = item.image; }
      img.alt = '';
      btn.appendChild(img);
      const meta = document.createElement('span');
      meta.className = 'meta';
      const n = document.createElement('span');
      n.className = 'n'; n.textContent = item.name;
      const s = document.createElement('span');
      s.className = 's'; s.textContent = item.by || '';
      meta.appendChild(n); meta.appendChild(s);
      btn.appendChild(meta);
      btn.addEventListener('click', function () {
        if (btn.disabled) return;
        list.querySelectorAll('.pick-item').forEach(function (b) { b.disabled = true; });
        onPick(item);
      });
      list.appendChild(btn);
    });
  }

  function renderPickList(container, items, onPick) {
    container.innerHTML = '';
    if (!items.length) {
      window.UIKit.showEmpty(container, 'Keine Treffer.', null, null);
      return;
    }
    const list = ensurePickList(container);
    appendPickItems(list, items, onPick);
  }

  async function addFromSpotifyItem(item, statusEl) {
    const entry = { type: 'spotify', ref: item.uri, label: item.name };
    try {
      const data = await saveAsLibraryEntry(entry);
      if (data.ok) {
        finishAdd(data.id);
      } else {
        window.UIKit.showError(statusEl, 'Hinzufügen fehlgeschlagen.', null, null);
      }
    } catch (e) {
      window.UIKit.showError(statusEl, 'Hinzufügen fehlgeschlagen.', null, null);
    }
  }

  function renderSpotifyLibrary() {
    const LIB_LIMIT = 20;
    const { title, body } = els();
    title.textContent = 'Meine Spotify-Bibliothek';
    body.innerHTML =
      '<button type="button" class="btn-secondary" id="add-sheet-back">← Zurück</button>' +
      '<div id="sp-lib-status"></div>' +
      '<select id="sp-lib-type">' +
      '<option value="playlists">Playlists</option>' +
      '<option value="tracks">Liked Songs</option>' +
      '<option value="albums">Alben</option>' +
      '<option value="artists">Gefolgte Künstler</option>' +
      '</select>' +
      '<div id="sp-lib-results"></div>' +
      '<button type="button" class="btn-secondary" id="sp-lib-more" hidden>Mehr laden</button>';
    document.getElementById('add-sheet-back').addEventListener('click', renderMenu);
    const select = document.getElementById('sp-lib-type');
    const results = document.getElementById('sp-lib-results');
    const moreBtn = document.getElementById('sp-lib-more');
    const status = document.getElementById('sp-lib-status');
    let offset = 0;

    function load(reset) {
      if (reset) {
        offset = 0; results.innerHTML = ''; status.innerHTML = '';
        window.UIKit.showSkeleton(results, 4);
      }
      fetch('/api/spotify/library?type=' + select.value + '&offset=' + offset + '&limit=' + LIB_LIMIT)
        .then(function (r) {
          if (!r.ok) throw new Error('http_error');
          return r.json();
        })
        .then(function (data) {
          if (data.error === 'reauth_required') {
            window.UIKit.showError(results, 'Spotify-Zugriff abgelaufen.',
              'Erneut verbinden', function () { location.href = '/auth/spotify/start'; });
            moreBtn.hidden = true;
            moreBtn.disabled = false;
            return;
          }
          const items = data.items || [];
          if (reset) results.innerHTML = '';
          if (reset && !items.length) {
            window.UIKit.showEmpty(results, 'Nichts gefunden.', null, null);
          } else {
            const list = ensurePickList(results);
            appendPickItems(list, items, function (item) { addFromSpotifyItem(item, status); });
          }
          offset += LIB_LIMIT;
          // "Gefolgte Künstler" unterstützt serverseitig kein Offset-basiertes
          // Pagination (Spotify-API kennt dort nur Cursor-Pagination via
          // "after") — "Mehr laden" würde nur dieselbe erste Seite erneut
          // liefern, daher hier bewusst nie anbieten. Echte Cursor-Pagination
          // ist eine eigene, spätere Backend-Aufgabe.
          moreBtn.hidden = !data.next || select.value === 'artists';
          moreBtn.disabled = false;
        })
        .catch(function () {
          window.UIKit.showError(results, 'Bibliothek konnte nicht geladen werden.',
            'Erneut verbinden', function () { location.href = '/auth/spotify/start'; });
          moreBtn.hidden = true;
          moreBtn.disabled = false;
        });
    }

    select.addEventListener('change', function () { load(true); });
    moreBtn.addEventListener('click', function () {
      if (moreBtn.disabled) return;
      moreBtn.disabled = true;
      load(false);
    });
    load(true);
  }
  function renderUpload() {
    const { title, body } = els();
    title.textContent = 'Datei hochladen';
    body.innerHTML =
      '<button type="button" class="btn-secondary" id="add-sheet-back">← Zurück</button>' +
      '<form id="add-upload-form">' +
      '<label>Dateien: <input type="file" id="add-upload-files" accept="audio/*" multiple></label>' +
      '<label>Playlist-Name (optional): <input type="text" id="add-upload-name"></label>' +
      '<label>Kategorie: <select id="add-upload-cat"><option value="musik">Musik</option><option value="hoerbuch">Hörbuch</option></select></label>' +
      '<button type="submit">Hochladen</button>' +
      '</form>' +
      '<div id="add-upload-status"></div>';
    document.getElementById('add-sheet-back').addEventListener('click', renderMenu);
    document.getElementById('add-upload-form').addEventListener('submit', function (e) {
      e.preventDefault();
      doUpload();
    });
  }

  function doUpload() {
    const files = document.getElementById('add-upload-files').files;
    const status = document.getElementById('add-upload-status');
    if (!files.length) {
      window.UIKit.showError(status, 'Bitte mindestens eine Datei wählen.', null, null);
      return;
    }
    const submitBtn = document.querySelector('#add-upload-form button[type="submit"]');
    if (submitBtn.disabled) return;
    submitBtn.disabled = true;
    const fd = new FormData();
    for (let i = 0; i < files.length; i++) fd.append('files', files[i]);
    fd.append('playlist_name', document.getElementById('add-upload-name').value);
    fd.append('category', document.getElementById('add-upload-cat').value);
    status.innerHTML = '';
    window.UIKit.showSkeleton(status, 1);
    fetch('/upload', { method: 'POST', body: fd })
      .then(function (r) {
        return r.json().then(function (data) { return { ok: r.ok, data: data }; });
      })
      .then(function (res) {
        if (!res.ok || !res.data.ok || !res.data.ref) {
          const rawDetail = res.data && res.data.detail;
          const msg = (Array.isArray(rawDetail) ? (rawDetail[0] && rawDetail[0].msg) : rawDetail) || 'Upload fehlgeschlagen.';
          window.UIKit.showError(status, msg, null, null);
          submitBtn.disabled = false;
          return null;
        }
        const entry = { type: 'local', ref: res.data.ref, label: res.data.playlist || res.data.target };
        return saveAsLibraryEntry(entry);
      })
      .then(function (data) {
        if (!data) return;
        if (data.ok) {
          finishAdd(data.id);
        } else {
          window.UIKit.showError(status, 'Hinzufügen zur Bibliothek fehlgeschlagen.', null, null);
          submitBtn.disabled = false;
        }
      })
      .catch(function () {
        window.UIKit.showError(status, 'Upload fehlgeschlagen.', null, null);
        submitBtn.disabled = false;
      });
  }

  function renderPlaylistBuilder() {
    const { title, body } = els();
    title.textContent = 'Lokale Playlist bauen';
    body.innerHTML =
      '<button type="button" class="btn-secondary" id="add-sheet-back">← Zurück</button>' +
      '<div id="pl-status"></div>' +
      '<label>Name: <input type="text" id="pl-name" autocomplete="off"></label>' +
      '<label>Kategorie: <select id="pl-cat"><option value="musik">Musik</option><option value="hoerbuch">Hörbuch</option></select></label>' +
      '<label><input type="checkbox" id="pl-shuffle"> Shuffle</label>' +
      '<label>Wiederholen: <select id="pl-repeat"><option value="off">Aus</option><option value="all">Alle</option><option value="one">Einen</option></select></label>' +
      '<h2>Dateien auswählen</h2>' +
      '<div id="pl-file-browser"></div>' +
      '<h2>Ausgewählt <span class="muted" id="pl-selected-count">(0)</span></h2>' +
      '<ul id="pl-selected-list" class="selected-tracks"></ul>' +
      '<button type="button" id="pl-save">Playlist speichern</button>';
    document.getElementById('add-sheet-back').addEventListener('click', renderMenu);

    const status = document.getElementById('pl-status');
    const fileBrowser = document.getElementById('pl-file-browser');
    const selectedList = document.getElementById('pl-selected-list');
    const selectedCount = document.getElementById('pl-selected-count');
    const saveBtn = document.getElementById('pl-save');
    const CAT_LABELS = { musik: 'Musik', hoerbuch: 'Hörbuch' };
    let selected = [];
    let createdPlaylist = null;

    function findCheckbox(path) {
      return Array.prototype.find.call(
        fileBrowser.querySelectorAll('input[type=checkbox]'),
        function (c) { return c.value === path; }
      );
    }

    function renderSelected() {
      selectedList.innerHTML = '';
      selected.forEach(function (path) {
        const li = document.createElement('li');
        li.className = 'selected-track';
        const name = document.createElement('span');
        const parts = path.split('/');
        const cat = parts[0];
        const base = parts.slice(1).join('/');
        name.textContent = base + ' (' + (CAT_LABELS[cat] || cat) + ')';
        li.appendChild(name);
        const rm = document.createElement('button');
        rm.type = 'button';
        rm.className = 'btn-secondary';
        rm.textContent = '✕';
        rm.addEventListener('click', function () { toggleTrack(path, false); });
        li.appendChild(rm);
        selectedList.appendChild(li);
      });
      selectedCount.textContent = '(' + selected.length + ')';
    }

    function toggleTrack(path, checked) {
      const cb = findCheckbox(path);
      if (cb) cb.checked = checked;
      if (checked && selected.indexOf(path) === -1) {
        selected.push(path);
      } else if (!checked) {
        selected = selected.filter(function (p) { return p !== path; });
      }
      renderSelected();
    }

    function loadFiles() {
      window.UIKit.showSkeleton(fileBrowser, 3);
      fetch('/api/files')
        .then(function (r) {
          if (!r.ok) throw new Error('http ' + r.status);
          return r.json();
        })
        .then(function (data) {
          const files = data.files || {};
          const hasAny = Object.keys(files).some(function (cat) { return (files[cat] || []).length; });
          fileBrowser.innerHTML = '';
          if (!hasAny) {
            const empty = document.createElement('div');
            empty.className = 'empty-state';
            const p = document.createElement('p');
            p.textContent = 'Noch keine Dateien hochgeladen.';
            empty.appendChild(p);
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn-secondary';
            btn.textContent = 'Datei hochladen';
            btn.addEventListener('click', renderUpload);
            empty.appendChild(btn);
            fileBrowser.appendChild(empty);
            return;
          }
          Object.keys(files).forEach(function (cat) {
            const catFiles = files[cat] || [];
            if (!catFiles.length) return;
            const details = document.createElement('details');
            details.open = true;
            const summary = document.createElement('summary');
            summary.textContent = (CAT_LABELS[cat] || cat) + ' (' + catFiles.length + ')';
            details.appendChild(summary);
            const list = document.createElement('div');
            list.className = 'pick-list';
            catFiles.forEach(function (path) {
              const label = document.createElement('label');
              label.className = 'pick-item';
              const cb = document.createElement('input');
              cb.type = 'checkbox';
              cb.value = path;
              cb.addEventListener('change', function () { toggleTrack(path, cb.checked); });
              label.appendChild(cb);
              const span = document.createElement('span');
              span.textContent = path.split('/').pop();
              label.appendChild(span);
              list.appendChild(label);
            });
            details.appendChild(list);
            fileBrowser.appendChild(details);
          });
        })
        .catch(function () {
          window.UIKit.showError(fileBrowser, 'Dateien konnten nicht geladen werden.',
            'Erneut versuchen', loadFiles);
        });
    }

    function save() {
      if (saveBtn.disabled) return;
      const name = document.getElementById('pl-name').value.trim();
      if (!name) {
        window.UIKit.showError(status, 'Bitte einen Namen eingeben.', null, null);
        return;
      }
      if (!selected.length) {
        window.UIKit.showError(status, 'Bitte mindestens eine Datei auswählen.', null, null);
        return;
      }
      saveBtn.disabled = true;
      status.innerHTML = '';
      const payload = {
        name: name,
        category: document.getElementById('pl-cat').value,
        tracks: selected,
        shuffle: document.getElementById('pl-shuffle').checked,
        repeat: document.getElementById('pl-repeat').value,
      };

      const createStep = createdPlaylist
        ? Promise.resolve({ ok: true, data: { ok: true, playlist: createdPlaylist } })
        : fetch('/api/playlists', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          }).then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); });

      createStep
        .then(function (res) {
          if (!res.ok || !res.data.ok) {
            const rawDetail = res.data && res.data.detail;
            const msg = (Array.isArray(rawDetail) ? (rawDetail[0] && rawDetail[0].msg) : rawDetail) || 'Playlist konnte nicht gespeichert werden.';
            window.UIKit.showError(status, msg, null, null);
            saveBtn.disabled = false;
            return null;
          }
          createdPlaylist = res.data.playlist;
          const entry = {
            type: 'local', ref: createdPlaylist.m3u8_path, label: createdPlaylist.name,
            shuffle: payload.shuffle, repeat: payload.repeat,
          };
          return saveAsLibraryEntry(entry);
        })
        .then(function (data) {
          if (!data) return;
          if (data.ok) {
            finishAdd(data.id);
          } else {
            window.UIKit.showError(status,
              'Playlist wurde gespeichert, aber das Hinzufügen zur Bibliothek ist fehlgeschlagen — bitte erneut versuchen.',
              null, null);
            saveBtn.disabled = false;
          }
        })
        .catch(function () {
          const msg = createdPlaylist
            ? 'Playlist wurde gespeichert, aber das Hinzufügen zur Bibliothek ist fehlgeschlagen — bitte erneut versuchen.'
            : 'Playlist konnte nicht gespeichert werden.';
          window.UIKit.showError(status, msg, null, null);
          saveBtn.disabled = false;
        });
    }

    saveBtn.addEventListener('click', save);
    loadFiles();
  }

  function saveAsLibraryEntry(entry) {
    return fetch('/api/library', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entry: entry }),
    }).then(function (r) { return r.json(); });
  }

  function finishAdd(libId) {
    const cb = onAddedCb;
    close();
    if (typeof cb === 'function') cb(libId);
  }

  return { open: open, close: close };
})();
