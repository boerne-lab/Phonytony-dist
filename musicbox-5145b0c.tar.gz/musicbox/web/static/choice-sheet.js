// Der Auswahl-Baustein: EIN Bottom-Sheet mit zwei Optionen ("Aus
// Bibliothek wählen" / "Neuen Inhalt anlegen"), gezeigt nach einem
// Karten-Scan im Karte-zuerst-Einlernen-Flow. Führt selbst KEINE Aktion
// aus — ruft nach Auswahl nur den vom Aufrufer übergebenen
// onFromLibrary()/onNewContent()-Callback auf.
window.ChoiceSheet = (function () {
  let onFromLibraryCb = null;
  let onNewContentCb = null;

  function els() {
    return {
      backdrop: document.getElementById('card-choice-sheet'),
      fromLibraryBtn: document.getElementById('choice-from-library'),
      newContentBtn: document.getElementById('choice-new-content'),
    };
  }

  function open(opts) {
    opts = opts || {};
    onFromLibraryCb = opts.onFromLibrary || null;
    onNewContentCb = opts.onNewContent || null;
    const { backdrop, fromLibraryBtn, newContentBtn } = els();
    backdrop.hidden = false;
    document.addEventListener('keydown', onKeydown);
    backdrop.addEventListener('click', onBackdropClick);
    fromLibraryBtn.addEventListener('click', onFromLibraryClick);
    newContentBtn.addEventListener('click', onNewContentClick);
  }

  function close() {
    const { backdrop, fromLibraryBtn, newContentBtn } = els();
    backdrop.hidden = true;
    document.removeEventListener('keydown', onKeydown);
    backdrop.removeEventListener('click', onBackdropClick);
    fromLibraryBtn.removeEventListener('click', onFromLibraryClick);
    newContentBtn.removeEventListener('click', onNewContentClick);
    onFromLibraryCb = null;
    onNewContentCb = null;
  }

  function onKeydown(e) {
    if (e.key === 'Escape') close();
  }

  function onBackdropClick(e) {
    if (e.target === e.currentTarget) close();
  }

  function onFromLibraryClick() {
    const cb = onFromLibraryCb;
    close();
    if (typeof cb === 'function') cb();
  }

  function onNewContentClick() {
    const cb = onNewContentCb;
    close();
    if (typeof cb === 'function') cb();
  }

  return { open: open, close: close };
})();
