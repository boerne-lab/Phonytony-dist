// Der zentrale Zuweisen-Baustein: EIN Bottom-Sheet für "Karte auflegen", ersetzt
// die bisher drei unabhängigen Scan-Implementierungen (Zuweisen-, Karten- und
// Playlist-Seite). Führt selbst KEINE Zuweisung aus — ruft nach ausdrücklicher
// Bestätigung nur den vom Aufrufer übergebenen onAssigned(uid)-Callback auf.
window.ScanSheet = (function () {
  const POLL_MS = 500;
  const TIMEOUT_MS = 30000;

  let pollTimer = null;
  let deadline = 0;
  let onAssignedCb = null;

  function els() {
    return {
      backdrop: document.getElementById('assign-sheet'),
      title: document.getElementById('assign-sheet-title'),
      body: document.getElementById('assign-sheet-body'),
    };
  }

  function open(opts) {
    // Falls noch ein Poll-Zyklus aus einem vorherigen, nicht per close()
    // beendeten Aufruf läuft: dessen Timer stoppen, bevor ein neuer startet
    // (sonst entstehen zwei parallele setTimeout-Ketten).
    if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
    opts = opts || {};
    onAssignedCb = opts.onAssigned || null;
    const { backdrop, title, body } = els();
    body.setAttribute('aria-live', 'polite');
    title.textContent = 'Karte auflegen';
    renderScanning();
    backdrop.hidden = false;
    document.addEventListener('keydown', onKeydown);
    backdrop.addEventListener('click', onBackdropClick);
    deadline = Date.now() + TIMEOUT_MS;
    poll();
  }

  function onKeydown(e) {
    if (e.key === 'Escape') close();
  }

  function onBackdropClick(e) {
    if (e.target === e.currentTarget) close();
  }

  function close() {
    const { backdrop } = els();
    backdrop.hidden = true;
    if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
    onAssignedCb = null;
    document.removeEventListener('keydown', onKeydown);
    backdrop.removeEventListener('click', onBackdropClick);
  }

  function renderScanning() {
    const { body } = els();
    body.innerHTML =
      '<div class="sheet-spinner" aria-hidden="true"></div>' +
      '<p class="sheet-status">Karte auflegen …</p>' +
      '<button type="button" class="btn-secondary" data-role="cancel">Abbrechen</button>';
    body.querySelector('[data-role="cancel"]').addEventListener('click', close);
  }

  function renderTimeout() {
    const { body } = els();
    body.innerHTML =
      '<p class="sheet-status">Zeitüberschreitung – keine Karte erkannt.</p>' +
      '<button type="button" class="btn" data-role="retry">Nochmal versuchen</button>' +
      '<button type="button" class="btn-secondary" data-role="cancel">Abbrechen</button>';
    body.querySelector('[data-role="retry"]').addEventListener('click', function () {
      deadline = Date.now() + TIMEOUT_MS;
      renderScanning();
      poll();
    });
    body.querySelector('[data-role="cancel"]').addEventListener('click', close);
  }

  async function poll() {
    if (Date.now() > deadline) { renderTimeout(); return; }
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      if (data.present_uid) {
        await afterDetected(data.present_uid);
        return;
      }
    } catch (e) {
      // Netzwerkfehler: bis Timeout weiterversuchen statt sofort abzubrechen.
    }
    pollTimer = setTimeout(poll, POLL_MS);
  }

  async function afterDetected(uid) {
    let existing = null;
    try {
      const res = await fetch('/api/mappings');
      const data = await res.json();
      existing = (data.cards || {})[uid] || null;
    } catch (e) {
      // Bibliotheks-Check ist optional (nur für die Überschreiben-Warnung) —
      // ein Fehlschlag hier darf das Zuweisen selbst nicht blockieren.
    }
    renderConfirm(uid, existing);
  }

  function renderConfirm(uid, existing) {
    const { body } = els();
    body.innerHTML = '';
    const p = document.createElement('p');
    p.className = 'sheet-status';
    if (existing) {
      const label = existing.label || existing.ref || 'unbekannter Inhalt';
      p.textContent = 'Karte erkannt (' + uid + ') — zeigt aktuell auf „' + label + '". Überschreiben?';
    } else {
      p.textContent = 'Karte erkannt: ' + uid;
    }
    body.appendChild(p);

    const confirmBtn = document.createElement('button');
    confirmBtn.type = 'button';
    confirmBtn.className = 'btn';
    confirmBtn.textContent = existing ? 'Überschreiben' : 'Bestätigen';
    confirmBtn.addEventListener('click', function () {
      const cb = onAssignedCb;
      close();
      if (typeof cb === 'function') cb(uid);
    });
    body.appendChild(confirmBtn);

    const cancelBtn = document.createElement('button');
    cancelBtn.type = 'button';
    cancelBtn.className = 'btn-secondary';
    cancelBtn.textContent = 'Abbrechen';
    cancelBtn.addEventListener('click', close);
    body.appendChild(cancelBtn);
  }

  return { open, close };
})();
