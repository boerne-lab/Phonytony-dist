"""HTML-Seiten (Jinja2)."""

from __future__ import annotations

from urllib.parse import urlencode

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

router = APIRouter()


def _render(request: Request, template: str, **ctx):
    templates = request.app.state.templates
    # Starlette >=1.0: Signatur ist TemplateResponse(request, name, context)
    return templates.TemplateResponse(request, template, {"request": request, **ctx})


@router.get("/", response_class=HTMLResponse)
def library_page(request: Request, msg: str = ""):
    from musicbox.store.content import content_kind
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    cards = ms.all_cards()

    # Gruppierung nach (type, ref): ein Bibliothekseintrag + alle Karten,
    # die per assign_to_card() denselben Inhalt referenzieren, werden zu
    # EINER Kachel zusammengefasst. Maßgeblich für Titel/Metadaten ist der
    # Bibliothekseintrag, falls vorhanden; sonst die erste passende Karte
    # (verwaiste Karten — Bibliothekseintrag wurde gelöscht, Karten mit
    # demselben type+ref bestehen aber noch).
    groups = {}
    order = []
    for lib_id, e in ms.library_all().items():
        key = (e.get("type"), e.get("ref"))
        if key not in groups:
            groups[key] = {"lib_id": lib_id, "uids": [], "entry": e}
            order.append(key)
    for uid, c in cards.items():
        key = (c.get("type"), c.get("ref"))
        if key not in groups:
            groups[key] = {"lib_id": None, "uids": [], "entry": c}
            order.append(key)
        groups[key]["uids"].append(uid)

    entries = []
    for key in order:
        g = groups[key]
        entries.append({
            "lib_id": g["lib_id"],
            "uids": g["uids"],
            "entry": g["entry"],
            "kind": content_kind(g["entry"]),
        })
    entries.sort(key=lambda x: (x["entry"].get("label") or x["lib_id"] or x["uids"][0]).lower())
    return _render(request, "library.html", entries=entries, msg=msg,
                   active_tab="library")


@router.get("/library/edit", response_class=HTMLResponse)
def library_edit(request: Request, uid: str = "", lib: str = ""):
    from musicbox.store.content import content_kind
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    uid = uid.upper()
    entry = None
    card_count = 0
    if uid:
        entry = ms.get(uid)
    elif lib:
        entry = ms.library_get(lib)
        if entry is not None:
            key = (entry.get("type"), entry.get("ref"))
            card_count = sum(
                1 for c in ms.all_cards().values()
                if (c.get("type"), c.get("ref")) == key
            )
    if entry is None:
        return RedirectResponse("/", status_code=302)
    return _render(request, "library_edit.html", uid=uid, lib=lib, entry=entry,
                   kind=content_kind(entry), card_count=card_count,
                   active_tab=("cards" if uid else "library"))


@router.get("/cards", response_class=HTMLResponse)
def cards_page(request: Request, msg: str = "", prefill_uid: str = ""):
    ms = request.app.state.mapping_store
    ms.reload_if_changed()
    entries = [{"uid": uid, "entry": c} for uid, c in ms.all_cards().items()]
    entries.sort(key=lambda x: (x["entry"].get("label") or x["uid"]).lower())
    return _render(request, "cards.html", entries=entries, msg=msg,
                   prefill_uid=prefill_uid.upper(), active_tab="cards")


@router.get("/assign")
def assign_redirect(request: Request, uid: str = "", lib: str = "") -> RedirectResponse:
    if uid:
        ms = request.app.state.mapping_store
        ms.reload_if_changed()
        if ms.get(uid.upper()) is not None:
            return RedirectResponse("/library/edit?" + urlencode({"uid": uid}), status_code=302)
        return RedirectResponse("/cards?" + urlencode({"prefill_uid": uid}), status_code=302)
    if lib:
        return RedirectResponse("/library/edit?" + urlencode({"lib": lib}), status_code=302)
    return RedirectResponse("/", status_code=302)


@router.get("/mappings")
def mappings_redirect() -> RedirectResponse:
    return RedirectResponse("/cards", status_code=302)


@router.get("/upload")
def upload_redirect() -> RedirectResponse:
    return RedirectResponse("/", status_code=302)


@router.get("/logs")
def logs_redirect() -> RedirectResponse:
    return RedirectResponse("/device", status_code=302)


@router.get("/settings")
def settings_redirect() -> RedirectResponse:
    return RedirectResponse("/device", status_code=302)


@router.get("/device", response_class=HTMLResponse)
def device_page(request: Request, msg: str = ""):
    return _render(request, "device.html", msg=msg, active_tab="device")
