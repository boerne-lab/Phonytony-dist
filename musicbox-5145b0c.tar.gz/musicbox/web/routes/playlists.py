"""Playlist-Routen: /playlists (HTML) + /api/playlists + /api/files"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse

router = APIRouter()


def _render(request: Request, template: str, **ctx):
    # Starlette >=1.0: Signatur ist TemplateResponse(request, name, context)
    return request.app.state.templates.TemplateResponse(request, template, {"request": request, **ctx})


@router.get("/playlists", response_class=HTMLResponse)
def playlists_page(request: Request, msg: str = ""):
    ps = request.app.state.playlist_store
    ps.load()
    return _render(request, "playlists.html",
                   playlists=ps.all(),
                   files=ps.list_files(),
                   msg=msg,
                   active_tab="device")


@router.get("/api/playlists")
def list_playlists(request: Request) -> dict:
    ps = request.app.state.playlist_store
    ps.load()
    return {"playlists": ps.all()}


@router.post("/api/playlists")
async def create_playlist(request: Request) -> dict:
    body = await request.json()
    name = body.get("name", "").strip()
    category = body.get("category", "musik")
    tracks = body.get("tracks", [])
    shuffle = bool(body.get("shuffle", False))
    repeat = body.get("repeat", "off")
    if not name:
        raise HTTPException(400, "name fehlt")
    ps = request.app.state.playlist_store
    try:
        entry = ps.create(name, category, tracks, shuffle, repeat)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "playlist": entry}


@router.put("/api/playlists/{playlist_id}")
async def update_playlist(playlist_id: str, request: Request) -> dict:
    body = await request.json()
    ps = request.app.state.playlist_store
    try:
        entry = ps.update(playlist_id, **{
            k: v for k, v in body.items()
            if k in ("name", "category", "tracks", "shuffle", "repeat")
        })
    except ValueError as e:
        raise HTTPException(400, str(e))
    if entry is None:
        raise HTTPException(404, "Playlist nicht gefunden")
    return {"ok": True, "playlist": entry}


@router.delete("/api/playlists/{playlist_id}")
def delete_playlist(playlist_id: str, request: Request) -> dict:
    ps = request.app.state.playlist_store
    if not ps.delete(playlist_id):
        raise HTTPException(404, "Playlist nicht gefunden")
    return {"ok": True}


@router.get("/api/files")
def list_files(request: Request) -> dict:
    ps = request.app.state.playlist_store
    return {"files": ps.list_files()}
