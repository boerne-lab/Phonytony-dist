"""WLAN-Seite + API. Schreibende Aktionen laufen über den root-Helfer (sudo)."""

from __future__ import annotations

import asyncio
import json
import subprocess

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

router = APIRouter()
HELPER = "/opt/musicbox/scripts/wifi_helper.sh"


def _helper(cmd: str, *args: str) -> dict:
    try:
        r = subprocess.run(["sudo", "-n", HELPER, cmd, *args],
                           capture_output=True, text=True, timeout=30)
        out = (r.stdout or "").strip()
        return json.loads(out) if out else {"ok": r.returncode == 0}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _render(request: Request, template: str, **ctx):
    return request.app.state.templates.TemplateResponse(request, template, {"request": request, **ctx})


@router.get("/wifi")
def wifi_redirect() -> RedirectResponse:
    return RedirectResponse("/device/wifi", status_code=302)


@router.get("/device/wifi", response_class=HTMLResponse)
def wifi_page(request: Request):
    return _render(request, "wifi.html", ap_ssid=request.app.state.settings.ap_ssid,
                   active_tab="device")


@router.get("/api/wifi")
async def wifi_list(request: Request) -> dict:
    saved = await asyncio.to_thread(_helper, "list")
    scan = await asyncio.to_thread(_helper, "scan")
    return {"saved": saved.get("saved", []), "scan": scan.get("scan", []),
            "ap": {"ssid": request.app.state.settings.ap_ssid}}


@router.post("/api/wifi")
async def wifi_add(request: Request) -> dict:
    body = await request.json()
    ssid = (body.get("ssid") or "").strip()
    pw = body.get("password") or ""
    if not ssid:
        raise HTTPException(400, "ssid fehlt")
    return await asyncio.to_thread(_helper, "add", "--ssid", ssid, "--password", pw)


@router.delete("/api/wifi/{ssid}")
async def wifi_remove(ssid: str, request: Request) -> dict:
    return await asyncio.to_thread(_helper, "remove", "--ssid", ssid)


@router.post("/api/wifi/ap")
async def wifi_ap(request: Request) -> dict:
    body = await request.json()
    ssid = (body.get("ssid") or "").strip()
    pw = body.get("password") or ""
    return await asyncio.to_thread(_helper, "set-ap", "--ssid", ssid, "--password", pw)
